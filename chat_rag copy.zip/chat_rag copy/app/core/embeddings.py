from sentence_transformers import SentenceTransformer
from app.config.settings import settings

_model = SentenceTransformer(settings.EMBEDDING_MODEL)

def embed(text: str):
    return _model.encode(text).tolist()
