from qdrant_client import QdrantClient
from app.config.settings import settings
import threading


# Lazy-initialized Qdrant client to avoid opening the storage at import time
_client = None
_client_lock = threading.Lock()


def _get_client():
    """Get or initialize the Qdrant client with thread-safe lazy loading."""
    global _client
    if _client is None:
        with _client_lock:
            if _client is None:
                _client = QdrantClient(path="./qdrant_data")
    return _client


# Pure delegation proxy - forward all attribute and method calls
class _ClientProxy:
    """Proxy that forwards all calls to the lazy-initialized QdrantClient."""
    
    def __getattr__(self, name):
        """Forward any attribute/method access to the underlying client."""
        actual_client = _get_client()
        attr = getattr(actual_client, name)
        # If it's a method, return it directly so it can be called
        return attr


client = _ClientProxy()
