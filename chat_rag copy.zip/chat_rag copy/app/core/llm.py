import requests
from app.config.settings import settings

def generate(prompt: str):
    """Generate response using Ollama LLM.
    
    Handles deepseek-r1 model which uses thinking tokens.
    For deepseek-r1, uses the thinking field when response is empty.
    """
    res = requests.post(
        f"{settings.OLLAMA_BASE_URL}/api/generate",
        json={
            "model": settings.OLLAMA_MODEL,
            "prompt": prompt,
            "stream": False,
            "options": {
                "num_predict": 1500
            }
        },
        timeout=300
    )
    
    data = res.json()
    response = data.get("response", "").strip()
    
    # For deepseek-r1, if response is empty but thinking exists, use it
    if not response and data.get("thinking"):
        # Extract meaningful content from thinking field
        thinking_text = data.get("thinking", "")
        # Clean up and limit length
        lines = thinking_text.split("\n")
        # Get non-empty lines
        content_lines = [line.strip() for line in lines if line.strip()]
        # Join and limit to 1000 characters
        response = "\n".join(content_lines[:20])[:1000] if content_lines else ""
    
    # Fallback message if both are empty
    if not response:
        response = "I don't have information about that."
    
    return response
