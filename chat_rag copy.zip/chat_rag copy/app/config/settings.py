"""Alias module so `app.config.settings` resolves to the project's root `settings.py`.

This keeps backward compatibility for imports like
`from app.config.settings import settings` while reusing the single
`settings` instance defined at the project root.
"""
from settings import settings

__all__ = ["settings"]
