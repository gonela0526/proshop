"""app.config package initializer."""

__all__ = ["settings"]
