import os
import json
import uuid
from langchain_text_splitters import RecursiveCharacterTextSplitter
from app.core.embeddings import embed
from app.core.vectordb import client
from app.config.settings import settings
from qdrant_client.models import Distance, VectorParams, PointStruct


# Initialize collection if it doesn't exist
def _init_collection():
    """Create collection if it doesn't exist."""
    collections = client.get_collections()
    collection_names = [c.name for c in collections.collections]
    
    if settings.QDRANT_COLLECTION not in collection_names:
        print(f"Creating collection: {settings.QDRANT_COLLECTION}")
        client.create_collection(
            collection_name=settings.QDRANT_COLLECTION,
            vectors_config=VectorParams(
                size=384,  # BAAI/bge-small-en embedding size
                distance=Distance.COSINE
            )
        )


splitter = RecursiveCharacterTextSplitter(
    chunk_size=settings.CHUNK_SIZE,
    chunk_overlap=settings.CHUNK_OVERLAP
)

def normalize_metadata(data):
    """Convert deeply nested config JSON into readable knowledge text."""
    lines = []

    # Project info
    project_key = data.get("project_key")
    if project_key:
        lines.append(f"Project Key: {project_key}")

    # Configsets
    for cfg_id, cfg in data.get("configsets", {}).items():
        lines.append(f"\nConfigset {cfg_id}:")

        for val in cfg.get("config_values", []):
            name = val.get("paramname")
            value = val.get("paramvalue")
            lines.append(f"{name} = {value}")

    # Mappings
    for mapping_id, mapping in data.get("mappings", {}).items():
        scenario = mapping.get("scenario", {})
        scenario_name = scenario.get("name")

        if scenario_name:
            lines.append(f"\nMapping Scenario: {scenario_name}")

        attributes = mapping.get("attributes", {})
        for attr_data in attributes.values():
            attr = attr_data.get("attribute", {})
            src = attr.get("srcname")
            dst = attr.get("dstname")

            if src and dst:
                lines.append(f"Maps '{src}' to '{dst}'")

    # Schedules
    for schedule in data.get("schedules", []):
        name = schedule.get("name")
        cron = schedule.get("cronstring")
        active = schedule.get("isactive")

        lines.append(
            f"Schedule '{name}' runs with cron '{cron}'. Active: {active}"
        )

    return "\n".join(lines)


def ingest_project(project_key):
    """Ingest documents from a project directory into Qdrant.
    
    Args:
        project_key: The directory name/project key (e.g., FORD29262)
    """
    _init_collection()
    
    project_path = f"data/{project_key}"
    
    # Check if directory exists
    if not os.path.isdir(project_path):
        print(f"⚠ Directory not found: {project_path}")
        return
    
    points = []
    
    # Process all JSON files in the project directory
    for file in os.listdir(project_path):
        filepath = os.path.join(project_path, file)
        
        if not os.path.isfile(filepath) or not file.endswith('.json'):
            continue
        
        try:
            with open(filepath) as f:
                data = json.load(f)
                normalized_text = normalize_metadata(data)
                chunks = splitter.split_text(normalized_text)

                
                for chunk in chunks:
                    # Generate embedding for the chunk
                    vector = embed(chunk)
                    
                    # Create a point with ID, vector, and payload
                    point = PointStruct(
                        id=str(uuid.uuid4()),
                        vector=vector,
                        payload={
                            "text": chunk,
                            "project": project_key,  # Use directory name as project key
                            "file": file
                        }
                    )
                    points.append(point)
        except json.JSONDecodeError:
            print(f"⚠ Invalid JSON file: {filepath}")
            continue
        except Exception as e:
            print(f"⚠ Error processing {filepath}: {e}")
            continue
    
    if points:
        # Upsert points to the collection
        print(f"Upserting {len(points)} points for project: {project_key}")
        client.upsert(
            collection_name=settings.QDRANT_COLLECTION,
            points=points
        )
        print(f"✓ Ingestion complete for {project_key}")
    else:
        print(f"⚠ No JSON files found in {project_path}")


def discover_projects():
    """Discover all project directories in data/ folder.
    
    Returns:
        List of project keys (directory names)
    """
    data_path = "data"
    projects = []
    
    if not os.path.isdir(data_path):
        print(f"Error: {data_path} directory not found")
        return projects
    
    for item in os.listdir(data_path):
        item_path = os.path.join(data_path, item)
        if os.path.isdir(item_path):
            projects.append(item)
    
    return sorted(projects)


if __name__ == "__main__":
    # Auto-discover and ingest all projects
    projects = discover_projects()
    
    if not projects:
        print("No project directories found in data/")
    else:
        print(f"Found {len(projects)} project(s): {', '.join(projects)}\n")
        
        for project in projects:
            try:
                ingest_project(project)
            except Exception as e:
                print(f"✗ Error ingesting {project}: {e}")
        
        print("\n✓ All projects ingested successfully!")
