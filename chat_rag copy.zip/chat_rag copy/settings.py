from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    APP_NAME: str
    ENV: str

    OLLAMA_BASE_URL: str
    OLLAMA_MODEL: str

    QDRANT_HOST: str
    QDRANT_PORT: int
    QDRANT_COLLECTION: str

    EMBEDDING_MODEL: str

    CHUNK_SIZE: int
    CHUNK_OVERLAP: int

    TOP_K: int
    SIMILARITY_THRESHOLD: float

    class Config:
        env_file = ".env"

settings = Settings()
