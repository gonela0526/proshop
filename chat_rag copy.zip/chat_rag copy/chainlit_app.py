import chainlit as cl
from app.rag.pipeline import ask
from app.ingest.json_ingestor import discover_projects


@cl.on_chat_start
async def start():
    """Initialize chat session and discover available projects."""
    cl.user_session.set("project", None)
    cl.user_session.set("pending_query", None)
    
    # Discover available projects
    projects = discover_projects()
    if projects:
        cl.user_session.set("available_projects", projects)
    
    await cl.Message(
        content="Welcome to the RAG Chat! Ask any question and I'll help you find the answer."
    ).send()


@cl.on_message
async def chat(msg: cl.Message):
    """Handle user messages and provide RAG responses."""
    
    project = cl.user_session.get("project")
    pending_query = cl.user_session.get("pending_query")
    available_projects = cl.user_session.get("available_projects", [])
    
    # Check if we're waiting for project selection
    if pending_query:
        # User is responding with a project key
        user_input = msg.content.strip()
        
        # Accept the project key (case-sensitive or case-insensitive based on your needs)
        if user_input in available_projects:
            cl.user_session.set("project", user_input)
            
            # Now answer the original query with the selected project
            try:
                answer = ask(pending_query, user_input)
                cl.user_session.set("pending_query", None)
                await cl.Message(content=answer).send()
            except Exception as e:
                await cl.Message(
                    content=f"Error processing your request: {str(e)}"
                ).send()
        else:
            # Invalid project key
            if available_projects:
                await cl.Message(
                    content=f"❌ Project '{user_input}' not found.\n\nAvailable projects: {', '.join(available_projects)}"
                ).send()
            else:
                await cl.Message(
                    content=f"❌ Project '{user_input}' not found. No projects available."
                ).send()
        return
    
    # User is asking a new question
    if not project:
        # No project selected yet, ask for it
        cl.user_session.set("pending_query", msg.content)
        await cl.Message(
            content="Which project would you like to search in?"
        ).send()
        return
    
    # Project already selected, answer the query directly
    try:
        answer = ask(msg.content, project)
        await cl.Message(content=answer).send()
    except Exception as e:
        await cl.Message(
            content=f"Error processing your request: {str(e)}\n\nMake sure the '{project}' data has been ingested."
        ).send()
