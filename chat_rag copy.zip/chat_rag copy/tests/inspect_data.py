#!/usr/bin/env python3
"""Check what data is actually stored in the first few points"""

from app.core.vectordb import client
from app.config.settings import settings
import json

collection_name = settings.QDRANT_COLLECTION

# Get first 10 points
points, _ = client.scroll(collection_name=collection_name, limit=10)

print(f"Sample of stored data:\n")
for i, point in enumerate(points[:3]):
    print(f"\n--- Point {i+1} (ID: {point.id}) ---")
    print(f"Project: {point.payload.get('project')}")
    print(f"File: {point.payload.get('file')}")
    text = point.payload.get('text', '')
    print(f"Text content (first 500 chars):")
    print(text[:500])
    print("\nParsing as JSON to see structure...")
    try:
        data = json.loads(text)
        if isinstance(data, dict):
            print(f"  - Keys: {list(data.keys())[:5]}")
        elif isinstance(data, list):
            print(f"  - Array with {len(data)} items")
            if len(data) > 0 and isinstance(data[0], dict):
                print(f"  - First item keys: {list(data[0].keys())[:5]}")
    except:
        print(f"  - Not valid JSON or couldn't parse")
