#!/usr/bin/env python3
"""Debug script to inspect Qdrant data and test search"""

from app.core.vectordb import client
from app.core.embeddings import embed
from app.config.settings import settings
from qdrant_client.models import Filter, FieldCondition, MatchValue

collection_name = settings.QDRANT_COLLECTION
print(f"Collection: {collection_name}")

# Check collection info
try:
    collection_info = client.get_collection(collection_name)
    print(f"\nCollection info:")
    print(f"  - Points count: {collection_info.points_count}")
    print(f"  - Vector size: {collection_info.config.params.vectors.size}")
except Exception as e:
    print(f"Error getting collection info: {e}")
    exit(1)

# Get all points to see what's stored
print(f"\nScanning all points in collection:")
try:
    points, _ = client.scroll(
        collection_name=collection_name,
        limit=200
    )
    
    if not points:
        print("  No points found in collection!")
    else:
        print(f"  Found {len(points)} points")
        
        # Group by project key
        projects = {}
        for point in points:
            project = point.payload.get("project", "UNKNOWN")
            if project not in projects:
                projects[project] = []
            projects[project].append(point.id)
        
        print(f"\n  Projects and their point counts:")
        for project, ids in sorted(projects.items()):
            print(f"    - {project}: {len(ids)} points")
            
        # Show sample points
        print(f"\n  Sample points (first 3):")
        for i, point in enumerate(points[:3]):
            print(f"\n    Point {i+1} (ID: {point.id}):")
            print(f"      project: {point.payload.get('project')}")
            print(f"      filename: {point.payload.get('filename')}")
            text = point.payload.get('text', '').strip()
            if len(text) > 100:
                text = text[:100] + "..."
            print(f"      text: {text}")
            
except Exception as e:
    print(f"Error scanning points: {e}")
    import traceback
    traceback.print_exc()

# Test search with both projects
print(f"\n\nTesting search queries:")
test_query = "What is the order total"

for project_name in ["FORD29262", "TASK30896"]:
    print(f"\n--- Searching for '{test_query}' in project: {project_name} ---")
    
    try:
        query_filter = Filter(
            must=[
                FieldCondition(
                    key="project",
                    match=MatchValue(value=project_name)
                )
            ]
        )
        
        query_vector = embed(test_query)
        print(f"Query vector shape: {len(query_vector)} dimensions")
        
        results = client.search(
            collection_name=collection_name,
            query_vector=query_vector,
            query_filter=query_filter,
            limit=3
        )
        
        print(f"Results: {len(results)} matches")
        for i, result in enumerate(results):
            print(f"  Match {i+1} (score: {result.score:.4f}):")
            print(f"    project: {result.payload.get('project')}")
            print(f"    filename: {result.payload.get('filename')}")
            text = result.payload.get('text', '').strip()
            if len(text) > 150:
                text = text[:150] + "..."
            print(f"    text: {text}")
            
    except Exception as e:
        print(f"Error searching: {e}")
        import traceback
        traceback.print_exc()

print("\n\nDone!")
