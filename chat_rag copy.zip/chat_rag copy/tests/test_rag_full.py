#!/usr/bin/env python3
"""Test the complete RAG pipeline"""

from app.rag.pipeline import ask

print("🚀 Testing RAG System\n")

test_cases = [
    ("FORD29262", "What attributes are available?"),
    ("FORD29262", "What transformations exist?"),
    ("FORD29262", "Describe the mapping scenarios"),
]

for project, question in test_cases:
    print(f"📁 Project: {project}")
    print(f"❓ Question: {question}")
    print("-" * 60)
    
    try:
        answer = ask(question, project)
        print(f"✅ Response:\n{answer}\n")
    except Exception as e:
        print(f"❌ Error: {e}\n")
