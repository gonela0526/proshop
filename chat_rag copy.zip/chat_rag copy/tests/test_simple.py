#!/usr/bin/env python3
"""Quick test of RAG with a single technical question"""

from app.rag.pipeline import ask
import sys
import time

print("🚀 Testing RAG System with Technical Metadata\n")

project = "FORD29262"
question = "What attributes are available?"

print(f"📁 Project: {project}")
print(f"❓ Question: {question}")
print("\n⏳ Querying (this takes 15-20 seconds due to LLM latency)...")
print("-" * 60)

start_time = time.time()

try:
    answer = ask(question, project)
    elapsed = time.time() - start_time
    
    print(f"\n✅ Response received in {elapsed:.1f} seconds:\n")
    print(answer)
    print("\n" + "-" * 60)
    
    if "I don't have information" in answer:
        print("⚠️  No relevant information found")
    else:
        print("✅ Relevant information FOUND and provided!")
    
except Exception as e:
    print(f"\n❌ Error: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)
