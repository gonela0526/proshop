#!/usr/bin/env python3
"""Test the ask() function directly"""

from app.rag.pipeline import ask
from app.config.settings import settings

print(f"Settings:")
print(f"  TOP_K: {settings.TOP_K}")
print(f"  SIMILARITY_THRESHOLD: {settings.SIMILARITY_THRESHOLD}")

# Test ask function
query = "What is the order total"
projects = ["FORD29262", "TASK30896"]

for project in projects:
    print(f"\n--- Testing ask('{query}', '{project}') ---")
    answer = ask(query, project)
    print(f"Answer length: {len(answer)} characters")
    print(f"Answer (first 200 chars): {answer[:200]}")
