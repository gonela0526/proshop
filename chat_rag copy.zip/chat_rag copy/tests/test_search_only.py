#!/usr/bin/env python3
"""Test the search part of the ask() function"""

from app.core.embeddings import embed
from app.core.vectordb import client
from app.config.settings import settings
from qdrant_client.models import Filter, FieldCondition, MatchValue

print(f"Settings:")
print(f"  TOP_K: {settings.TOP_K}")
print(f"  SIMILARITY_THRESHOLD: {settings.SIMILARITY_THRESHOLD}")

# Replicate the search part of ask()
query = "What is the order total"
projects = ["FORD29262", "TASK30896"]

for project in projects:
    print(f"\n--- Testing search for '{query}' in '{project}' ---")
    
    # This is what the ask() function does
    query_filter = Filter(
        must=[
            FieldCondition(
                key="project",
                match=MatchValue(value=project)
            )
        ]
    )
    
    results = client.search(
        collection_name=settings.QDRANT_COLLECTION,
        query_vector=embed(query),
        query_filter=query_filter,
        limit=settings.TOP_K
    )
    
    print(f"Found {len(results)} results")
    
    if not results:
        print("  → Pipeline would return: 'I don't have information about that.'")
    else:
        # Build context like pipeline does
        context = "\n".join([r.payload["text"] for r in results])
        print(f"  → Context length: {len(context)} characters")
        print(f"  → First 200 chars: {context[:200]}")
