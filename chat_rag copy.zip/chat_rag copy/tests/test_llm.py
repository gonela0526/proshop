from app.core.llm import generate

prompt = """You must answer only using the context below.
If answer not found say: I don't have information about that.

Context:
This is test context about orders and billing.

Question:
What is the order total?"""

print("Testing LLM with timeout...")
try:
    result = generate(prompt)
    print(f"LLM Result: {result}")
except Exception as e:
    print(f"Error: {e}")
    import traceback
    traceback.print_exc()
