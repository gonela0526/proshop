#!/usr/bin/env python3
"""Test RAG system with questions appropriate for technical metadata"""

from app.rag.pipeline import ask

# Test queries that should find answers in the metadata
test_queries = [
    {
        "project": "FORD29262",
        "questions": [
            "What attributes are available?",
            "What field transformations exist?",
            "Tell me about attribute 398",
            "What is the purpose of scenario_id?",
            "What is ismultiline used for?",
            "What attributes have replaces mapping?",
            "Describe the data structure"
        ]
    },
    {
        "project": "TASK30896",
        "questions": [
            "What are the available attributes?",
            "Explain the transformation rules",
            "What is attribute_id 5159?",
            "How are field mappings configured?",
            "What pattern matching options exist?"
        ]
    }
]

print("=" * 80)
print("Testing RAG System with Technical Metadata")
print("=" * 80)

for test_set in test_queries:
    project = test_set["project"]
    print(f"\n\n📁 Project: {project}")
    print("-" * 80)
    
    for i, question in enumerate(test_set["questions"], 1):
        print(f"\n{i}. Question: {question}")
        print("   " + "─" * 76)
        
        try:
            answer = ask(question, project)
            
            # Truncate long answers for readability
            if len(answer) > 500:
                display_answer = answer[:500] + "\n   [... truncated ...]"
            else:
                display_answer = answer
            
            # Format the answer with indentation
            formatted_answer = "\n   ".join(display_answer.split("\n"))
            print(f"   Answer: {formatted_answer}")
            
            # Check if it's the "no information" response
            if "I don't have information" in answer:
                print("   ⚠️  No relevant information found")
            else:
                print("   ✅ Found relevant information")
                
        except Exception as e:
            print(f"   ❌ Error: {e}")

print("\n" + "=" * 80)
print("Test Complete!")
print("=" * 80)
