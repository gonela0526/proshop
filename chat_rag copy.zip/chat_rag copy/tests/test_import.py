#!/usr/bin/env python3
try:
    from app.core.vectordb import client
    print(f"SUCCESS: client={client}, type={type(client).__name__}")
except ImportError as e:
    print(f"IMPORT ERROR: {e}")
except Exception as e:
    print(f"ERROR: {e}")
