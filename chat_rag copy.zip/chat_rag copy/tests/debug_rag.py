#!/usr/bin/env python3
"""Debug RAG pipeline step by step"""

import sys
sys.path.insert(0, '.')

from app.core.embeddings import embed
from app.core.vectordb import client
from app.core.llm import generate
from app.config.settings import settings
from qdrant_client.models import Filter, FieldCondition, MatchValue

query = "What attributes are available?"
project = "FORD29262"

print("=" * 60)
print("RAG Pipeline Debug")
print("=" * 60)

# Step 1: Embed the query
print(f"\n1️⃣  Embedding query: '{query}'")
try:
    query_vector = embed(query)
    print(f"   ✅ Got embedding with dimension: {len(query_vector)}")
except Exception as e:
    print(f"   ❌ Error: {e}")
    sys.exit(1)

# Step 2: Search Qdrant
print(f"\n2️⃣  Searching for project: '{project}'")
try:
    query_filter = Filter(
        must=[
            FieldCondition(
                key="project",
                match=MatchValue(value=project)
            )
        ]
    )
    
    results = client.search(
        collection_name=settings.QDRANT_COLLECTION,
        query_vector=query_vector,
        query_filter=query_filter,
        limit=settings.TOP_K
    )
    
    print(f"   ✅ Found {len(results)} results")
    for i, r in enumerate(results, 1):
        print(f"      [{i}] Score: {r.score:.3f}, Text: {r.payload['text'][:60]}...")
except Exception as e:
    print(f"   ❌ Error: {e}")
    sys.exit(1)

# Step 3: Build context
if not results:
    print(f"\n3️⃣  No results - returning default message")
    response = "I don't have information about that."
else:
    context = "\n".join([r.payload["text"] for r in results])
    print(f"\n3️⃣  Built context ({len(context)} chars)")
    
    # Step 4: Call LLM
    print(f"\n4️⃣  Calling LLM...")
    prompt = f"""You must answer only using the context below.
If answer not found say: I don't have information about that.

Context:
{context}

Question:
{query}
"""
    
    try:
        # Test with direct request to see full response
        import requests
        res = requests.post(
            f"{settings.OLLAMA_BASE_URL}/api/generate",
            json={
                "model": settings.OLLAMA_MODEL,
                "prompt": prompt,
                "stream": False,
                "options": {"num_predict": 200}
            },
            timeout=60
        )
        print(f"   Status: {res.status_code}")
        full_json = res.json()
        print(f"   Full response: {full_json}")
        
        response = full_json.get("response", "")
        print(f"   ✅ Got response: {len(response)} chars")
        if not response:
            print(f"   ⚠️ Response is empty!")
    except Exception as e:
        print(f"   ❌ Error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

# Step 5: Display final response
print("\n" + "=" * 60)
print("FINAL RESPONSE:")
print("=" * 60)
print(response)
