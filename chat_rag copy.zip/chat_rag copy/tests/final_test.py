from app.rag.pipeline import ask
import time

print('🚀 Testing RAG System with Technical Metadata')
print('='*70)

queries = [
    ('What attributes are configured?', 'FORD29262'),
    ('Tell me about field transformations', 'TASK30896'),
]

for question, project in queries:
    print(f'\n Question: {question}')
    print(f'📁 Project: {project}')
    print('─'*70)
    
    start = time.time()
    try:
        answer = ask(question, project)
        elapsed = time.time() - start
        
        print(f'✅ Response ({elapsed:.1f}s):\n')
        # Show first 600 chars
        if len(answer) > 600:
            print(answer[:600] + '\n[...truncated...]')
        else:
            print(answer)
            
        if 'I don\'t have information' in answer:
            print('\n⚠️  No information found')
        else:
            print('\n✓ Information retrieved successfully!')
    except Exception as e:
        print(f'❌ Error: {e}')
        import traceback
        traceback.print_exc()
    
    print('='*70)

print('\n✅ Test complete!')
