#!/usr/bin/env python3
"""Test RAG using Ollama embeddings directly"""

import requests
import json
from qdrant_client import QdrantClient
from qdrant_client.models import Filter, FieldCondition, MatchValue

# Ollama API endpoint for embeddings
OLLAMA_EMBEDDINGS_URL = "http://localhost:11434/api/embeddings"
OLLAMA_MODEL = "nomic-embed-text:latest"

def get_ollama_embedding(text):
    """Get embedding from Ollama"""
    response = requests.post(OLLAMA_EMBEDDINGS_URL, json={"model": OLLAMA_MODEL, "prompt": text})
    if response.status_code == 200:
        return response.json()["embedding"]
    raise Exception(f"Failed to get embedding: {response.text}")

print("🚀 Testing RAG with Ollama Embeddings\n")

# Test queries specific to the metadata content
test_cases = [
    ("FORD29262", "What attributes are available?"),
    ("FORD29262", "What are the transformations?"),
    ("TASK30896", "List the field mappings"),
]

try:
    # Connect to Qdrant
    client = QdrantClient(path='./qdrant_data')
    collection_info = client.get_collection('project_docs')
    print(f"✅ Qdrant collection has {collection_info.points_count} points\n")
    
    for project, query in test_cases:
        print(f"📁 Project: {project}")
        print(f"❓ Query: {query}")
        
        try:
            # Get embedding for query
            query_embedding = get_ollama_embedding(query)
            print(f"✅ Got embedding (dim={len(query_embedding)})")
            
            # Search Qdrant
            results = client.search(
                collection_name='project_docs',
                query_vector=query_embedding,
                query_filter=Filter(
                    must=[FieldCondition(key="project", match=MatchValue(value=project))]
                ),
                limit=3
            )
            
            if results:
                print(f"✅ Found {len(results)} relevant results:")
                for i, result in enumerate(results, 1):
                    print(f"   [{i}] Score={result.score:.3f}, Text={result.payload['text'][:80]}...")
            else:
                print(f"❌ No results found")
                
        except Exception as e:
            print(f"❌ Error processing query: {e}")
        
        print()

except Exception as e:
    print(f"❌ Error: {type(e).__name__}: {e}")
