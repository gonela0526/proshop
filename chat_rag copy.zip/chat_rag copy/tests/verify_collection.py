#!/usr/bin/env python3
"""Verify that Qdrant collection exists and search works"""

from qdrant_client import QdrantClient
from app.core.embeddings import embed
from qdrant_client.models import Filter, FieldCondition, MatchValue

# Connect to Qdrant
client = QdrantClient(path='./qdrant_data')

# Check collection
try:
    info = client.get_collection('project_docs')
    print(f"✅ Collection 'project_docs' exists")
    print(f"✅ Total points: {info.points_count}")
except Exception as e:
    print(f"❌ Collection not found: {e}")
    exit(1)

# Test a search query
query = "What attributes are available?"
query_vector = embed(query)

results = client.search(
    collection_name='project_docs',
    query_vector=query_vector,
    query_filter=Filter(must=[FieldCondition(key="project", match=MatchValue(value="FORD29262"))]),
    limit=3
)

print(f"\n📊 Search results for: '{query}'")
print(f"Found {len(results)} results:\n")

for i, result in enumerate(results, 1):
    print(f"[{i}] Score: {result.score:.3f}")
    print(f"    Text: {result.payload['text'][:100]}...")
    print()

if not results:
    print("❌ No results found")
else:
    print("✅ Search is working!")
