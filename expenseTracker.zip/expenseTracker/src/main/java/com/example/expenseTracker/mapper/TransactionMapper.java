package com.example.expenseTracker.mapper;

import com.example.expenseTracker.model.Transaction;
import com.example.expenseTracker.dto.TransactionDTO;

public class TransactionMapper {

    public static TransactionDTO toDTO(Transaction transaction) {
        TransactionDTO dto = new TransactionDTO();
        dto.setId(transaction.getId());
        dto.setAmount(transaction.getAmount());
        dto.setTransactionType(transaction.getTransactionType());
        dto.setCategory(transaction.getCategory());
        dto.setAccountType(transaction.getAccountType());
        dto.setDescription(transaction.getDescription());
        dto.setDate(transaction.getDate());

        if (transaction.getAccount() != null) {
            dto.setAccountId(transaction.getAccount().getId());
        }

        return dto;
    }

}

