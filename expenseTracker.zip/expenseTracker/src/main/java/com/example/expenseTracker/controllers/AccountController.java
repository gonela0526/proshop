package com.example.expenseTracker.controllers;


import com.example.expenseTracker.dto.AccountDTO;
import com.example.expenseTracker.model.Accounts;
import com.example.expenseTracker.services.AccountService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Tag(name = "Account Controller", description = "APIs for managing user accounts")
@RestController
@RequestMapping("/api/v1/account")
public class AccountController {

    @Autowired
    AccountService accService;

    @Operation(
            summary = "Get all Accounts",
            description = "Fetches all the account details",
            tags = {"Accounts"}
    )
    @GetMapping("/")
    public List<AccountDTO> getAllAccounts()
    {
        return accService.getAllAccounts();
    }


    @Operation(
            summary = "Create a new Account",
            description = "Creates a new account with the provided account details"
    )
    @PostMapping("/")
    public Accounts createAccount(@RequestBody Accounts account)
    {
        return accService.createAccount(account);
    }


    @Operation(
            summary = "Update Account Balance",
            description = "Updates the balance for a specific account based on the transaction amount",
            responses = {
                    @ApiResponse(
                            responseCode = "200",
                            description = "Account updated successfully",
                            content = @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = AccountDTO.class))
                    ),
                    @ApiResponse(responseCode = "404", description = "Account not found")
            }
    )
    @PutMapping("/{accountId}")
    public Accounts updateAccount(@PathVariable Long accountId, @RequestBody Accounts account)
    {
        return accService.updateAccount(accountId,account);
    }

    @GetMapping("/{accountId}")
    public Accounts getAccountById(@PathVariable Long accountId)
    {
        return accService.getAccountById(accountId);
    }
}
