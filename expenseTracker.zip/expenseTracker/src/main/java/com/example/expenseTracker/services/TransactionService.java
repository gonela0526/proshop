package com.example.expenseTracker.services;


import com.example.expenseTracker.dto.CategoryExpenditureDTO;
import com.example.expenseTracker.enums.AccountType;
import com.example.expenseTracker.enums.TransactionType;
import com.example.expenseTracker.mapper.TransactionMapper;
import com.example.expenseTracker.model.Accounts;
import com.example.expenseTracker.model.Transaction;
import com.example.expenseTracker.dto.TransactionDTO;
import com.example.expenseTracker.repos.AccountRepo;
import com.example.expenseTracker.repos.TransactionRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Service
public class TransactionService {
    @Autowired
    TransactionRepo transactRepo;

    @Autowired
    AccountRepo accountRepo;
    public TransactionDTO addTransaction(TransactionDTO transactionDTO) {

        Accounts account = accountRepo.findById(transactionDTO.getAccountId())
                .orElseThrow(() -> new RuntimeException("Account not found with id: "+transactionDTO.getAccountId()));

        if(
                (!transactionDTO.getTransactionType().equals(TransactionType.INCOME) && transactionDTO.getAccountType().equals(AccountType.SAVINGS))
                ||
                (transactionDTO.getTransactionType().equals(TransactionType.INCOME) && transactionDTO.getAccountType().equals(AccountType.CREDIT))
        )
        {
            account.setBalance(account.getBalance().subtract(BigDecimal.valueOf(transactionDTO.getAmount()))
                    .setScale(2, RoundingMode.HALF_UP));
        }else{
            account.setBalance(account.getBalance().add(BigDecimal.valueOf(transactionDTO.getAmount()))
                    .setScale(2, RoundingMode.HALF_UP));
        }






        Transaction transaction = new Transaction();
        transaction.setAccount(account);
        transaction.setAmount(transactionDTO.getAmount());
        transaction.setTransactionType(transactionDTO.getTransactionType());
        transaction.setDate(transactionDTO.getDate());
        transaction.setCategory(transactionDTO.getCategory());
        transaction.setAccountType(transactionDTO.getAccountType());
        transaction.setDescription(transactionDTO.getDescription());

        Transaction saved = transactRepo.save(transaction);

        accountRepo.save(account);


        return TransactionMapper.toDTO(saved);
    }

    public List<TransactionDTO> getAllTransactions() {
        List<Transaction> transactions = transactRepo.findAll();
        return transactions.stream()
                .map(TransactionMapper::toDTO)
                .collect(Collectors.toList());
    }

    public boolean deleteTransactionByID(Long id) {
        Transaction transaction = transactRepo.findById(id).orElse(null);

        if(transaction == null) return false;

        Accounts account = transaction.getAccount();

        if(
                (!transaction.getTransactionType().equals(TransactionType.INCOME) && transaction.getAccountType().equals(AccountType.SAVINGS))
                        ||(transaction.getTransactionType().equals(TransactionType.INCOME) && transaction.getAccountType().equals(AccountType.CREDIT)))
        {
            account.setBalance(account.getBalance().add(BigDecimal.valueOf(transaction.getAmount()))
                    .setScale(2, RoundingMode.HALF_UP));
        }else{
            account.setBalance(account.getBalance().subtract(BigDecimal.valueOf(transaction.getAmount()))
                    .setScale(2, RoundingMode.HALF_UP));
        }


        accountRepo.save(account);

        transactRepo.delete(transaction);
        return true;

    }

    public TransactionDTO updateTransactionById(Long id,TransactionDTO transaction) {

        Transaction existingTransaction = transactRepo.findById(id).orElseThrow(()-> new RuntimeException("Transaction not found"));


        if(transaction.getTransactionType() != null)
        {
            existingTransaction.setTransactionType(transaction.getTransactionType());
        }

        if(transaction.getAccountType() != null)
        {
            existingTransaction.setAccountType(transaction.getAccountType());
        }

        if(transaction.getDate() != null)
        {
            existingTransaction.setDate(transaction.getDate());
        }

        if(transaction.getCategory() != null)
        {
            existingTransaction.setCategory(transaction.getCategory());
        }

        if(transaction.getDescription() != null)
        {
            existingTransaction.setDescription(transaction.getDescription());
        }

        if(transaction.getAmount() != null)
        {
            Accounts account = updateAccountBalForUpdateTransact(transaction, existingTransaction);

            accountRepo.save(account);
            existingTransaction.setAmount(transaction.getAmount());
        }
        transactRepo.save(existingTransaction);
        return TransactionMapper.toDTO(existingTransaction);

    }

    private static Accounts updateAccountBalForUpdateTransact(TransactionDTO transaction, Transaction existingTransaction) {
        Accounts account = existingTransaction.getAccount();
        double remBal = transaction.getAmount() - existingTransaction.getAmount();
        if(
                (!existingTransaction.getTransactionType().equals(TransactionType.INCOME) && existingTransaction.getAccountType().equals(AccountType.SAVINGS))
                ||(existingTransaction.getTransactionType().equals(TransactionType.INCOME) && existingTransaction.getAccountType().equals(AccountType.CREDIT)))
        {
            account.setBalance(account.getBalance().subtract(BigDecimal.valueOf(remBal))
                    .setScale(2, RoundingMode.HALF_UP));
        }else{
            account.setBalance(account.getBalance().add(BigDecimal.valueOf(remBal))
                    .setScale(2, RoundingMode.HALF_UP));
        }
        return account;
    }

    public BigDecimal getTotalExpenditure(LocalDate startDate, LocalDate endDate, TransactionType transactionType)
    {

        return transactRepo.getTotalAmountByDateRangeAndType(startDate,endDate,transactionType);
    }

    public List<TransactionDTO> getTransactionsBetweenDates(LocalDate startDate, LocalDate endDate, TransactionType transactionType)
    {
        List<Transaction> transactionList = transactRepo.getTransactionsBetweenDateRangeAndType(startDate,endDate,transactionType);
        return transactionList
                .stream()
                .map(TransactionMapper::toDTO)
                .collect(Collectors.toList());
    }

    public List<CategoryExpenditureDTO> getCategoryWiseExpenditure(LocalDate startDate, LocalDate endDate, TransactionType transactionType)
    {
        List<Object[]> results = transactRepo.getCategoryWiseExpenditure(startDate,endDate,transactionType);

        return results.stream()
                .map(r -> new CategoryExpenditureDTO((String) r[0],BigDecimal.valueOf((Double) r[1]).setScale(2,RoundingMode.HALF_UP)))
                .collect(Collectors.toList());

    }

}
