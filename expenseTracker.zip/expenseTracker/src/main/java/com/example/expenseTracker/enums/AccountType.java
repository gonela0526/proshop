package com.example.expenseTracker.enums;

public enum AccountType {
    SAVINGS,
    CREDIT
}
