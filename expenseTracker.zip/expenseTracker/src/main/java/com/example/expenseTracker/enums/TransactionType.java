package com.example.expenseTracker.enums;

public enum TransactionType {
    EXPENSE,
    BILL,
    TRANSFER,
    INCOME
}
