package com.example.expenseTracker.repos;

import com.example.expenseTracker.enums.TransactionType;
import com.example.expenseTracker.model.Transaction;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@Repository
public interface TransactionRepo extends JpaRepository<Transaction,Long> {

    @Query("SELECT COALESCE(SUM(t.amount), 0) FROM Transaction t WHERE t.date BETWEEN :startDate AND :endDate AND t.transactionType = :transactionType")
    BigDecimal getTotalAmountByDateRangeAndType(@Param("startDate") LocalDate startDate,
                                                @Param("endDate") LocalDate endDate,
                                                @Param("transactionType") TransactionType transactionType);

    @Query("SELECT t FROM Transaction t WHERE t.date BETWEEN :startDate AND :endDate AND t.transactionType = :transactionType")
    List<Transaction> getTransactionsBetweenDateRangeAndType(@Param("startDate") LocalDate startDate,
                                                             @Param("endDate") LocalDate endDate,
                                                             @Param("transactionType") TransactionType transactionType);


    @Query("SELECT t.category, COALESCE(SUM(t.amount), 0) " +
            "FROM Transaction t " +
            "WHERE t.date BETWEEN :startDate AND :endDate " +
            "AND t.transactionType = :transactionType " +
            "GROUP BY t.category")
    List<Object[]> getCategoryWiseExpenditure(@Param("startDate") LocalDate startDate,
                                              @Param("endDate") LocalDate endDate,
                                              @Param("transactionType") TransactionType transactionType);



}
