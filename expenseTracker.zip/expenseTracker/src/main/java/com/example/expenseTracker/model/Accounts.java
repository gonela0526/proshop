package com.example.expenseTracker.model;


import com.example.expenseTracker.enums.AccountType;
import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.*;
import jakarta.validation.constraints.Digits;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@Entity
@Data
@Table(name = "accounts")
@AllArgsConstructor
@RequiredArgsConstructor
public class Accounts {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Schema(hidden = true)
    private long id;

    private String name;

    @Enumerated(EnumType.STRING)
    private AccountType accountType;

    @Column(precision = 12, scale = 2)   // ensures DB stores only 2 decimal places
    @Digits(integer = 10, fraction = 2)  // validates up to 2 decimals in input
    private BigDecimal balance;

    @OneToMany(mappedBy = "account", cascade = CascadeType.ALL)
    @JsonManagedReference
    @Schema(hidden = true)
    private List<Transaction> transactions = new ArrayList<>();
}
