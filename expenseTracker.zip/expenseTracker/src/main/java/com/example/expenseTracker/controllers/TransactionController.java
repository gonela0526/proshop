package com.example.expenseTracker.controllers;


import com.example.expenseTracker.dto.CategoryExpenditureDTO;
import com.example.expenseTracker.dto.TransactionDTO;
import com.example.expenseTracker.enums.TransactionType;
import com.example.expenseTracker.services.TransactionService;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.*;

@Tag(name = "Transaction Controller", description = "APIs for managing transactions")
@RestController
@RequestMapping("/api/v1/transaction")
public class TransactionController {

    @Autowired
    TransactionService transactService;


    @PostMapping("/")
    public ResponseEntity<TransactionDTO> addTransaction(@Valid @RequestBody TransactionDTO transactionDTO)
    {
        TransactionDTO savedTransaction = transactService.addTransaction(transactionDTO);
        return new ResponseEntity<>(savedTransaction, HttpStatus.CREATED);
    }

    @GetMapping("/")
    public List<TransactionDTO> getAllTransactions()
    {
        return transactService.getAllTransactions();
    }

    @PutMapping("{id}")
    public TransactionDTO updateTransactionById(@PathVariable Long id,@RequestBody TransactionDTO transaction)
    {
        return transactService.updateTransactionById(id,transaction);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteTransaction(@PathVariable Long id){
        boolean deleted = transactService.deleteTransactionByID(id);
        if (deleted) {
            return ResponseEntity.ok("Transaction deleted successfully.");
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("Transaction not found with id: " + id);
        }
    }

    @GetMapping("/expenditure")
    public ResponseEntity<Map<String,Object>> getExpenditure(@RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
                                           @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate,
                                           @RequestParam TransactionType transactionType)
    {
        BigDecimal totalExpenditure = transactService.getTotalExpenditure(startDate, endDate,transactionType);
        totalExpenditure = totalExpenditure.setScale(2, RoundingMode.HALF_UP);
        List<TransactionDTO> transactions = transactService.getTransactionsBetweenDates(startDate, endDate,transactionType);

        List<CategoryExpenditureDTO> categoryExpenditureDTOList = transactService.getCategoryWiseExpenditure(startDate,endDate,transactionType);

        LinkedHashMap<String, Object> response = new LinkedHashMap<>();
        response.put("startDate", startDate);
        response.put("endDate", endDate);
        response.put("totalExpenditure", totalExpenditure);
        response.put("categoryExpenditure",categoryExpenditureDTOList);
        response.put("transactions", transactions);

        return ResponseEntity.ok(response);
    }
}
