package com.example.expenseTracker.mapper;

import com.example.expenseTracker.dto.AccountDTO;
import com.example.expenseTracker.model.Accounts;

public class AccountMapper {

    public static AccountDTO toDto(Accounts account)
    {
        AccountDTO dto = new AccountDTO();

        dto.setId(account.getId());
        dto.setName(account.getName());
        dto.setAccountType(account.getAccountType());
        dto.setBalance(account.getBalance());

        return dto;
    }
}
