package com.example.expenseTracker.services;

import com.example.expenseTracker.mapper.AccountMapper;
import com.example.expenseTracker.dto.AccountDTO;
import com.example.expenseTracker.model.Accounts;
import com.example.expenseTracker.repos.AccountRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class AccountService {

    @Autowired
    AccountRepo repo;
    public Accounts createAccount(Accounts account) {
        return repo.save(account);
    }

    public List<AccountDTO> getAllAccounts() {
       List<Accounts> accounts = repo.findAll();

       return accounts.stream()
               .map(AccountMapper::toDto)
               .collect(Collectors.toList());
    }

    public Accounts updateAccount(Long accountId, Accounts account) {
        Accounts existingAccount = repo.findById(accountId).orElseThrow(() ->new RuntimeException("Account not found"));

        if(account.getName() != null)
        {
            existingAccount.setName(account.getName());
        }
        if(account.getAccountType() != null)
        {
            existingAccount.setAccountType(account.getAccountType());
        }
        if(account.getBalance() != null)
        {
            existingAccount.setBalance(account.getBalance());
        }

        return repo.save(existingAccount);

    }

    public Accounts getAccountById(Long accountId) {
        return repo.findById(accountId).orElseThrow(() ->new RuntimeException("Account not found"));
    }
}
