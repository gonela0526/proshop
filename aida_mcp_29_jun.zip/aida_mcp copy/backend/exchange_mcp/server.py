from mcp.server.fastmcp import FastMCP

from tools.mapping_tool import MappingTool
from tools.config_tool import ConfigTool
from tools.schedule_tool import ScheduleTool

from models.query_plan import QueryPlan
from models.tool_context import ToolContext

mcp = FastMCP("Exchange MCP Server")

@mcp.tool()
def mapping_tool(
        project_key: str,
        process_name: str,
        search_text: str):
    plan = QueryPlan(
        intent="MAPPING",
        tool_name="mapping_tool",
        search_text=search_text
    )

    context = ToolContext(
        project_key=project_key,
        process_name=process_name
    )

    response = MappingTool.execute(
        plan,
        context
    )

    return response.model_dump()


@mcp.tool()
def config_tool(
        project_key: str,
        process_name: str,
        search_text: str,
        config_category: str):
    
    plan = QueryPlan(
        intent="CONFIG",
        tool_name="config_tool",
        search_text=search_text,
        config_category=config_category
    )

    context = ToolContext(
        project_key=project_key,
        process_name=process_name
    )

    response =  ConfigTool.execute(
        plan,
        context
    )
    return response.model_dump()


@mcp.tool()
def schedule_tool(
        project_key: str,
        process_name: str):
    
    plan = QueryPlan(
        intent="SCHEDULE",
        tool_name="schedule_tool"
    )

    context = ToolContext(
        project_key=project_key,
        process_name=process_name
    )

    response = ScheduleTool.execute(
        plan,
        context
    )
    return response.model_dump()


if __name__ == "__main__":
    mcp.run()