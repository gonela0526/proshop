from repositories.config_repository import ConfigRepository
from models.tool_response import ToolResponse
from core.search.retrieval_engine import RetrievalEngine
from core.config_classifier import ConfigClassifier


class ConfigService:

    def __init__(self):
        self.repo = ConfigRepository()
        self.retrieval = RetrievalEngine()

    def get_config(
            self,
            project_key: str,
            process_name: str,
            search_text: str,
            config_category: str):

        configs = self.repo.get_config_value(
            project_key,
            process_name
        )

        filtered_configs = []

        for config in configs:

            category = ConfigClassifier.get_category(
                config["config_key"],
                config["config_value"]
            )

            if category.value == config_category:
                filtered_configs.append(config)

        
        print(f"Filtered Config Count: {len(filtered_configs)}")

        if not filtered_configs:
            return ToolResponse(
                module="config",
                success=False,
                message=f"No configurations found for category '{config_category}'.",
                data={},
                suggestions=[
                    "Try another query"
                ]
            )

        results = self.retrieval.retrieve_candidates(
            search_text=search_text,
            candidates=filtered_configs,
            extractor=lambda x: x["config_key"],
            limit=3
        )

        if not results:

            return ToolResponse(
                module="config",
                success=False,
                message=f"Configuration '{search_text}' not found",
                data={},
                suggestions=[
                    "Show all configurations",
                    "Check another configuration"
                ]
            )

        
        print("\nRetrieved Candidates")

        for result in results:

            print(
                f"{result.item['config_key']} "
                f"({result.score})"
            )
        
        matches = []

        for result in results:

            config = result.item

            matches.append({

                "config_key": config["config_key"],

                "config_value": config["config_value"],

                "confidence": round(result.score, 2)

            })

        return ToolResponse(

            module="config",

            success=True,

            message="Matching configurations found",

            data={
                "matches": matches
            },

            suggestions=[
                "Check another configuration",
                "Show process details"
            ]
        )

        