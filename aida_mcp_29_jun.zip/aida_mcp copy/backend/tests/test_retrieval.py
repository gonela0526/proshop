from core.search.retrieval_engine import RetrievalEngine

engine = RetrievalEngine()

configs = [

    {"config_key": "Include Attachments"},

    {"config_key": "Include creation of WI"},

    {"config_key": "Comments Mapping"},

    {"config_key": "Jira Filter Query"},

    {"config_key": "Resolution Description"}
]

queries = [

    "attachment transfer",

    "attachments",

    "create work item",

    "comments sync",

    "jira filter",

    "resolution",

    "resolution description",

    "database password"
]

for query in queries:

    result = engine.find_best_match(
        query,
        configs,
        lambda x: x["config_key"]
    )

    print("----------------------------------")
    print(query)
    print(result)