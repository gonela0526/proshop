from services.config_service import ConfigService

service = ConfigService()

class ConfigTool:

    @staticmethod
    def execute(
            plan,
            context):

        return service.get_config(
            project_key = context.project_key,
            process_name = context.process_name,
            search_text=plan.search_text,
            config_category=plan.config_category
        )