# core/search/search_result.py

from dataclasses import dataclass
from typing import Any


@dataclass
class SearchResult:

    item: Any
    score: float
    matched_text: str