from pydantic import BaseModel
from typing import Dict


class QueryPlan(BaseModel):

    intent: str
    tool_name: str | None = None
    search_text: str | None = None
    config_category: str | None = None