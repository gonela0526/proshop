from enum import Enum


class ConfigCategory(Enum):

    BOOLEAN = "boolean"

    MAPPING_REFERENCE = "mapping_reference"

    FILTER_QUERY = "filter_query"

    EMAIL = "email"

    JIRA_CONFIG = "jira_config"

    FILE = "file"

    PROJECT = "project"

    VERSION = "version"

    UNKNOWN = "unknown"