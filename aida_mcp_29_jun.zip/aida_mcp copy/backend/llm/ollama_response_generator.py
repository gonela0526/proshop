from llm.ollama_client import OllamaClient
from llm.response_prompt import RESPONSE_PROMPT


class OllamaResponseGenerator:

    @staticmethod
    def generate(
            query,
            tool_response):

        evidence = OllamaResponseGenerator._build_evidence(
            tool_response
        )

        prompt = RESPONSE_PROMPT

        prompt = prompt.replace(
            "{query}",
            query
        )

        prompt = prompt.replace(
            "{evidence}",
            evidence
        )

        return OllamaClient.generate(
            prompt
        )

    @staticmethod
    def _build_evidence(
            tool_response):

        if not tool_response.get("success"):

            return tool_response.get(
                "message",
                "No information found."
            )

        module = tool_response.get("module")

        if module == "config":

            matches = tool_response["data"].get(
                "matches",
                []
            )

            lines = []

            for index, match in enumerate(matches, start=1):

                lines.append(

                    f"{index}. "
                    f"{match['config_key']} = "
                    f"{match['config_value']}"

                )

            return "\n".join(lines)

        return str(
            tool_response.get("data")
        )