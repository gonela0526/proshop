import json

from llm.ollama_client import (
    OllamaClient
)

from llm.planner_prompt import (
    PLANNER_PROMPT
)

from models.query_plan import (
    QueryPlan
)


class OllamaPlanner:

    def build_plan(
            self,
            query):

        prompt = PLANNER_PROMPT.replace(
            "{query}",
            query
        )

        response = (
            OllamaClient.generate(
                prompt
            )
        )

        print("OLLAMA RESPONSE:")
        print(response)
        print(type(response))

        try:
            plan_json = json.loads(
                response)
        except Exception as ex:
            print(
                f"Failed to parse Ollama response: {ex}"
            )

            return QueryPlan(
                intent="UNKNOWN",
                tool_name=None
            )

        return QueryPlan(
            intent=plan_json.get("intent"),
            tool_name=plan_json.get("tool_name"),
            search_text=plan_json.get("search_text"),
            config_category=plan_json.get("config_category")
        )