from rapidfuzz import fuzz

from core.search.text_normalizer import TextNormalizer
from models.search_result import SearchResult


class RetrievalEngine:

    DEFAULT_THRESHOLD = 60
    DEFAULT_LIMIT = 3

    def find_best_match(
            self,
            search_text,
            candidates,
            extractor,
            threshold=DEFAULT_THRESHOLD):

        results = self.retrieve_candidates(
            search_text=search_text,
            candidates=candidates,
            extractor=extractor,
            limit=1,
            threshold=threshold
        )

        if not results:
            return None

        return results[0]

    def retrieve_candidates(
            self,
            search_text,
            candidates,
            extractor,
            limit=DEFAULT_LIMIT,
            threshold=DEFAULT_THRESHOLD):

        normalized_search = TextNormalizer.normalize(
            search_text
        )

        results = []

        for candidate in candidates:

            candidate_text = extractor(candidate)

            normalized_candidate = TextNormalizer.normalize(
                candidate_text
            )

            final_score = fuzz.WRatio(
                normalized_search,
                normalized_candidate
            )


            if final_score < threshold:
                continue

            results.append(
                SearchResult(
                    item=candidate,
                    score=round(final_score, 2),
                    matched_text=normalized_candidate
                )
            )

        results.sort(
            key=lambda result: result.score,
            reverse=True
        )

        return results[:limit]