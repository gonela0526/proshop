import re


class TextNormalizer:

    NORMALIZATION_RULES = {

        # Common abbreviations
        "wi": "work item",
        "cfg": "configuration",
        "cfgs": "configurations",
        "sync": "synchronization",

        # Singular forms
        "attachments": "attachment",
        "comments": "comment",
        "filters": "filter",
        "statuses": "status",

        # Word normalization
        "creation": "create",
        "created": "create",
        "creating": "create",

        "mappings": "mapping",

        "resolutions": "resolution",

        "scheduling":"schedule"
    }

    @staticmethod
    def normalize(text: str) -> str:

        text = text.lower()

        text = re.sub(
            r"[^a-z0-9\s]",
            " ",
            text
        )

        words = text.split()

        normalized = []

        for word in words:

            normalized.append(
                TextNormalizer.NORMALIZATION_RULES.get(
                    word,
                    word
                )
            )

        return " ".join(normalized)