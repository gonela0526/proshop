from models.config_category import ConfigCategory


class ConfigClassifier:

    CATEGORY_RULES = {

        ConfigCategory.MAPPING_REFERENCE: [
            "mapping",
            "scenario"
        ],

        ConfigCategory.FILTER_QUERY: [
            "filter"
        ],

        ConfigCategory.EMAIL: [
            "mail_"
        ],

        ConfigCategory.JIRA_CONFIG: [
            "jiraconfig"
        ],

        ConfigCategory.VERSION: [
            "version"
        ],

        ConfigCategory.FILE: [
            "filepath",
            "script"
        ],

        ConfigCategory.PROJECT: [
            "project"
        ]
    }

    @staticmethod
    def get_category(
            config_key: str,
            config_value: str):

        key = config_key.lower()

        value = str(config_value).lower()

        # Boolean configs
        if value in ["true", "false"]:
            return ConfigCategory.BOOLEAN

        # Keyword based configs
        for category, keywords in ConfigClassifier.CATEGORY_RULES.items():

            for keyword in keywords:

                if keyword in key:
                    return category

        return ConfigCategory.UNKNOWN