CREATE TABLE jira_oauth
(
    id UUID PRIMARY KEY,

    jira_account_id VARCHAR(255) UNIQUE NOT NULL,

    cloud_id VARCHAR(255) NOT NULL,

    access_token TEXT NOT NULL,

    refresh_token TEXT NOT NULL,

    expires_at TIMESTAMP NOT NULL,

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);