import chainlit as cl
import requests

BACKEND_URL = "http://localhost:8080"


def initialize_session():

    response = requests.post(
        f"{BACKEND_URL}/api/session/init"
    )

    response.raise_for_status()

    return response.json()


@cl.on_chat_start
async def on_chat_start():

    session = initialize_session()

    if not session["connected"]:
        authorization_url = session["authorization_url"]
        await cl.Message(
            content=f"""
            # 🤖 Welcome to AIDA

            Jira authentication is required.

            Please click the link below.

            🔗 {authorization_url}

            After authentication you will automatically return to AIDA.
            """
                ).send()

        return

    cl.user_session.set(
        "session",
        session
    )

    if session["connected"]:

        cl.user_session.set(
            "jira_account_id",
            session["user"]["jira_account_id"]
        )

        cl.user_session.set(
            "projects",
            session["context"]["projects"]
        )

        cl.user_session.set(
            "project_ids",
            [
                project["db_project_id"]
                for project in session["context"]["projects"]
            ]
        )

        await show_home(session)

    else:

        await show_login(session)


async def show_login(session):

    await cl.Message(
        content=f"""
        # 🤖 Welcome to AIDA

        Jira authentication is required.

        Please click the link below.

        🔗 {session["authorization_url"]}

        After authentication you will automatically return to AIDA.
        """
            ).send()
    


async def show_home(session):

    projects = session["context"]["projects"]

    project_list = "\n".join(
        [
            f"• {project['project_key']}"
            for project in projects
        ]
    )

    await cl.Message(
        content=f"""
        # 🤖 Welcome to AIDA

        ✅ Connected to Jira

        ### Accessible Projects

        {project_list}

        How can I help you today?
        """
            ).send()