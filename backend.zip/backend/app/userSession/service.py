from app.userSession.repository import UserSessionRepository


class UserSessionService:

    def __init__(self):

        self.repository = UserSessionRepository()

    def create_session(self, email: str):

        return self.repository.create_session(email)

    def validate_session(self, session_id: str):

        return self.repository.get_session(session_id)

    def extend_session(self, session_id: str):

        self.repository.update_session(session_id)

    def logout(self, session_id: str):

        self.repository.delete_session(session_id)