import uuid

from app.database import get_connection


class JiraOAuthRepository:

    def save(
        self,
        email,
        jira_account_id,
        cloud_id,
        access_token,
        refresh_token,
        expires_at
    ):

        conn = get_connection()
        cursor = conn.cursor()

        cursor.execute(
            """
            INSERT INTO jira_oauth
            (
                id,
                email,
                jira_account_id,
                cloud_id,
                access_token,
                refresh_token,
                expires_at
            )

            VALUES (%s,%s,%s,%s,%s,%s,%s)

            ON CONFLICT (jira_account_id)

            DO UPDATE SET

                cloud_id=EXCLUDED.cloud_id,

                access_token=EXCLUDED.access_token,

                refresh_token=EXCLUDED.refresh_token,

                expires_at=EXCLUDED.expires_at,

                updated_at=NOW()
            """,
            (
                str(uuid.uuid4()),
                email,
                jira_account_id,
                cloud_id,
                access_token,
                refresh_token,
                expires_at
            )
        )

        conn.commit()

        cursor.close()
        conn.close()



    def get_connection(self,email: str):

        conn = get_connection()
        cursor = conn.cursor()

        cursor.execute("""
            SELECT
                jira_account_id,
                cloud_id,
                access_token,
                refresh_token,
                expires_at
            FROM jira_oauth
            WHERE email = %s
        """, (email,))

        row = cursor.fetchone()

        cursor.close()
        conn.close()

        if row is None:
            return None

        return {
            "jira_account_id": row[0],
            "cloud_id": row[1],
            "access_token": row[2],
            "refresh_token": row[3],
            "expires_at": row[4]
        }


    def update_tokens(
        self,
        jira_account_id,
        access_token,
        refresh_token,
        expires_at
    ):

        conn = get_connection()
        cursor = conn.cursor()

        cursor.execute(
            """
            UPDATE jira_oauth
            SET
                access_token=%s,
                refresh_token=%s,
                expires_at=%s,
                updated_at=NOW()
            WHERE jira_account_id=%s
            """,
            (
                access_token,
                refresh_token,
                expires_at,
                jira_account_id
            )
        )

        conn.commit()

        cursor.close()
        conn.close()    