from datetime import datetime, timedelta

from app.jiraOAuth.client import JiraClient
from app.jiraOAuth.repository import JiraOAuthRepository
from app.jiraOAuth.schema import (
    JiraProject,
    JiraProjectsResponse
)
from app.project.repository import ProjectRepository
from app.auth.repository import AuthRepository
from app.userSession.service import UserSessionService


CHAINLIT_URL = "http://localhost:8080/chat"


class JiraOAuthService:

    def __init__(self):
        self.repository = JiraOAuthRepository()
        self.auth_repository = AuthRepository()
        self.project_repository = ProjectRepository()
        self.user_session_service = UserSessionService()

    def get_login_url(self):
        return JiraClient.get_authorization_url()

    async def exchange_code(self, code: str, state: str):

        # Validate OAuth state
        auth_request = self.auth_repository.get_request(state)

        if not auth_request:
            raise ValueError("Invalid OAuth state.")

        # Exchange authorization code
        token = await JiraClient.exchange_code(code)

        access_token = token["access_token"]
        refresh_token = token["refresh_token"]

        expires_at = datetime.now() + timedelta(
            seconds=token["expires_in"]
        )

        # Logged in Jira user
        me = await JiraClient.get_me(access_token)

        jira_email = me["email"]

        # Get Cloud Id
        resources = await JiraClient.get_accessible_resources(
            access_token
        )

        if not resources:
            raise Exception("No Jira Cloud instance found.")

        cloud_id = resources[0]["id"]

        # Save / Update OAuth details
        self.repository.save(
            email=jira_email,
            jira_account_id=me["account_id"],
            cloud_id=cloud_id,
            access_token=access_token,
            refresh_token=refresh_token,
            expires_at=expires_at
        )

        # Create browser session
        session_id = self.user_session_service.create_session(
            jira_email
        )

        # OAuth state no longer needed
        self.auth_repository.delete_request(state)

        return session_id

    async def get_projects(self):

        connection = self.repository.get_connection()

        if connection is None:

            return JiraProjectsResponse(
                connected=False,
                projects=[]
            )

        access_token = connection["access_token"]

        if datetime.now() >= connection["expires_at"]:

            token = await JiraClient.refresh_access_token(
                connection["refresh_token"]
            )

            access_token = token["access_token"]

            self.repository.update_tokens(
                connection["jira_account_id"],
                token["access_token"],
                token["refresh_token"],
                datetime.now() + timedelta(
                    seconds=token["expires_in"]
                )
            )

        jira_projects = await JiraClient.get_projects(
            connection["cloud_id"],
            access_token
        )

        db_projects = self.project_repository.get_projects()

        db_project_map = {
            project["project_key"]: project
            for project in db_projects
        }

        matched_projects = []

        for jira_project in jira_projects:

            project_key = jira_project["key"]

            if project_key not in db_project_map:
                continue

            db_project = db_project_map[project_key]

            matched_projects.append(
                JiraProject(
                    jira_project_id=jira_project["id"],
                    project_key=project_key,
                    jira_project_name=jira_project["name"],
                    db_project_id=db_project["project_id"],
                    db_project_name=db_project["project_name"]
                )
            )

        return JiraProjectsResponse(
            connected=True,
            projects=matched_projects
        )