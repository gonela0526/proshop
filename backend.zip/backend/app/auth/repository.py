import uuid

from app.database import get_connection


class AuthRepository:

    def create_request(self):

        state = str(uuid.uuid4())

        conn = get_connection()
        cursor = conn.cursor()

        cursor.execute(
            """
            INSERT INTO oauth_requests
            (
                state
            )
            VALUES
            (
                %s
            )
            """,
            (
                state,
            )
        )

        conn.commit()

        cursor.close()
        conn.close()

        return state
    
    def get_request(self, state: str):

        conn = get_connection()
        cursor = conn.cursor()

        cursor.execute(
            """
            SELECT
                state
            FROM oauth_requests
            WHERE state=%s
            """,
            (state,)
        )

        row = cursor.fetchone()

        cursor.close()
        conn.close()

        if row is None:
            return None

        return True


    def delete_request(self, state: str):

        conn = get_connection()
        cursor = conn.cursor()

        cursor.execute(
            """
            DELETE
            FROM oauth_requests
            WHERE state=%s
            """,
            (state,)
        )

        conn.commit()

        cursor.close()
        conn.close()

        