from dataclasses import dataclass


@dataclass
class AuthStartRequest:

    email: str


@dataclass
class AuthStartResponse:

    authorization_url: str