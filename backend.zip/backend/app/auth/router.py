from dataclasses import asdict

from fastapi import APIRouter

from app.auth.schema import AuthStartRequest
from app.auth.service import AuthService

router = APIRouter(
    prefix="/api/auth",
    tags=["Authentication"]
)

service = AuthService()


@router.post("/start")
async def start_authentication(
    request: AuthStartRequest
):

    response = await service.start_authentication(
        request
    )

    return asdict(response)