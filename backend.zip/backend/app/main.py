from fastapi import FastAPI
from chainlit.utils import mount_chainlit
from app.jiraOAuth.router import router as jira_router
from app.session.router import router as session_router
from app.auth.router import router as auth_router
from pathlib import Path
from fastapi import Request
from fastapi.responses import RedirectResponse
from app.session.service import SessionService



session_service = SessionService()

current_dir = Path(__file__).parent

frontend_path = (current_dir / ".." / "frontend" / "app.py").resolve()

app = FastAPI(
    title="Jira OAuth Demo"
)

app.include_router(jira_router)
app.include_router(session_router)
app.include_router(auth_router)


mount_chainlit(
    app=app,
    target=str(frontend_path),
    path="/chat"
)


@app.get("/")
async def home(request: Request):

    print("Request received at /")
    redirect_url = await session_service.bootstrap(request)
    print("redirect_url", redirect_url)

    return RedirectResponse(url=redirect_url)