from app.database import get_connection


class ProjectRepository:

    def get_projects(self):

        conn = get_connection()
        cursor = conn.cursor()

        cursor.execute("""
            SELECT
                id,
                project_key,
                project_name
            FROM projects
        """)

        rows = cursor.fetchall()

        cursor.close()
        conn.close()

        return [
            {
                "project_id": row[0],
                "project_key": row[1],
                "project_name": row[2]
            }
            for row in rows
        ]