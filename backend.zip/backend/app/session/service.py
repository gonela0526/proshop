from datetime import datetime

from app.jiraOAuth.service import JiraOAuthService
from app.jiraOAuth.client import JiraClient
from fastapi import Request
from app.userSession.repository import UserSessionRepository
from app.userSession.service import UserSessionService
from app.auth.service import AuthService
from fastapi.responses import RedirectResponse

from app.session.schema import (
    UserInfo,
    SessionContext,
    SessionResponse
)


class SessionService:

    def __init__(self):

        self.jira_service = JiraOAuthService()
        self.user_session_service = UserSessionService()
        self.auth_service = AuthService()
    async def initialize_session(self,
                                 session_id: str | None):
        
        if session_id is None:

            return SessionResponse(
                connected=False,
                authorization_url=None,
                user=None,
                context=None
            )

        user_session = self.user_session_service.validate_session(
            session_id
        )

        if user_session is None:

            return SessionResponse(
                connected=False,
                authorization_url=None,
                user=None,
                context=None
            )

        self.user_session_service.extend_session(
            session_id
        )

        jira_response = await self.jira_service.get_projects()

        self.user_session_repository = UserSessionRepository()
        if session_id is None:

            return SessionResponse(
                connected=False,
                authorization_url=None,
                user=None,
                context=None
            )
        
        user_session = self.user_session_repository.get_session(
            session_id
        )

        if user_session is None:

            return SessionResponse(
                connected=False,
                authorization_url=None,
                user=None,
                context=None
            )

        self.user_session_repository.update_session(
            session_id
        )

        if not jira_response.connected:

            return SessionResponse(
                connected=False,
                authorization_url=JiraClient.get_authorization_url(),
                user=None,
                context=None
            )
        


        connection = self.jira_service.repository.get_connection(user_session["email"])

        return SessionResponse(

            connected=True,
            authorization_url=None,
            user=UserInfo(
                jira_account_id=connection["jira_account_id"]
            ),

            context=SessionContext(
                initialized_at=datetime.utcnow(),
                projects=jira_response.projects
            )
        )
    

    async def bootstrap(self, request: Request):

        session = request.cookies.get("AIDA_SESSION")
        print("session_id", session)

        if session is None:
            authorization_url = await self.auth_service.start_authentication()
            return authorization_url

        return "/chat"