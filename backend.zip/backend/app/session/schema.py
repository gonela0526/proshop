from dataclasses import dataclass
from datetime import datetime

from app.jiraOAuth.schema import JiraProject


@dataclass
class UserInfo:

    jira_account_id: str


@dataclass
class SessionContext:

    initialized_at: datetime

    projects: list[JiraProject]


@dataclass
class SessionResponse:

    connected: bool
    authorization_url: str | None
    user: UserInfo | None
    context: SessionContext | None