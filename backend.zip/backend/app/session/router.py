from dataclasses import asdict

from fastapi import APIRouter, Request

from app.session.service import SessionService

router = APIRouter(
    prefix="/api/session",
    tags=["Session"]
)

service = SessionService()


@router.post("/init")
async def initialize(request: Request):

    session_id = request.cookies.get(
        "AIDA_SESSION"
    )

    response =  await service.initialize_session(
        session_id
    )
    return asdict(response)