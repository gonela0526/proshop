import chainlit as cl
from ui_renderer import render_response
import httpx

BACKEND_URL = "http://localhost:8000"  # adjust if needed


async def send_to_backend(session_id: str, query: str):
    async with httpx.AsyncClient() as client:
        response = await client.post(
            f"{BACKEND_URL}/query",
            json={
                "session_id": session_id,
                "query": query
            }
        )
        return response.json()

@cl.on_chat_start
async def start():
    cl.user_session.set("session_id", None)

    await cl.Message(
        content="Exchange Intelligence Console is ready."
    ).send()
    


@cl.on_message
async def handle_message(message: cl.Message):

    session_id = cl.user_session.get("session_id")

    response = await send_to_backend(session_id, message.content)


    if response.get("session_id"):
        cl.user_session.set("session_id", response["session_id"])

    # Handle clarification separately
    if response.get("status") == "clarification_required":
        await render_clarification_buttons(response)
        return

    await render_backend_response(response)


async def render_clarification_buttons(response):

    details = response.get("details", {})
    session_id = response.get("session_id")

    actions = []

    # -----------------------
    # OEM SELECTION
    # -----------------------
    if "oem_required" in details:

        for option in details["oem_required"]:
            label = option.get("name")

            actions.append(
                cl.Action(
                    name="clarification_select",
                    payload={
                        "type": "oem",
                        "value": option.get("name"),
                        "session_id": session_id
                    },
                    label=label
                )
            )

        await cl.Message(
            content="Please select an OEM:",
            actions=actions
        ).send()

        return


    # -----------------------
    # PROJECT SELECTION
    # -----------------------
    if "project_required" in details:

        for option in details["project_required"]:
            label = option.get("project_name") or option.get("project_key")

            actions.append(
                cl.Action(
                    name="clarification_select",
                    payload={
                        "type": "project",
                        "value": option.get("project_key"),
                        "session_id": session_id
                    },
                    label=label
                )
            )

        await cl.Message(
            content="Please select a project:",
            actions=actions
        ).send()

        return

    # -----------------------
    # PROCESS SELECTION
    # -----------------------
    if "process_required" in details:

        for option in details["process_required"]:
            label = option.get("process_name")

            actions.append(
                cl.Action(
                    name="clarification_select",
                    payload={
                        "type": "process",
                        "value": option.get("process_name"),
                        "session_id": session_id
                    },
                    label=label
                )
            )

        await cl.Message(
            content="Please select a process:",
            actions=actions
        ).send()

        return


async def render_backend_response(response: dict):

    status = response.get("status")

    # ----------------------------
    # Clarification
    # ----------------------------
    if status == "clarification_required":
        await render_clarification_buttons(response)
        return

    # ----------------------------
    # Success
    # ----------------------------
    if status == "success":

        # 1️⃣ Schedule Query
        if "schedule" in response:
            content = f"""
### ⏱ Exchange Schedule

**Project:** {response.get("project_key")}
**Process:** {response.get("process_name")}

**Cron Expression:**
`{response.get("schedule")}`
"""
            await cl.Message(
                content=content,
                actions=[
                    cl.Action(
                        name="feedback",
                        payload={"type": "like"},
                        label="👍"
                    ),
                    cl.Action(
                        name="feedback",
                        payload={"type": "dislike"},
                        label="👎"
                    )
                ]
            ).send()
            return

        # 2️⃣ Failure Summary
        if "failures" in response:
            lines = []
            for f in response["failures"]:
                lines.append(
                    f"• **{f['defect_id']}** | {f['direction']} | {f['message']}"
                )

            content = "### ❌ Recent Failures\n\n" + "\n".join(lines)

            await cl.Message(
                content=content,
                actions=[
                    cl.Action(
                        name="feedback",
                        payload={"type": "like"},
                        label="👍"
                    ),
                    cl.Action(
                        name="feedback",
                        payload={"type": "dislike"},
                        label="👎"
                    )
                ]
            ).send()
            return

        # 3️⃣ Config Query
        if "config_key" in response:
            content = f"""
### ⚙ Configuration

**Key:** {response.get("config_key")}
**Value:** `{response.get("value")}`
"""
            await cl.Message(
                content=content,
                actions=[
                    cl.Action(
                        name="feedback",
                        payload={"type": "like"},
                        label="👍"
                    ),
                    cl.Action(
                        name="feedback",
                        payload={"type": "dislike"},
                        label="👎"
                    )
                ]
            ).send()
            return

        # 4️⃣ ✅ ADD THIS BLOCK HERE (Mapping Renderer)
        if "mappings" in response and isinstance(response["mappings"], dict):

            lines = []
            lines.append("### 🔁 Field Mappings")
            lines.append(f"**Project:** {response.get('project_key')}")
            lines.append(f"**Process:** {response.get('process_name')}\n")

            for scenario, mappings in response["mappings"].items():

                lines.append(f"#### 🧩 Scenario: {scenario}")

                for m in mappings:
                    lines.append(
                        f"- **{m['source_field']}** → `{m['destination_field']}`"
                    )

                lines.append("")

            content = "\n".join(lines)

            await cl.Message(
                content=content,
                actions=[
                    cl.Action(
                        name="feedback",
                        payload={"type": "like"},
                        label="👍"
                    ),
                    cl.Action(
                        name="feedback",
                        payload={"type": "dislike"},
                        label="👎"
                    )
                ]
            ).send()
            return

        
        # 5️⃣ Exchange History
        if "results" in response and isinstance(response["results"], dict):

            lines = []
            lines.append("### 🧾 Exchange History\n")

            for defect_id, data in response["results"].items():

                summary = data.get("summary", {})
                history = data.get("history", [])

                lines.append(f"## 🔎 {defect_id}")
                lines.append(f"- Total Attempts: {summary.get('total_attempts')}")
                lines.append(f"- Failed Attempts: {summary.get('failed_attempts')}")
                lines.append(f"- Latest Status: {summary.get('latest_status')}")
                lines.append("")

                for h in history:
                    lines.append(
                        f"• {h['timestamp']} | {h['direction']} | {h['exchange_status']}"
                    )

                lines.append("")

            content = "\n".join(lines)

            await cl.Message(
                content=content,
                actions=[
                    cl.Action(
                        name="feedback",
                        payload={"type": "like"},
                        label="👍"
                    ),
                    cl.Action(
                        name="feedback",
                        payload={"type": "dislike"},
                        label="👎"
                    )
                ]
            ).send()
            return

        # 5️⃣ Fallback JSON
        await cl.Message(
            content=f"```json\n{response}\n```"
        ).send()
        return

    # ----------------------------
    # Not found
    # ----------------------------
    if status == "not_found":
        await cl.Message(
            content=f"⚠ {response.get('message', 'No data found.')}",
            actions=[
                cl.Action(
                    name="feedback",
                    payload={"type": "like"},
                    label="👍"
                ),
                cl.Action(
                    name="feedback",
                    payload={"type": "dislike"},
                    label="👎"
                )
            ]
        ).send()
        return
    

    if status == "unknown_intent":
        await cl.Message(
        content="⚠ I couldn't understand your request. Please try rephrasing.",
        actions=[
            cl.Action(
                name="feedback",
                payload={"type": "like"},
                label="👍"
            ),
            cl.Action(
                name="feedback",
                payload={"type": "dislike"},
                label="👎"
            )
        ]
    ).send()
        return

    # Final fallback
    await cl.Message(
        content="⚠ Something unexpected happened."
    ).send()


    # ----------------------------
    # Default fallback
    # ----------------------------
    await cl.Message(
        content=f"⚠ {response}"
    ).send()

@cl.action_callback("clarification_select")
async def handle_clarification_selection(action: cl.Action):

    selection_type = action.payload["type"]
    value = action.payload["value"]
    session_id = action.payload["session_id"]

    if selection_type == "oem":
        query = f"__select_oem__={value}"
    elif selection_type == "project":
        query = f"__select_project__={value}"
    elif selection_type == "process":
        query = f"__select_process__={value}"
    else:
        return

    response = await send_to_backend(session_id, query)

    await render_backend_response(response)



@cl.action_callback("feedback")
async def handle_feedback(action: cl.Action):

    session_id = cl.user_session.get("session_id")
    feedback_type = action.payload["type"]

    async with httpx.AsyncClient() as client:
        await client.post(
            f"{BACKEND_URL}/feedback",
            json={
                "session_id": session_id,
                "feedback": feedback_type
            }
        )

    await cl.Message(
        content="Thanks for your feedback! 🙌"
    ).send()


