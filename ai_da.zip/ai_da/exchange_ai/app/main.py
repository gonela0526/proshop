from fastapi import FastAPI, Body
from app.db.connection import get_connection
from app.session.session_service import SessionService
from app.router.query_router import QueryRouter
from app.utils.logger import setup_logger
from typing import Optional

logger = setup_logger()



session_service = SessionService()
router_instance = QueryRouter()

app = FastAPI()

@app.get("/health")
def health_check():
    try:
        conn = get_connection()
        conn.close()
        return {"status": "ok"}
    except Exception as e:
        return {"status": "error", "details": str(e)}
    

@app.get("/create-session")
def create_session():
    return {"session_id": session_service.create_session()}


@app.post("/query")
def query(
    session_id: Optional[str] = Body(None),
    query: str = Body(...)
):
    # Create session if not provided
    if not session_id:
        session_id = session_service.create_session()

    result = router_instance.handle_query(session_id, query)

    # Always return session_id to frontend
    if isinstance(result, dict):
        result["session_id"] = session_id

    return result



@app.post("/feedback")
def store_feedback(
    session_id: str = Body(...),
    feedback: str = Body(...)
):
    return router_instance.handle_feedback(session_id, feedback)
