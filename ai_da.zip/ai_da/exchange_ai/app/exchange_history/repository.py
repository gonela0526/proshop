
def get_exchange_history_for_defects(conn, defect_ids: list):

    placeholders = ",".join(["%s"] * len(defect_ids))

    query = f"""
        SELECT 
            ed.sourcewiid,
            ed.destinationwiid,
            ed.status,
            ed.description,
            ed.processid
        FROM exchange_description ed
        WHERE ed.sourcewiid IN ({placeholders})
           OR ed.destinationwiid IN ({placeholders})
        ORDER BY ed.processid;
    """

    params = defect_ids + defect_ids

    cur = conn.cursor()
    cur.execute(query, params)
    rows = cur.fetchall()
    cur.close()

    return rows

def get_failed_defects(conn, project_key=None, start_time=None, end_time=None, direction=None):

    query = """
        SELECT 
            ed.sourcewiid,
            ed.destinationwiid,
            ed.status,
            ed.description,
            ed.processid
        FROM exchange_description ed
        WHERE ed.status ILIKE 'Failed'
    """

    params = []

    if project_key:
        query += " AND (ed.sourcewiid ILIKE %s OR ed.destinationwiid ILIKE %s)"
        prefix = f"{project_key}-%"
        params.extend([prefix, prefix])

    if direction:
        query += " AND ed.processid ILIKE %s"
        params.append(f"%{direction}%")

    cur = conn.cursor()
    cur.execute(query, params)
    rows = cur.fetchall()
    cur.close()

    return rows

def get_all_failures(conn):
    cur = conn.cursor()
    cur.execute("""
        SELECT sourcewiid, destinationwiid, status, description, processid
        FROM exchange_description
        WHERE status = 'Failed';
    """)
    rows = cur.fetchall()
    cur.close()
    return rows

