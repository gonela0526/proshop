from app.db.connection import get_connection
from app.utils import logger
from . import repository
from app.utils.defect_parser import extract_defect_ids
from collections import defaultdict
from datetime import datetime
from app.utils.time_parser import extract_time_range
from app.utils.defect_parser import extract_defect_ids
import re

class ExchangeHistoryService:

    def get_history(self, query_text: str):

        defect_ids = extract_defect_ids(query_text)
        start_time, end_time = extract_time_range(query_text)

        if not defect_ids:
            return {
                "status": "clarification_required",
                "message": "Please provide at least one defect ID."
            }

        conn = get_connection()
        try:
            rows = repository.get_exchange_history_for_defects(conn, defect_ids)
        finally:
            conn.close()

        if not rows:
            return {
                "status": "not_found",
                "defects": defect_ids
            }

        grouped = defaultdict(lambda: {
            "history": [],
            "summary": {}
        })

        # Step 1: Build full history
        for row in rows:
            source_id, dest_id, status, desc, processid = row

            timestamp_part, direction = processid.split("_", 1)
            dt = datetime.strptime(timestamp_part, "%y%m%d%H%M%S")

            source_id_norm = source_id.upper() if source_id else None
            dest_id_norm = dest_id.upper() if dest_id else None

            if source_id_norm in defect_ids:
                defect_key = source_id_norm
            elif dest_id_norm and dest_id_norm in defect_ids:
                defect_key = dest_id_norm
            else:
                continue

            entry = {
                "timestamp": dt.isoformat(),
                "project_key": defect_key.split("-")[0],
                "direction": direction,
                "exchange_status": status,
                "source_id": source_id,
                "destination_id": dest_id,
                "message": desc
            }

            grouped[defect_key]["history"].append(entry)

        # Step 2: Apply time filter and recompute summary
        for defect_key in grouped:

            full_history = grouped[defect_key]["history"]

            if start_time and end_time:
                filtered_history = [
                    item for item in full_history
                    if start_time <= datetime.fromisoformat(item["timestamp"]) <= end_time
                ]
            else:
                filtered_history = full_history

            grouped[defect_key]["history"] = filtered_history

            summary = {
                "latest_status": None,
                "latest_timestamp": None,
                "total_attempts": 0,
                "successful_attempts": 0,
                "failed_attempts": 0,
                "directions_seen": set(),
                "is_currently_synced": None
            }

            for entry in filtered_history:
                summary["total_attempts"] += 1
                summary["directions_seen"].add(entry["direction"])

                if entry["exchange_status"].lower() == "failed":
                    summary["failed_attempts"] += 1
                else:
                    summary["successful_attempts"] += 1

                summary["latest_status"] = entry["exchange_status"]
                summary["latest_timestamp"] = entry["timestamp"]

            summary["directions_seen"] = list(summary["directions_seen"])

            if summary["latest_status"]:
                summary["is_currently_synced"] = (
                    summary["latest_status"].lower() != "failed"
                )

            grouped[defect_key]["summary"] = summary

        return {
            "status": "success",
            "results": grouped
        }


    def get_failure_summary(self, query_text: str):

        query_upper = query_text.upper()

        # --- Extract project key ---
        project_match = re.search(r"for\s+([A-Z0-9]+)", query_upper)
        project_key = project_match.group(1) if project_match else None

        # --- Extract direction ---
        direction_match = re.search(r"\b(\w+to\w+)\b", query_text)
        direction = direction_match.group(1) if direction_match else None

        # --- Extract time range ---
        start_time, end_time = extract_time_range(query_text)

        conn = get_connection()
        try:
            rows = repository.get_failed_defects(
                conn,
                project_key=project_key,
                direction=direction
            )
        except Exception as e:
            logger.error(f"DB error in get_failed_defects: {e}")
            raise
        finally:
            conn.close()

        results = []
        unique_defects = set()
        directions_seen = set()

        for row in rows:
            source_id, dest_id, status, desc, processid = row

            timestamp_part, dir_value = processid.split("_", 1)
            dt = datetime.strptime(timestamp_part, "%y%m%d%H%M%S")

            # --- Apply time filter ---
            if start_time and end_time:
                if not (start_time <= dt <= end_time):
                    continue

            defect_id = source_id if source_id else dest_id

            results.append({
                "defect_id": defect_id,
                "timestamp": dt.isoformat(),
                "direction": dir_value,
                "message": desc
            })

            # Sort by timestamp descending
            results.sort(key=lambda x: x["timestamp"], reverse=True)

            



            unique_defects.add(defect_id)
            directions_seen.add(dir_value)

        page = 1
        page_size = 20

        start_index = (page - 1) * page_size
        end_index = start_index + page_size

        paginated_results = results[start_index:end_index]
        
        return {
            "status": "success",
            "filters_applied": {
                "project_key": project_key,
                "direction": direction,
                "time_range": {
                    "start": start_time.isoformat() if start_time else None,
                    "end": end_time.isoformat() if end_time else None
                }
            },
            "summary": {
                "total_failures": len(results),
                "unique_defects": len(unique_defects),
                "directions_involved": list(directions_seen)
            },
            "failures": paginated_results
        }
    

    def get_top_failure_reasons(self, query_text: str):

        import re
        from datetime import datetime
        from collections import defaultdict
        from app.utils.time_parser import extract_time_range

        query_upper = query_text.upper()

        # --- Extract project ---
        project_match = re.search(r"for\s+([A-Z0-9]+)", query_upper)
        project_key = project_match.group(1) if project_match else None

        # --- Extract direction ---
        direction_match = re.search(r"\b(\w+to\w+)\b", query_text)
        direction = direction_match.group(1) if direction_match else None

        # --- Extract time ---
        start_time, end_time = extract_time_range(query_text)

        conn = get_connection()
        try:
            rows = repository.get_failed_defects(
                conn,
                project_key=project_key,
                direction=direction
            )
        finally:
            conn.close()

        reason_counter = defaultdict(int)
        total_failures = 0

        for row in rows:
            source_id, dest_id, status, desc, processid = row

            timestamp_part, _ = processid.split("_", 1)
            dt = datetime.strptime(timestamp_part, "%y%m%d%H%M%S")

            # Apply time filter
            if start_time and end_time:
                if not (start_time <= dt <= end_time):
                    continue

            reason_counter[desc] += 1
            total_failures += 1

        # Sort reasons by count descending
        sorted_reasons = sorted(
            reason_counter.items(),
            key=lambda x: x[1],
            reverse=True
        )

        top_n = 5
        top_reasons = [
            {"reason": reason, "count": count}
            for reason, count in sorted_reasons[:top_n]
        ]

        return {
            "status": "success",
            "filters_applied": {
                "project_key": project_key,
                "direction": direction,
                "time_range": {
                    "start": start_time.isoformat() if start_time else None,
                    "end": end_time.isoformat() if end_time else None
                }
            },
            "summary": {
                "total_failures": total_failures,
                "unique_reasons": len(reason_counter)
            },
            "top_failure_reasons": top_reasons
        }
    
    def get_global_health(self):

        from datetime import datetime, timedelta

        now = datetime.utcnow()
        last_7_days = now - timedelta(days=7)
        previous_7_days = last_7_days - timedelta(days=7)

        conn = get_connection()
        try:
            rows = repository.get_all_failures(conn)
        finally:
            conn.close()

        total_today = 0
        total_last_7 = 0
        total_previous_7 = 0

        direction_counter = {}

        for row in rows:
            source_id, dest_id, status, desc, processid = row

            timestamp_part, direction = processid.split("_", 1)
            dt = datetime.strptime(timestamp_part, "%y%m%d%H%M%S")

            if dt.date() == now.date():
                total_today += 1

            if last_7_days <= dt <= now:
                total_last_7 += 1

            if previous_7_days <= dt < last_7_days:
                total_previous_7 += 1

            direction_counter[direction] = direction_counter.get(direction, 0) + 1

        trend = None
        if total_previous_7 > 0:
            trend = round(
                ((total_last_7 - total_previous_7) / total_previous_7) * 100, 2
            )

        return {
            "summary": {
                "failures_today": total_today,
                "failures_last_7_days": total_last_7,
                "failures_previous_7_days": total_previous_7,
                "trend_percentage": trend,
                "direction_distribution": direction_counter
            }
        }




