import json
from app.db.connection import get_connection


def ingest_program(file_path: str):

    conn = get_connection()
    cur = conn.cursor()

    with open(file_path) as f:
        program = json.load(f)

    oem_name = program["oem"].upper()
    project_key = program["project key"]
    project_name = program.get("project name")

    # -----------------------------------
    # 1️⃣ Insert or fetch OEM
    # -----------------------------------
    cur.execute("""
        INSERT INTO oems (name)
        VALUES (%s)
        ON CONFLICT (name)
        DO UPDATE SET name = EXCLUDED.name
        RETURNING id
    """, (oem_name,))
    oem_id = cur.fetchone()[0]

    # -----------------------------------
    # 2️⃣ Insert or update Project
    # -----------------------------------
    cur.execute("""
        INSERT INTO projects (project_key, project_name, oem_id)
        VALUES (%s, %s, %s)
        ON CONFLICT (project_key)
        DO UPDATE SET
            project_name = EXCLUDED.project_name,
            oem_id = EXCLUDED.oem_id
        RETURNING id
    """, (project_key, project_name, oem_id))

    project_id = cur.fetchone()[0]

    # -----------------------------------
    # 3️⃣ Delete old processes (idempotent)
    # -----------------------------------
    cur.execute("""
        DELETE FROM processes
        WHERE project_id = %s
    """, (project_id,))

    # -----------------------------------
    # 4️⃣ Insert processes
    # -----------------------------------
    for process in program.get("process", []):

        process_name = process.get("process name")
        schedule = process.get("schedules")

        cur.execute("""
            INSERT INTO processes (project_id, process_name, schedule)
            VALUES (%s, %s, %s)
            RETURNING id
        """, (project_id, process_name, schedule))

        process_id = cur.fetchone()[0]

        config = process.get("config", {})

        # -----------------------------------
        # 5️⃣ Insert config entries
        # -----------------------------------
        for key, value in config.items():

            if key == "mappings":
                continue

            if isinstance(value, (str, int, bool)):
                cur.execute("""
                    INSERT INTO config_entries (process_id, config_key, config_value)
                    VALUES (%s, %s, %s)
                """, (process_id, key, str(value)))

        # -----------------------------------
        # 6️⃣ Insert mapping scenarios
        # -----------------------------------
        mappings = config.get("mappings", {})

        for scenario_name, scenario in mappings.items():

            cur.execute("""
                INSERT INTO mapping_scenarios (process_id, scenario_name)
                VALUES (%s, %s)
                RETURNING id
            """, (process_id, scenario_name))

            scenario_id = cur.fetchone()[0]

            # -----------------------------------
            # 7️⃣ Attribute mappings
            # -----------------------------------
            for mapping in scenario.get("Attribute Mapping", []):

                source = mapping.get("source")
                destination = mapping.get("destination")

                cur.execute("""
                    INSERT INTO attribute_mappings (scenario_id, source_field, destination_field)
                    VALUES (%s, %s, %s)
                    RETURNING id
                """, (scenario_id, source, destination))

                attribute_mapping_id = cur.fetchone()[0]

                # -----------------------------------
                # 8️⃣ Value mappings
                # JSON structure: Value Mapping is a DICT
                # -----------------------------------
                value_mapping = mapping.get("Value Mapping", {})

                if isinstance(value_mapping, dict):
                    for source_val, dest_val in value_mapping.items():

                        cur.execute("""
                            INSERT INTO value_mappings
                            (attribute_mapping_id, source_value, destination_value)
                            VALUES (%s, %s, %s)
                        """, (attribute_mapping_id, source_val, dest_val))

    conn.commit()
    cur.close()
    conn.close()

    print(f"Project {project_key} ({project_name}) under OEM {oem_name} ingested successfully.")
