from app.ingestion.ingest_config import ingest_program

ingest_program("data/programs/W61632023.json")
