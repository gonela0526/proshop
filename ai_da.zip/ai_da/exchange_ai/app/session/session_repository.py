import uuid
from datetime import datetime


# --------------------------------------------------
# Create Session
# --------------------------------------------------

def create_session(conn) -> str:
    session_id = str(uuid.uuid4())

    cur = conn.cursor()
    cur.execute("""
        INSERT INTO sessions (id, updated_at)
        VALUES (%s, %s);
    """, (session_id, datetime.utcnow()))

    conn.commit()
    cur.close()

    return session_id


# --------------------------------------------------
# Get Session
# --------------------------------------------------

def get_session(conn, session_id: str):

    cur = conn.cursor()
    cur.execute("""
        SELECT oem,
               project_key,
               process_name,
               last_query,
               pending_intent
        FROM sessions
        WHERE id = %s;
    """, (session_id,))

    row = cur.fetchone()
    cur.close()

    if not row:
        return None

    return {
        "oem": row[0],
        "project_key": row[1],
        "process_name": row[2],
        "last_query": row[3],
        "pending_intent": row[4]
    }


# --------------------------------------------------
# Update Session
# --------------------------------------------------

def update_session(conn, session_id: str,
                   oem=None,
                   project_key=None,
                   process_name=None,
                   last_query=None,
                   pending_intent=None):

    cur = conn.cursor()

    cur.execute("""
        UPDATE sessions
        SET oem = COALESCE(%s, oem),
            project_key = COALESCE(%s, project_key),
            process_name = COALESCE(%s, process_name),
            last_query = COALESCE(%s, last_query),
            pending_intent = COALESCE(%s, pending_intent),
            updated_at = %s
        WHERE id = %s;
    """, (
        oem,
        project_key,
        process_name,
        last_query,
        pending_intent,
        datetime.utcnow(),
        session_id
    ))

    conn.commit()
    cur.close()


def insert_feedback(conn, session_id, query, intent, feedback):

    cur = conn.cursor()

    cur.execute("""
        INSERT INTO response_feedback
        (session_id, query, intent, status, feedback)
        VALUES (%s, %s, %s, %s, %s)
    """, (
        session_id,
        query,
        intent,
        None,
        feedback
    ))

    conn.commit()
    cur.close()

