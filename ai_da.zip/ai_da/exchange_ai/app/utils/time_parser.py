from datetime import datetime, timedelta

def extract_time_range(query: str):

    query_lower = query.lower()
    now = datetime.now()

    if "today" in query_lower:
        start = now.replace(hour=0, minute=0, second=0, microsecond=0)
        end = now
        return start, end

    if "last 7 days" in query_lower:
        start = now - timedelta(days=7)
        return start, now

    if "this week" in query_lower:
        start = now - timedelta(days=now.weekday())
        start = start.replace(hour=0, minute=0, second=0, microsecond=0)
        return start, now

    return None, None
