from typing import Dict
from app.router.context_resolver import ContextResolver
from app.router.intent_classifier import IntentClassifier
from app.services.config_service import ConfigService
from app.exchange_history.service import ExchangeHistoryService
from app.session.session_service import SessionService


class QueryRouter:

    def __init__(self):
        self.resolver = ContextResolver()
        self.classifier = IntentClassifier()
        self.config_service = ConfigService()
        self.exchange_service = ExchangeHistoryService()
        self.session_service = SessionService()
    
    INTENT_REQUIREMENTS = {
        "schedule_query": ["project", "process"],
        "config_check": ["project", "process"],
        "filter_query": ["project", "process"],
        "mapping_query": ["project", "process"],
        "mapping_value_query": ["project", "process"],
        "defect_history_query": [],
        "failure_summary_query": [],
        "top_failure_reason_query": [],
        "global_health_query": [],
        "project_validation": ["project"]
    }



    # ==========================================================
    # MAIN ENTRY
    # ==========================================================

    def handle_query(self, session_id: str, query: str) -> Dict:

        print("---- HANDLE QUERY START ----")
        print("Session:", session_id)
        print("Query:", query)
        print("Session Data:", self.session_service.get_session(session_id))

        # ------------------------------------------------------
        # 1️⃣ HANDLE SELECTION EVENTS
        # ------------------------------------------------------

        if query.startswith("__select_oem__="):
            selected_oem = query.split("=")[1]

            self.session_service.update_context(
                session_id,
                new_oem=selected_oem
            )

            session_data = self.session_service.get_session(session_id)
            return self._resume_pending_execution(session_id, session_data)
        
        if query.startswith("__select_project__="):
            selected_project = query.split("=")[1]

            self.session_service.update_context(
                session_id,
                new_project=selected_project
            )

            print("AFTER PROJECT UPDATE:",
            self.session_service.get_session(session_id))

            session_data = self.session_service.get_session(session_id)
            return self._resume_pending_execution(session_id, session_data)

        if query.startswith("__select_process__="):
            selected_process = query.split("=")[1]

            self.session_service.update_context(
                session_id,
                new_process=selected_process
            )

            session_data = self.session_service.get_session(session_id)
            return self._resume_pending_execution(session_id, session_data)

        # ------------------------------------------------------
        # 2️⃣ STORE LAST QUERY
        # ------------------------------------------------------

        self.session_service.update_context(
            session_id,
            new_last_query=query
        )

        # ------------------------------------------------------
        # 3️⃣ RESOLVE CONTEXT
        # ------------------------------------------------------

        resolution = self.resolver.resolve(session_id, query)

        if "error" in resolution:
            return resolution

        context = resolution["context"]
        ambiguity = resolution["ambiguity"]

        # ------------------------------------------------------
        # 4️⃣ HANDLE AMBIGUITY
        # ------------------------------------------------------

        if ambiguity:

            intent_data = self.classifier.classify(query)

            if intent_data:
                self.session_service.update_context(
                    session_id,
                    new_pending_intent=intent_data["intent"]
                )

            return {
                "status": "clarification_required",
                "details": ambiguity,
                "session_id": session_id
            }

        # ------------------------------------------------------
        # 5️⃣ CLASSIFY INTENT
        # ------------------------------------------------------

        intent_data = self.classifier.classify(query)

        if not intent_data:
            return {
                "status": "unknown_intent",
                "message": "Unable to determine query intent.",
                "session_id": session_id
            }

        intent = intent_data["intent"]
        requires = intent_data.get("requires", [])

        # ------------------------------------------------------
        # 6️⃣ CHECK REQUIRED CONTEXT
        # ------------------------------------------------------

        missing = []

        if "project" in requires and not context.get("oem"):
            missing.append("oem")

        if "project" in requires and not context.get("project_key"):
            missing.append("project")

        if "process" in requires and not context.get("process_name"):
            missing.append("process")

        if missing:

            # Always store pending intent
            self.session_service.update_context(
                session_id,
                new_pending_intent=intent
            )

            # 🔴 STEP 1: OEM missing → ask OEM FIRST
            if not context.get("oem"):
                oems = self.config_service.list_oems()
                print("ASKING FOR OEM")
                return {
                    "status": "clarification_required",
                    "details": {
                        "oem_required": oems
                    },
                    "session_id": session_id
                }

            # 🟡 STEP 2: Project missing → ask project
            if "project" in missing:
                projects = self.config_service.list_projects_by_oem(
                    context.get("oem")
                )
                print("ASKING FOR PROJECT")
                return {
                    "status": "clarification_required",
                    "details": {
                        "project_required": projects
                    },
                    "session_id": session_id
                }

            # 🟢 STEP 3: Process missing → ask process
            if "process" in missing:
                processes = self.config_service.list_processes(
                    context.get("project_key")
                )
                print("ASKING FOR PROCESS")
                return {
                    "status": "clarification_required",
                    "details": {
                        "process_required": processes
                    },
                    "session_id": session_id
                }


        # ------------------------------------------------------
        # 7️⃣ EXECUTE
        # ------------------------------------------------------
        print("FINAL CONTEXT BEFORE EXECUTION:", context)

        return self._execute_intent(intent, context, query, session_id)

    # ==========================================================
    # RESUME LOGIC
    # ==========================================================

    def _resume_pending_execution(self, session_id: str, context: Dict):

        print("---- RESUME START ----")
        print("RESUME SESSION ID:", session_id)
        print("RESUME CONTEXT:", context)

        intent = context.get("pending_intent")
        query = context.get("last_query")

        print("RESUME INTENT:", intent)
        print("RESUME LAST QUERY:", query)


        if not intent:
            return {
                "status": "error",
                "message": "No pending intent to resume.",
                "session_id": session_id
            }

        requires = self.INTENT_REQUIREMENTS.get(intent, [])
        print("REQUIRED FIELDS:", requires)

        missing = []

        if "project" in requires and not context.get("project_key"):
            missing.append("project")

        if "process" in requires and not context.get("process_name"):
            missing.append("process")

        print("MISSING FIELDS:", missing)


        if missing:

            details = {}

            if "project" in missing:
                projects = self.config_service.list_projects_by_oem(context.get("oem"))
                details["project_required"] = projects

            if "process" in missing:
                processes = self.config_service.list_processes(context.get("project_key"))
                details["process_required"] = processes

            return {
                "status": "clarification_required",
                "details": details,
                "session_id": session_id
            }

        return self._execute_intent(intent, context, query, session_id)

    # ==========================================================
    # INTENT EXECUTION
    # ==========================================================

    def _execute_intent(self, intent: str, context: Dict, query: str, session_id: str):

        print("---- EXECUTING INTENT ----")
        print("INTENT:", intent)
        print("CONTEXT:", context)

        # Clear pending intent
        self.session_service.update_context(
            session_id,
            new_pending_intent=None
        )

        # ----------------------------
        # SCHEDULE
        # ----------------------------
        if intent == "schedule_query":
            result = self.config_service.get_schedule(
                context["project_key"],
                context["process_name"]
            )
            return self._standardize_response(result, intent, session_id)

        # ----------------------------
        # CONFIG
        # ----------------------------
        if intent == "config_check":
            result = self.config_service.get_config_value_by_query(
                context["project_key"],
                context["process_name"],
                query
            )
            return self._standardize_response(result, intent, session_id)

        if intent == "filter_query":
            result = self.config_service.get_filter_query(
                context["project_key"],
                context["process_name"]
            )
            return self._standardize_response(result, intent, session_id)
        # ----------------------------
        # MAPPING
        # ----------------------------
        if intent in ["mapping_query", "mapping_value_query"]:
            result = self.config_service.get_mapping_by_query(
                context["project_key"],
                context["process_name"],
                query
            )
            return self._standardize_response(result, intent, session_id)

        if intent == "mapping_list_query":
            result = self.config_service.get_all_mappings(
                context["project_key"]
            )
            return self._standardize_response(result, intent, session_id)

        # ----------------------------
        # EXCHANGE HISTORY
        # ----------------------------
        if intent == "defect_history_query":
            return self._standardize_response(self.exchange_service.get_history(query), intent, session_id)

        if intent == "failure_summary_query":
            return self._standardize_response(self.exchange_service.get_failure_summary(query), intent, session_id)

        if intent == "top_failure_reason_query":
            return self._standardize_response(self.exchange_service.get_top_failure_reasons(query), intent, session_id)

        if intent == "global_health_query":
            return self._standardize_response(self.exchange_service.get_global_health(), intent, session_id)
        if intent == "project_validation":
            return self._standardize_response({
                "status": "success",
                "project_key": context["project_key"]
            }, intent, session_id)

        # ----------------------------
        # FALLBACK
        # ----------------------------
        return self._standardize_response({
            "status": "unknown_intent",
            "message": "Intent not supported.",
            "session_id": session_id
        }, intent, session_id)
    

    def _standardize_response(self, result, intent, session_id):

        if isinstance(result, list):
            result = {"items": result}

        if not isinstance(result, dict):
            result = {"value": result}

        if "status" not in result:
            result = {
                "status": "success",
                "data": result
            }

        result["intent"] = intent
        result["session_id"] = session_id

        return result
    


    def handle_feedback(self, session_id: str, feedback: str):

        session_data = self.session_service.get_session(session_id)

        if not session_data:
            return {"status": "error", "message": "Invalid session."}

        query = session_data.get("last_query")
        intent = session_data.get("pending_intent")

        self.session_service.store_feedback(
            session_id=session_id,
            query=query,
            intent=intent,
            feedback=feedback
        )

        return {"status": "success"}


