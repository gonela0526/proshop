import re
from app.utils.defect_parser import extract_defect_ids


class IntentClassifier:

    def classify(self, query: str):

        if not query or not query.strip():
            return None

        query_lower = query.lower()

        # -------------------------------------------------
        # 1️⃣ DEFECT HISTORY (Highest Priority)
        # -------------------------------------------------

        defect_ids = extract_defect_ids(query)
        if defect_ids:
            return {
                "intent": "defect_history_query",
                "requires": [],
                "aggregation_allowed": False
            }

        # -------------------------------------------------
        # 2️⃣ TOP FAILURE REASONS
        # -------------------------------------------------

        if re.search(r"(top|most\s+common|highest|major)\s+(failure|error|issue)", query_lower):
            return {
                "intent": "top_failure_reason_query",
                "requires": [],
                "aggregation_allowed": True
            }

        # -------------------------------------------------
        # 3️⃣ FAILURE SUMMARY / HEALTH
        # -------------------------------------------------

        if re.search(r"(fail|error|issue|problem|unsync|not\s+sync|health)", query_lower):
            return {
                "intent": "failure_summary_query",
                "requires": [],
                "aggregation_allowed": True
            }

        # -------------------------------------------------
        # 4️⃣ GLOBAL HEALTH
        # -------------------------------------------------

        if re.search(r"(overall|system|exchange)\s+(health|status)", query_lower):
            return {
                "intent": "global_health_query",
                "requires": [],
                "aggregation_allowed": True
            }

        # -------------------------------------------------
        # 5️⃣ SCHEDULE
        # -------------------------------------------------

        if re.search(r"(schedule|timings|cron|run|execute|execution\s+time)", query_lower):
            return {
                "intent": "schedule_query",
                "requires": ["project", "process"],
                "aggregation_allowed": False
            }

        # -------------------------------------------------
        # 6️⃣ FILTER QUERY
        # -------------------------------------------------

        if re.search(r"(filter\s+query|jql|filter\s+used)", query_lower):
            return {
                "intent": "filter_query",
                "requires": ["project", "process"],
                "aggregation_allowed": False
            }

        # -------------------------------------------------
        # 7️⃣ MAPPING VALUE
        # -------------------------------------------------

        if re.search(r"\b(map|mapped|mapping|attribute|field\s+map)\b", query_lower):
            return {
                "intent": "mapping_value_query",
                "requires": ["project", "process"],
                "aggregation_allowed": False
            }

        # -------------------------------------------------
        # 8️⃣ MAPPING FIELD
        # -------------------------------------------------

        if re.search(r"(which\s+field|field\s+mapped|map\s+field|fields\s+used|attribute)", query_lower):
            return {
                "intent": "mapping_query",
                "requires": ["project", "process"],
                "aggregation_allowed": False
            }

        # -------------------------------------------------
        # 9️⃣ CONFIG CHECK
        # -------------------------------------------------

        if re.search(r"(enabled|transfer|attachment|comment|creation|sync)", query_lower):
            return {
                "intent": "config_check",
                "requires": ["project", "process"],
                "aggregation_allowed": False
            }

        # -------------------------------------------------
        # 🔟 PROJECT VALIDATION
        # -------------------------------------------------

        if re.search(r"(exist|available|present)", query_lower):
            return {
                "intent": "project_validation",
                "requires": ["project"],
                "aggregation_allowed": False
            }

        return None
