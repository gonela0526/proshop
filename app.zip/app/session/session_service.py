from app.db.connection import get_connection
from app.session import session_repository as repo


class SessionService:

    def create_session(self) -> str:
        conn = get_connection()
        try:
            return repo.create_session(conn)
        finally:
            conn.close()

    def get_session(self, session_id: str):
        conn = get_connection()
        try:
            return repo.get_session(conn, session_id)
        finally:
            conn.close()

    def update_context(self,
                       session_id: str,
                       new_oem=None,
                       new_project=None,
                       new_process=None,
                       new_last_query=None,
                       new_pending_intent=None,
                       new_last_response = None):

        conn = get_connection()

        try:
            current = repo.get_session(conn, session_id)

            if not current:
                return None

            oem = current["oem"]
            project = current["project_key"]
            process = current["process_name"]
            last_query = current.get("last_query")
            pending_intent = current.get("pending_intent")
            last_response = current.get("last_response")


            # ----------------------------
            # Context Policy Rules
            # ----------------------------

            if new_oem is not None and new_oem != oem:
                oem = new_oem
                project = None
                process = None

            if new_project is not None and new_project != project:
                project = new_project
                process = None

            if new_process is not None:
                process = new_process

            if new_last_query is not None:
                last_query = new_last_query

            if new_last_response is not None:
                last_response = new_last_response

            if new_pending_intent is not None:
                pending_intent = new_pending_intent


            repo.update_session(
                conn,
                session_id=session_id,
                oem=oem,
                project_key=project,
                process_name=process,
                last_query=last_query,
                pending_intent=pending_intent,
                last_response = last_response
            )

            return {
                "oem": oem,
                "project_key": project,
                "process_name": process,
                "last_query": last_query,
                "pending_intent": pending_intent,
                "last_response":last_response
            }

        finally:
            conn.close()

    def store_feedback(self, session_id: str, query: str, intent: str, feedback: str):

        conn = get_connection()
        try:
            repo.insert_feedback(
                conn,
                session_id,
                query,
                intent,
                feedback
            )
        finally:
            conn.close()

