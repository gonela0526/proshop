import re
from typing import List

def extract_defect_ids(text: str) -> List[str]:

    pattern = r"[A-Z]+[A-Z0-9]*-\d+"

    matches = re.findall(pattern, text.upper())

    # Deduplicate while preserving order
    seen = set()
    result = []

    for m in matches:
        if m not in seen:
            seen.add(m)
            result.append(m)

    return result
