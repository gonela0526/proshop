from app.ingestion.ingest_config import ingest_program

from app.db.connection import get_connection
from pathlib import Path

# Initialize connection
conn = get_connection()
conn.autocommit = False  # CRITICAL: Ensures a single transaction
json_dir = Path("/opt/AIDA/scripts/JSON")

try:
    # Use a single cursor for the entire batch
    with conn.cursor() as cur:
        for json_file in json_dir.glob("*.json"):
            print(f"Processing: {json_file.name}...")
            ingest_program(str(json_file), cur)
    
    # If we reached here, no errors occurred in any file.
    # We now swap the old data for the new data globally.
    conn.commit() 
    print("\n✅ Success! All data updated with zero downtime.")

except Exception as e:
    # If ANY file fails, we undo EVERYTHING.
    # The database stays exactly as it was before the script started.
    conn.rollback()
    print(f"\n❌ Error encountered: {e}")
    print("Transaction rolled back. No changes were made to the database.")

finally:
    conn.close()