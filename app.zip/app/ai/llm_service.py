import requests
import json
import re
from typing import Dict


class LLMService:

    def __init__(self):
        self.base_url = "http://10.138.90.99:11434/api/chat"
        self.model = "deepseek-coder-v2:latest"
        self.timeout = 15  # Safe timeout

    # ======================================================
    # SAFE LLM CALL
    # ======================================================

    def _call(self, prompt: str) -> str:
        try:
            response = requests.post(
                self.base_url,
                json={
                    "model": self.model,
                    "stream": False,
                    "messages": [
                        {"role": "system", "content": "You are a JSON-only assistant."},
                        {"role": "user", "content": prompt}
                    ]
                },
                timeout=self.timeout
            )

            if response.status_code != 200:
                return ""

            data = response.json()
            content = data.get("message", {}).get("content", "")

            # Clean markdown wrappers
            cleaned = re.sub(r"```json|```", "", content).strip()
            return cleaned

        except Exception:
            return ""

    # ======================================================
    # META INTENT CLASSIFICATION
    # ======================================================

    def classify_meta_intent(self, query: str) -> Dict:

        prompt = f"""
You are a routing classifier.

Return ONLY valid JSON.

Possible intents:
- transform_previous
- explain_previous
- summarize_previous
- none

Rules:
- If user refers to "above result", "previous result", "convert", "timezone",
  "explain this", "summarize this", choose appropriate meta intent.
- If user asks new business query like schedule, mapping, filter, config,
  choose "none".
- Never invent new intent names.

Return format:
{{
  "intent": "<intent_name>",
  "confidence": 0.0-1.0
}}

Query:
"{query}"
"""

        raw = self._call(prompt)

        if not raw:
            return {"intent": "none", "confidence": 0}

        try:
            parsed = json.loads(raw)
            return {
                "intent": parsed.get("intent", "none"),
                "confidence": float(parsed.get("confidence", 0))
            }
        except Exception:
            return {"intent": "none", "confidence": 0}

    # ======================================================
    # TRANSFORM PREVIOUS RESULT
    # ======================================================

    def transform_previous(self, previous_data: dict, user_query: str) -> str:

        prompt = f"""
You are an enterprise data assistant.

User request:
"{user_query}"

Previous structured result:
{json.dumps(previous_data, indent=2)}

Perform the requested transformation.

Rules:
- Do not invent fields.
- If converting timezone, convert properly.
- If summarizing, summarize clearly.
- If explaining, explain clearly.
- Return plain text only (no JSON).
"""

        result = self._call(prompt)

        return result if result else "Unable to transform previous result."
