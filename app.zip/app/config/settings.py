import os
from dotenv import load_dotenv

load_dotenv()

DB_CONFIG = {
    "dbname": os.getenv("DB_NAME"),
    "user": os.getenv("DB_USER"),
    "password": os.getenv("DB_PASSWORD"),
    "host": os.getenv("DB_HOST"),
    "port": os.getenv("DB_PORT")
}

ORACLE_DB_CONFIG ={
    "dsn": os.getenv("ORACLE_DSN"),
    "user": os.getenv("ORACLE_DB_USER"),
    "password": os.getenv("ORACLE_DB_PASSWORD"),
    "port": os.getenv("ORACLE_DB_PORT"),
    "path":os.getenv("ORACLE_DB_PATH_INSTANT_CLIENT")
}


PROD1_CONFIG = {
    "username": os.getenv("PROD1_USERNAME"),
    "password": os.getenv("PROD1_PASSWORD"),
    "trigger_url": os.getenv("PROD1_URL") + "/api/rest/v1/clientBean/addJob",
    "monitor_url": os.getenv("PROD1_URL") + "/api/rest/v1/clientBean/getJobStatus"
}


PROD2_CONFIG = {
    "username": os.getenv("PROD2_USERNAME"),
    "password": os.getenv("PROD2_PASSWORD"),
    "trigger_url": os.getenv("PROD2_URL") + "/api/rest/v1/clientBean/addJob",
    "monitor_url": os.getenv("PROD2_URL") + "/api/rest/v1/clientBean/getJobStatus"
}  