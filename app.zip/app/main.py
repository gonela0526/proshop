from fastapi import FastAPI, Body
from app.db.connection import get_connection
from app.session.session_service import SessionService
from app.exchange_trigger.trigger_service import TriggerService
from app.router.query_router import QueryRouter
from app.utils.logger import setup_logger
from typing import Optional,Union

logger = setup_logger()



session_service = SessionService()
router_instance = QueryRouter()
trigger_service = TriggerService()

app = FastAPI()

@app.get("/health")
def health_check():
    try:
        conn = get_connection()
        conn.close()
        return {"status": "ok"}
    except Exception as e:
        return {"status": "error", "details": str(e)}
    

@app.get("/create-session")
def create_session():
    return {"session_id": session_service.create_session()}


@app.post("/query")
def query(
    session_id: Optional[str] = Body(None),
    query: str = Body(...)
):
    # Create session if not provided
    if not session_id:
        session_id = session_service.create_session()

    result = router_instance.handle_query(session_id, query)

    # Always return session_id to frontend
    if isinstance(result, dict):
        result["session_id"] = session_id

    return result



@app.post("/feedback")
def store_feedback(
    session_id: str = Body(...),
    feedback: str = Body(...)
):
    return router_instance.handle_feedback(session_id, feedback)

# Add this above your /trigger endpoint in main.py
# main.py
@app.get("/trigger-options")
def get_trigger_options():
    # Replace these lists with your actual database query results
    processes_list = trigger_service.get_process_list()
    print("Processes for trigger options:", processes_list)  # Debugging log

    oems = processes_list.get("oems", [])
    projects = processes_list.get("projects", [])
    processes = processes_list.get("processes", [])
    
    

    return {
       "oems": oems,
       "projects": projects,
       "processes": processes
    }

@app.post("/trigger")
def trigger_exchange(
    oemId: str = Body(...),
    projectId: str = Body(...),
    process: dict = Body(...),
    defectIds: Optional[Union[str,list]] = Body(None)
):
    # Debugging logs
    print(f"Received trigger request for oemId: {oemId}, projectId: {projectId}, process: {process}")
    print(f"Defect IDs received: {defectIds}")
    processName = process.get("name") if isinstance(process, dict) else str(process)
    return trigger_service.trigger(oemId, projectId, process, defectIds)