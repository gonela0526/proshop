def insert_query_audit(conn, session_id, query, intent, execution_path, status, processing_time):
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO query_audit (
            session_id,
            query,
            detected_intent,
            execution_path,
            status,
            processing_time
        )
        VALUES (%s, %s, %s, %s, %s, %s)
    """, (
        session_id,
        query,
        intent,
        execution_path,
        status,
        processing_time
    ))
    conn.commit()
    cur.close()
