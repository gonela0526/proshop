from app.config.settings import ORACLE_DB_CONFIG
import oracledb

def get_connection():
    
    # Initialize thick mode only if Instant Client path is provided
    lib_path = ORACLE_DB_CONFIG.get("path")
    if lib_path:
        oracledb.init_oracle_client(lib_dir=lib_path)

    # Create and return the connection
    return oracledb.connect(
        user=ORACLE_DB_CONFIG.get("user"),
        password=ORACLE_DB_CONFIG.get("password"),
        dsn=ORACLE_DB_CONFIG.get("dsn")
    )
