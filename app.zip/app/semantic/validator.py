import re

ALLOWED_INTENTS = {
    "defect_history_query",
    "failure_summary_query",
    "top_failure_reason_query",
    "schedule_query",
    "mapping_query",
    "config_query",
    "unknown"
}

ALLOWED_TIME_FILTERS = {
    "today",
    "last_7_days",
    "this_week",
    "none"
}

def validate_semantic_output(data: dict):

    if not isinstance(data, dict):
        return None

    intent = data.get("intent")
    if intent not in ALLOWED_INTENTS:
        return None

    project_key = data.get("project_key")
    # Do not validate format here.
    # Existence will be validated in router.


    direction = data.get("direction")
    if direction is not None and not re.match(r"^\w+to\w+$", direction):
        return None

    time_filter = data.get("time_filter")
    if time_filter not in ALLOWED_TIME_FILTERS:
        return None

    return data
