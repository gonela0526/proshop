import json
import re
import requests


class SemanticParser:

    def __init__(self, model="deepseek-coder-v2:latest"):
        self.model = model
        self.url = "http://10.138.90.99:11434/v1"

    def parse(self, query: str):

        prompt = f"""
    You are a strict JSON parser.

    Return ONLY a valid JSON object with fields:
    intent, project_key, direction, time_filter.

    Allowed intents:
    defect_history_query
    failure_summary_query
    top_failure_reason_query
    schedule_query
    mapping_query
    config_query
    unknown

    If query contains ABC-123 or 123 → defect_history_query.
    If query contains issues/problems/failures → failure_summary_query.
    If query contains recently/lately → last_7_days.
    If no time mentioned → none.

    Do NOT invent values.
    Use null if project_key or direction not present.

    Query: {query}
    """

        try:
            response = requests.post(
            "http://10.138.90.99:11434/v1/api/chat",
            json={
                "model": self.model,
                "messages": [
                    {
                        "role": "system",
                        "content": "Respond ONLY with valid JSON. No explanations."
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                "stream": False,
                "options": {
                    "temperature": 0,
                    "num_predict": 150
                }
            },
            timeout=30
        )

            raw_text = response.json()["message"]["content"]

            print("RAW LLM OUTPUT:", raw_text)
        except Exception as e:
            print("Semantic parser error:", e)
            return {"intent": "unknown"}

        try:
            parsed = json.loads(raw_text)
            return parsed
        except:
            return {"intent": "unknown"}
