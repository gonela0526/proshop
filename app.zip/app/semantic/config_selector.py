import requests
import json

OLLAMA_URL = "http://10.138.90.99:11434/v1/api/chat"
MODEL_NAME = "deepseek-coder-v2:latest"  # use your actual model


def select_config_key_via_llm(query: str, config_keys: list):

    print("LLM CONFIG SELECTOR CALLED")

    if not config_keys:
        return None

    # Build numbered list
    key_list = "\n".join([f"{i+1}. {key}" for i, key in enumerate(config_keys)])

    prompt = f"""
You are a strict config key selector.

You must choose ONE config key from the provided list.

Rules:
- Return ONLY the exact config key name.
- Do NOT explain.
- Do NOT modify spelling.
- If none match, return NONE.

Config Keys:
{key_list}

User Query:
"{query}"
"""

    try:
        response = requests.post(
            OLLAMA_URL,
            json={
                "model": MODEL_NAME,
                "messages": [
                    {"role": "user", "content": prompt}
                ],
                "temperature": 0,
                "stream":False
            },
            timeout=20
        )

        data = response.json()
        print("LLM RAW JSON:", data)

        raw_text = None

        # Handle both possible formats
        if "message" in data and "content" in data["message"]:
            raw_text = data["message"]["content"].strip()
        elif "response" in data:
            raw_text = data["response"].strip()

        if not raw_text:
            print("LLM returned empty content")
            return None

        print("LLM RAW OUTPUT:", raw_text)

        cleaned = raw_text.replace('"', '').replace("`", "").strip()

        # Exact match
        if cleaned in config_keys:
            return cleaned

        # Substring match
        for key in config_keys:
            if key.lower() in cleaned.lower():
                return key

        return None

    except Exception as e:
        print("LLM CONFIG SELECTOR ERROR:", e)
        return None

