import json
from pathlib import Path
from app.rag import query

def main():
    cases=json.loads(Path(__file__).with_name("evaluation_questions.json").read_text())
    for c in cases:
        r=query(c["question"],top_k=4,hybrid=True); answer=r["answer"].lower()
        evidence=" ".join(x.get("content","") for x in r["retrieved_chunks"]).lower()
        if c["answerable"]: ok=any(k.lower() in (answer+" "+evidence) for k in c["keywords"])
        else: ok=any(p in answer for p in ["does not specify","not specified","not provided","cannot determine","not available","unable to find"])
        print(f"{'PASS' if ok else 'REVIEW'} {c['id']}: {c['question']}\nAnswer: {r['answer']}\n")
    print("Starter heuristic only. Review retrieval and answers manually; this is not a full accuracy metric.")
if __name__=="__main__": main()
