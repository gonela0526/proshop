from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from app.db import init_db, connect
from app.ingest import ingest
from app.rag import query
app=FastAPI(title="Insurance Policy RAG Demo",description="PDF ingestion + pgvector retrieval + Ollama grounded Q&A")
class QueryRequest(BaseModel):
    question:str=Field(min_length=1); top_k:int=Field(default=4,ge=1,le=15); hybrid:bool=True; source_name:str|None=None; show_context:bool=True
class IngestRequest(BaseModel): pdf_path:str
@app.on_event("startup")
def startup(): init_db()
@app.get("/health")
def health():
    try:
        with connect() as db: n=db.execute("SELECT count(*) AS n FROM rag_chunks").fetchone()["n"]
        return {"status":"ok","indexed_chunks":n}
    except Exception as e: raise HTTPException(503,str(e))
@app.post("/ingest")
def do_ingest(req:IngestRequest):
    try: return ingest(req.pdf_path)
    except Exception as e: raise HTTPException(400,str(e))
@app.post("/query")
def do_query(req:QueryRequest):
    try:
        r=query(req.question,req.top_k,req.hybrid,req.source_name)
        if not req.show_context:
            r.pop("context_sent_to_llm",None)
            for c in r.get("retrieved_chunks",[]): c.pop("content",None)
        return r
    except Exception as e: raise HTTPException(500,str(e))
@app.get("/documents")
def documents():
    with connect() as db:
        rows=db.execute("SELECT source_name,source_id,count(*) AS chunks,min(page_number) AS first_page,max(page_number) AS last_page,max(created_at) AS indexed_at FROM rag_chunks GROUP BY source_name,source_id ORDER BY indexed_at DESC").fetchall()
    return {"documents":[dict(x) for x in rows]}
@app.get("/chunks")
def chunks_endpoint(limit:int=10):
    limit=max(1,min(limit,100))
    with connect() as db: rows=db.execute("SELECT id,source_name,chunk_index,page_number,content,metadata FROM rag_chunks ORDER BY chunk_index LIMIT %s",(limit,)).fetchall()
    return {"chunks":[dict(x) for x in rows]}
