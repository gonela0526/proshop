import psycopg
from psycopg.rows import dict_row
from app.config import DATABASE_URL, DIM

def connect(): return psycopg.connect(DATABASE_URL, row_factory=dict_row)
def init_db():
    with connect() as c:
        c.execute("CREATE EXTENSION IF NOT EXISTS vector")
        c.execute(f"""CREATE TABLE IF NOT EXISTS rag_chunks (
          id BIGSERIAL PRIMARY KEY, source_id TEXT NOT NULL, source_name TEXT NOT NULL,
          content_hash TEXT NOT NULL, chunk_index INT NOT NULL, content TEXT NOT NULL,
          page_number INT, metadata JSONB NOT NULL DEFAULT '{{}}'::jsonb,
          embedding vector({DIM}) NOT NULL,
          search_tsv tsvector GENERATED ALWAYS AS (to_tsvector('english', coalesce(content,''))) STORED,
          UNIQUE(source_id, chunk_index))""")
        c.execute("CREATE INDEX IF NOT EXISTS rag_chunks_tsv_idx ON rag_chunks USING GIN(search_tsv)")
        c.execute("CREATE INDEX IF NOT EXISTS rag_chunks_source_idx ON rag_chunks(source_id)")
