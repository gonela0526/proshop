from app.db import init_db, connect
from app.ollama import embed
from app.ingest import vec

def vector_search(question, top_k=4, source_name=None):
    init_db(); qv=vec(embed(question))
    with connect() as db:
        rows=db.execute("""SELECT id,source_name,source_id,chunk_index,content,page_number,metadata,
          (embedding <=> %s::vector) AS distance FROM rag_chunks
          WHERE (%s IS NULL OR source_name=%s) ORDER BY embedding <=> %s::vector LIMIT %s""",
          (qv,source_name,source_name,qv,top_k)).fetchall()
    out=[]
    for r in rows:
        d=dict(r); dist=float(d.pop("distance")); d["score"]=1-dist; d["retrieval_method"]="vector"; out.append(d)
    return out

def keyword_search(question, top_k=8, source_name=None):
    init_db()
    with connect() as db:
        rows=db.execute("""SELECT id,source_name,source_id,chunk_index,content,page_number,metadata,
          ts_rank_cd(search_tsv,websearch_to_tsquery('english',%s)) AS rank FROM rag_chunks
          WHERE search_tsv @@ websearch_to_tsquery('english',%s) AND (%s IS NULL OR source_name=%s)
          ORDER BY rank DESC LIMIT %s""",(question,question,source_name,source_name,top_k)).fetchall()
    out=[]
    for r in rows:
        d=dict(r); d["score"]=float(d.pop("rank") or 0); d["retrieval_method"]="keyword"; out.append(d)
    return out

def hybrid_search(question, top_k=4, source_name=None):
    # Reciprocal Rank Fusion avoids adding incompatible vector-distance and text-rank scores.
    a=vector_search(question,max(top_k*3,8),source_name); b=keyword_search(question,max(top_k*3,8),source_name)
    merged={}; k=60
    for items,method in ((a,"vector"),(b,"keyword")):
        for rank,item in enumerate(items,1):
            key=item["id"]
            if key not in merged: merged[key]={**item,"rrf_score":0.0,"retrieval_methods":[]}
            merged[key]["rrf_score"]+=1/(k+rank); merged[key]["retrieval_methods"].append(method)
    result=sorted(merged.values(),key=lambda x:x["rrf_score"],reverse=True)[:top_k]
    for x in result: x["score"]=x["rrf_score"]; x["retrieval_method"]="hybrid"
    return result
