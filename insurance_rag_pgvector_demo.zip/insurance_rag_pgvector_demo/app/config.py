import os
from dotenv import load_dotenv
load_dotenv()
DATABASE_URL=os.getenv("DATABASE_URL","postgresql://rag:ragpass@localhost:5432/insurance_rag")
OLLAMA_BASE_URL=os.getenv("OLLAMA_BASE_URL","http://localhost:11434").rstrip("/")
CHAT_MODEL=os.getenv("OLLAMA_CHAT_MODEL","qwen2.5:7b")
EMBED_MODEL=os.getenv("OLLAMA_EMBED_MODEL","nomic-embed-text")
DIM=int(os.getenv("EMBEDDING_DIMENSION","768"))
CHUNK_SIZE=int(os.getenv("CHUNK_SIZE","900"))
CHUNK_OVERLAP=int(os.getenv("CHUNK_OVERLAP","150"))
