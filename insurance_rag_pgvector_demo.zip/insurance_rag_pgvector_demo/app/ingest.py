import argparse, hashlib, json
from pathlib import Path
from pypdf import PdfReader
from app.db import init_db, connect
from app.chunking import chunks
from app.ollama import embed
from app.config import DIM

def vec(v): return "["+",".join(str(float(x)) for x in v)+"]"
def ingest(pdf):
    path=Path(pdf)
    if not path.exists(): raise FileNotFoundError(path)
    init_db(); reader=PdfReader(str(path)); sha=hashlib.sha256(path.read_bytes()).hexdigest(); source_id=sha
    pages=[]
    for n,p in enumerate(reader.pages,1):
        t=(p.extract_text() or "").strip()
        if t: pages.append((n,t))
    if not pages: raise ValueError("No text extracted. Scanned PDFs need OCR.")
    records=[]
    for page,text in pages:
        for c in chunks(text): records.append((page,c))
    with connect() as db:
        # Remove old version(s) with same filename, then store this content hash.
        db.execute("DELETE FROM rag_chunks WHERE source_name=%s",(path.name,))
        for i,(page,content) in enumerate(records):
            v=embed(content)
            if len(v)!=DIM: raise ValueError(f"Embedding has {len(v)} dims but configured DIM={DIM}. Update .env and recreate table.")
            meta={"page_number":page,"document_type":"insurance_policy","policy_reference":"HCE-SAMPLE-2026-001"}
            db.execute("""INSERT INTO rag_chunks(source_id,source_name,content_hash,chunk_index,content,page_number,metadata,embedding)
                VALUES(%s,%s,%s,%s,%s,%s,%s::jsonb,%s::vector)""",
                (source_id,path.name,sha,i,content,page,json.dumps(meta),vec(v)))
    return {"source_name":path.name,"sha256":sha,"pages_with_text":len(pages),"chunks_inserted":len(records)}

if __name__=="__main__":
    ap=argparse.ArgumentParser(); ap.add_argument("--pdf",required=True); args=ap.parse_args()
    print(json.dumps(ingest(args.pdf),indent=2))
