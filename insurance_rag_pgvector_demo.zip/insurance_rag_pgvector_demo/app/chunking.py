import re
from app.config import CHUNK_SIZE, CHUNK_OVERLAP

def chunks(text, size=CHUNK_SIZE, overlap=CHUNK_OVERLAP):
    text=re.sub(r"[ \t]+"," ",text); text=re.sub(r"\n{3,}","\n\n",text).strip()
    if not text: return []
    # Paragraph-aware grouping, with a character window fallback for long paragraphs.
    paras=[p.strip() for p in re.split(r"\n\s*\n",text) if p.strip()]
    pieces=[]
    for p in paras:
        if len(p)<=size: pieces.append(p)
        else: pieces.extend(p[i:i+size] for i in range(0,len(p),size-overlap))
    out=[]; cur=""
    for p in pieces:
        cand=(cur+"\n\n"+p).strip() if cur else p
        if len(cand)<=size: cur=cand
        else:
            if cur: out.append(cur)
            prefix=cur[-overlap:] if cur and overlap else ""
            cur=(prefix+"\n\n"+p).strip() if prefix else p
            if len(cur)>size+overlap: cur=cur[-(size+overlap):]
    if cur: out.append(cur)
    return [x for x in out if x.strip()]
