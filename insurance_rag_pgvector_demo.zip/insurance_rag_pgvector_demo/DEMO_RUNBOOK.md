# Live demo runbook (15–20 minutes)

1. Ingest the PDF with `python -m app.ingest --pdf data/sample_insurance_policy_for_rag_demo.pdf`.
2. Open `/docs`; show `GET /documents` and `GET /chunks` to explain ingestion and chunk metadata.
3. Ask `What is the annual sum insured?` and inspect retrieved passages.
4. Ask `Does the initial waiting period apply to accidents?` to show condition-based answer generation.
5. Ask `Are routine dental treatments covered?` to show exclusions and exceptions.
6. Ask `What is the monthly premium?` to demonstrate abstention for missing information.
7. Compare `hybrid=true` with `hybrid=false`, and change `top_k` from 2 to 6.
8. Run `python -m app.evaluate` as a lightweight regression check.

Talking points: ingestion and querying are separate; vectors are created for both chunks and queries; PostgreSQL `<=>` is cosine distance; hybrid retrieval uses reciprocal rank fusion; inspect retrieved evidence before changing the prompt; RAG does not guarantee correctness; enforce access control before retrieval in real applications.
