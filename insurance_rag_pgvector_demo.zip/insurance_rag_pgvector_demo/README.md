# Insurance Policy RAG Demo

Python + FastAPI + PostgreSQL/pgvector + Ollama. Training-only implementation for the fictional HorizonCare sample policy.

## Setup
1. Copy `sample_insurance_policy_for_rag_demo.pdf` from the conversation into `data/sample_insurance_policy_for_rag_demo.pdf`.
2. Start PostgreSQL: `docker compose up -d`
3. Create a venv and install: `pip install -r requirements.txt`
4. Ensure Ollama is running, then run `ollama pull qwen2.5:7b` and `ollama pull nomic-embed-text`.
5. Copy `.env.example` to `.env` if you need to change defaults.
6. Ingest: `python -m app.ingest --pdf data/sample_insurance_policy_for_rag_demo.pdf`
7. Run API: `uvicorn app.main:app --reload`; open http://127.0.0.1:8000/docs
8. Run starter evaluation: `python -m app.evaluate`

## Demo sequence
- `GET /documents` and `GET /chunks` show the indexed PDF and extracted chunks.
- `POST /query` with `What is the annual sum insured?`
- Ask `Does the initial waiting period apply to accidents?`
- Ask `Are routine dental treatments covered?`
- Ask `What is the monthly premium?` to demonstrate abstention when the document is silent.
- Toggle hybrid retrieval off/on and change top_k to compare results.

The PDF is not bundled. Download it from the conversation and copy it into `data/`.

## Notes
Uses `nomic-embed-text` (768 dimensions) for embeddings and `qwen2.5:7b` for answer generation. If you change the embedding model/dimension, recreate the table and re-ingest all documents. The hybrid search uses reciprocal rank fusion, not direct addition of incomparable vector and keyword scores. This is a teaching demo, not a real insurance decision system. Enforce access controls and validate outputs before any production use.
