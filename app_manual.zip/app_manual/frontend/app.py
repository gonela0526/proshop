import chainlit as cl
import requests
import websockets
import asyncio
import json

BACKEND_URL = "http://localhost:8080"
WS_URL = "ws://localhost:8080"


@cl.on_chat_start
async def start():

    await cl.Message(
        content="Process Dashboard",
        actions=[
            cl.Action(
                name="start_process",
                label="Start Process",
                payload={}
            )
        ]
    ).send()


# @cl.action_callback("start_process")
# async def start_process(action):

#     settings = await cl.ChatSettings(
#         [
#             cl.input_widget.TextInput(
#                 id="configset",
#                 label="Config Set"
#             ),
#             cl.input_widget.TextInput(
#                 id="process",
#                 label="Process Name"
#             )
#         ]
#     ).send()

#     response = requests.post(
#         f"{BACKEND_URL}/process/start",
#         json={
#             "configset_name":
#                 settings["configset"],
#             "process_name":
#                 settings["process"]
#         }
#     )

#     job_id = response.json()["job_id"]

#     asyncio.create_task(
#         listen(job_id)
#     )


@cl.action_callback("start_process")
async def start_process(action):

    configset_response = await cl.AskUserMessage(
        content="Enter Config Set Name",
        timeout=300
    ).send()

    process_response = await cl.AskUserMessage(
        content="Enter Process Name",
        timeout=300
    ).send()

    configset = configset_response["output"]
    process = process_response["output"]

    response = requests.post(
        f"{BACKEND_URL}/process/start",
        json={
            "configset_name": configset,
            "process_name": process
        }
    )

    print(response.text)

    if response.status_code != 200:
        await cl.Message(
            content=f"Backend Error:\n{response.text}"
        ).send()
        return

    job_id = response.json()["job_id"]

    await cl.Message(
        content=f"Started Job: {job_id}"
    ).send()

    asyncio.create_task(listen(job_id))




async def listen(job_id):

    message = cl.Message(
        content="Waiting..."
    )

    await message.send()

    async with websockets.connect(
        f"{WS_URL}/ws/{job_id}"
    ) as ws:
        
        async for payload in ws:
            data = json.loads(payload)

            message.content = f"""
Job : {job_id}

Status : {data['status']}

Progress : {data['progress']}%
"""

            await message.update()

            if data["status"] == "COMPLETED":

                await cl.Message(
                    content="🎉 Finished"
                ).send()

                break