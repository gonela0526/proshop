import asyncio


async def start_external_process(
        configset,
        process):

    return {
        "execution_id":
            f"{configset}_{process}"
    }


async def get_process_status(
        execution_id,
        progress):

    await asyncio.sleep(2)

    progress += 10

    return {
        "status":
            "RUNNING"
            if progress < 100
            else "COMPLETED",
        "progress": progress
    }