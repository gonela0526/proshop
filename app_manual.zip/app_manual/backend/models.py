from enum import Enum
from pydantic import BaseModel


class ProcessStatus(str, Enum):
    STARTED = "STARTED"
    RUNNING = "RUNNING"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"


class ProcessRequest(BaseModel):
    configset_name: str
    process_name: str


class ProcessUpdate(BaseModel):
    job_id: str
    status: ProcessStatus
    progress: int
    message: str = ""