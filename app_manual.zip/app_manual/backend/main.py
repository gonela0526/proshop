from uuid import uuid4

from fastapi import (
    FastAPI,
    WebSocket,
    WebSocketDisconnect
)

from models import ProcessRequest
from connection_manager import (
    ConnectionManager
)
from process_service import (
    ProcessService
)

app = FastAPI()

manager = ConnectionManager()

process_service = ProcessService(
    manager
)


@app.post("/process/start")
async def start_process(
        request: ProcessRequest):

    job_id = str(uuid4())

    await process_service.start_process(
        job_id,
        request.configset_name,
        request.process_name
    )

    return {
        "job_id": job_id
    }


@app.websocket("/ws/{job_id}")
async def websocket_endpoint(
        websocket: WebSocket,
        job_id: str):

    await manager.connect(
        job_id,
        websocket
    )

    try:

        while True:
            await websocket.receive_text()

    except WebSocketDisconnect:

        manager.disconnect(
            job_id,
            websocket
        )