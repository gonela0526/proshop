import asyncio

from process_store import jobs
from external_client import (
    start_external_process,
    get_process_status
)


class ProcessService:

    def __init__(self, manager):
        self.manager = manager

    async def start_process(
            self,
            job_id,
            configset,
            process):

        jobs[job_id] = {
            "status": "STARTED",
            "progress": 0
        }

        asyncio.create_task(
            self.monitor_process(
                job_id,
                configset,
                process
            )
        )

    async def monitor_process(
            self,
            job_id,
            configset,
            process):

        execution = await start_external_process(
            configset,
            process
        )

        execution_id = execution[
            "execution_id"
        ]

        progress = 0

        while True:

            status_response = (
                await get_process_status(
                    execution_id,
                    progress
                )
            )

            progress = (
                status_response["progress"]
            )

            jobs[job_id] = {
                "job_id": job_id,
                "status":
                    status_response["status"],
                "progress": progress
            }

            await self.manager.broadcast(
                job_id,
                jobs[job_id]
            )

            if (
                status_response["status"]
                == "COMPLETED"
            ):
                break

            await asyncio.sleep(5)