from dataclasses import dataclass
from typing import List
from app.jiraOAuth.schema import JiraProject


@dataclass
class AuthorizationContext:

    email: str

    jira_account_id: str

    project_ids: List[int]

    project_keys: List[str]

    oem_ids: List[int]

    projects: List[JiraProject]
    session_id: str