from app.auth.repository import AuthRepository
from app.jiraOAuth.client import JiraClient


class AuthService:

    def __init__(self):

        self.repository = AuthRepository()

    async def start_authentication(self):
        state = self.repository.create_request()

        authorization_url = JiraClient.get_authorization_url(
            state
        )

        return authorization_url