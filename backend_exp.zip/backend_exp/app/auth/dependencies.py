from fastapi import HTTPException
from fastapi import Request

from app.access.service import AccessService
from app.auth.schema import AuthorizationContext
from app.userSession.service import UserSessionService


access_service = AccessService()
session_service = UserSessionService()


async def get_authorization_context(
    request: Request,
) -> AuthorizationContext:

    session_id = request.cookies.get(
        "AIDA_SESSION"
    )

    if session_id is None:
        raise HTTPException(
            status_code=401,
            detail="Authentication required."
        )

    session = session_service.validate_session(
        session_id
    )

    if session is None:
        raise HTTPException(
            status_code=401,
            detail="Invalid session."
        )

    return await access_service.build_authorization_context(
        session_id=session_id
    )