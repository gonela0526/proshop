import uuid

from app.db.connection import get_pg_connection

class AuthRepository:

    def create_request(self):

        state = str(uuid.uuid4())

        with get_pg_connection() as conn:
            try:
                cursor = conn.cursor()
                cursor.execute(
                    """
                    INSERT INTO oauth_requests
                    (
                        state
                    )
                    VALUES
                    (
                        %s
                    )
                    """,
                    (
                        state,
                    )
                )

                conn.commit()
            
            finally:
                cursor.close()
                conn.close() 
        
        return state
    
    def get_request(self, state: str):

        with get_pg_connection() as conn:
            try:
                cursor = conn.cursor()
                cursor.execute(
                    """
                    SELECT
                        state
                    FROM oauth_requests
                    WHERE state=%s
                    """,
                    (state,)
                )

                row = cursor.fetchone()

                if row is None:
                    return None
            finally:
                cursor.close()
                conn.close()
        
        return True


    def delete_request(self, state: str):

        with get_pg_connection() as conn:
            try:
                cursor = conn.cursor()
                cursor.execute(
                    """
                    DELETE
                    FROM oauth_requests
                    WHERE state=%s
                    """,
                    (state,)
                )

                conn.commit()
            finally:
                cursor.close()
                conn.close()
        