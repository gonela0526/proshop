"""
AIDA Unified Tools
==================
LangChain @tool-decorated functions that the router LLM can call.

Design principle:
  Each tool returns a STRUCTURED TEXT BLOCK — not a raw Python dict.
  This gives the synthesizer LLM much cleaner input and produces far more
  natural, readable responses. Labels are human-readable so the synthesizer
  doesn't need to know field names.

Context injection:
  The tool_node in workflow.py auto-injects oem / project_key / process_name /
  timezone from AgentState into any tool call where the LLM omitted them.
  So tools can declare these as parameters with default=None safely.
"""

from typing import Optional, Dict, Any
from langchain_core.tools import tool
from app.services.config_service import ConfigService
from app.exchange_history.service import ExchangeHistoryService
from app.utils.jql_parser import explain_jql, audit_jql

config_service = ConfigService()
exchange_service = ExchangeHistoryService()


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def _fmt(label: str, value) -> str:
    """Format a single label-value pair for inclusion in a text block."""
    return f"{label}: {value}" if value is not None else f"{label}: N/A"


def _header(title: str, oem=None, project=None, process=None) -> str:
    ctx = " | ".join(filter(None, [oem, project, process]))
    return f"=== {title} ===\nContext: {ctx or 'not specified'}"


# ─────────────────────────────────────────────────────────────────────────────
# Tool 1 — Schedule
# ─────────────────────────────────────────────────────────────────────────────

@tool
def get_schedule_tool(
    project_key: Optional[str] = None,
    process_name: Optional[str] = None,
    oem: Optional[str] = None,
    timezone: str = "America/New_York",
) -> str:
    """
    Retrieves the execution schedule (cron + upcoming run times) for a specific
    project and process.

    Args:
        project_key (str): The project key identifier (e.g. "P702_RCB").
        process_name (str): The specific process name (e.g. "Ford2Visteon_P708RCB").
        oem (str, optional): The OEM name for context (e.g. "FORD").
        timezone (str): User's local timezone — defaults to America/New_York.
    """
    raw = config_service.get_schedule(project_key, process_name, timezone)

    if not raw or raw.get("status") == "not_found":
        return (
            f"{_header('SCHEDULE RESULT', oem, project_key, process_name)}\n"
            f"Status: NOT FOUND\n"
            f"Message: No schedule configured for this project and process."
        )

    lines = [_header("SCHEDULE RESULT", oem or raw.get("oem"), project_key, process_name)]
    
    # We only output the schedule translated to the USER'S timezone to avoid confusion.
    # We deliberately hide the raw cron expression and the backend's EDT time.
    local_schedule = raw.get("local_schedule") or raw.get("readable_schedule")
    lines.append(f"Schedule ({timezone}): {local_schedule}")

    next_runs = raw.get("next_runs") or []
    if next_runs:
        lines.append("\nNext Upcoming Runs:")
        for i, run in enumerate(next_runs[:5], 1):
            lines.append(f"  {i}. {run}")

    return "\n".join(lines)


# ─────────────────────────────────────────────────────────────────────────────
# Tool 2 — Mappings
# ─────────────────────────────────────────────────────────────────────────────

@tool
def get_mappings_tool(
    project_key: Optional[str] = None,
    process_name: Optional[str] = None,
    oem: Optional[str] = None,
    mapping_type: str = "field",
    field_name: Optional[str] = None,
) -> str:
    """
    Retrieves the field or value mapping configurations for a specific project
    and process.

    Args:
        project_key (str): The project key identifier.
        process_name (str): The specific process name.
        oem (str, optional): OEM name for context.
        mapping_type (str): "field" to get attribute mappings, "value" for
                            value-level mappings. Defaults to "field".
        field_name (str, optional): The specific field to look up mappings for
                                     (e.g. "severity", "priority"). Extracted
                                     from the user's query.
    """
    # Build query_text that includes the field name so get_mapping_by_query
    # can match the correct field in the DB via token intersection.
    if field_name:
        query_text = f"{field_name} {'value mapping' if mapping_type == 'value' else 'field mapping'}"
    else:
        query_text = "field mapping" if mapping_type == "field" else "value mapping"
    raw = config_service.get_mapping_by_query(
        oem_name=oem or "",
        project_key=project_key,
        process_name=process_name,
        query=query_text,
    )

    if not raw or raw.get("status") in ("not_found", None):
        # Differentiate message for value vs field
        if mapping_type == "value":
            return (
                f"{_header('MAPPING RESULT', oem, project_key, process_name)}\n"
                f"Status: NO VALUE MAPPINGS\n"
                f"Message: No value-level mappings found for this process. "
                f"Note: not every field has value mappings configured — value mappings only exist when specific source values need to be translated to different destination values."
            )
        return (
            f"{_header('MAPPING RESULT', oem, project_key, process_name)}\n"
            f"Status: NOT FOUND\n"
            f"Message: {raw.get('message', 'No mappings found.')}"
        )

    lines = [_header(f"MAPPING RESULT ({mapping_type.upper()})", oem, project_key, process_name)]

    # Field mappings
    if raw.get("field") and raw.get("results"):
        lines.append(f"Field: {raw['field']}")
        for proj, processes in raw["results"].items():
            for proc, scenarios in processes.items():
                lines.append(f"\nProcess: {proc}")
                for scenario, mappings in scenarios.items():
                    lines.append(f"  Scenario: {scenario}")
                    lines.append("| Source Field | Destination Field |")
                    lines.append("| :--- | :--- |")
                    for m in mappings:
                        src = m.get("source_field") or "—"
                        dst = m.get("destination_field") or "—"
                        lines.append(f"| {src} | {dst} |")

    # Value mappings
    elif raw.get("values"):
        for scenario_name, scenario_data in raw["values"].items():
            lines.append(f"\n🎬 Scenario: {scenario_name}")
            src_fields = scenario_data.get("source_fields", {})
            dst_fields = scenario_data.get("destination_fields", {})
            for sf_name, sv_list in src_fields.items():
                df_name = list(dst_fields.keys())[0] if dst_fields else "N/A"
                dv_list = dst_fields.get(df_name, [])
                lines.append(f"Field Mapping: {sf_name} ➔ {df_name}")
                lines.append("| Source Value | Destination Value |")
                lines.append("| :--- | :--- |")
                for sv, dv in zip(sv_list, dv_list):
                    lines.append(f"| {sv} | {dv} |")

    # Summary mappings
    elif raw.get("mappings"):
        for scenario, items in raw["mappings"].items():
            lines.append(f"\n🎬 Scenario: {scenario}")
            lines.append("| Source Field | Destination Field |")
            lines.append("| :--- | :--- |")
            
            normal_mappings = []
            none_mappings = []
            
            for m in items:
                src = m.get("source_field") or "—"
                dst = m.get("destination_field") or "—"
                
                # Check if this is an unmapped or none mapping (e.g. source is [NONE]/empty/NONE)
                is_none = (src.upper() in ("[NONE]", "NONE", "—", "") or 
                           dst.upper() in ("[NONE]", "NONE", "—", ""))
                
                if is_none:
                    display_str = f"{src} ➔ {dst}" if src != dst else dst
                    none_mappings.append(display_str)
                else:
                    normal_mappings.append((src, dst))
            
            # Print normal mappings first
            for src, dst in normal_mappings:
                lines.append(f"| {src} | {dst} |")
                
            # If there are none mappings, group them in one row
            if none_mappings:
                grouped_none = ", ".join(none_mappings)
                lines.append(f"| - | {grouped_none} |")

    else:
        if mapping_type == "value":
            lines.append("No value-level mappings exist for this field/process. Value mappings are only configured when specific source values need translation.")
        else:
            lines.append("No mapping data could be parsed from the result.")

    return "\n".join(lines)


# ─────────────────────────────────────────────────────────────────────────────
# Tool 3 — Health & Failures
# ─────────────────────────────────────────────────────────────────────────────

@tool
def get_health_and_failures_tool(
    project_key: Optional[str] = None,
    process_name: Optional[str] = None,
    oem: Optional[str] = None,
    depth: str = "summary",
) -> str:
    """
    Retrieves sync health and failure details for a project.

    Args:
        project_key (str): The project key identifier.
        process_name (str): The specific process name.
        oem (str, optional): OEM name for context.
        depth (str): "summary" for recent failure list with counts.
                     "detailed" for top failure reasons ranked by frequency.
    """
    lines = [_header(f"FAILURE REPORT ({depth.upper()})", oem, project_key, process_name)]

    if depth == "summary":
        raw = exchange_service.get_failure_summary_direct(project_key)
    else:
        raw = exchange_service.get_top_failure_reasons_direct(project_key)

    if not raw or raw.get("status") == "not_found":
        lines.append("Status: NO FAILURES FOUND")
        lines.append("The project appears healthy — no recent failures detected.")
        return "\n".join(lines)

    if raw.get("status") == "error":
        lines.append(f"Status: ERROR\nMessage: {raw.get('message', 'Unknown error')}")
        return "\n".join(lines)

    # --- Summary mode ---
    if depth == "summary":
        summary = raw.get("summary", {})
        if summary:
            lines.append(f"Total Failures: {summary.get('total_failures', 0)}")
            lines.append(f"Unique Defects Affected: {summary.get('unique_defects', 0)}")
            directions = ", ".join(summary.get("directions_involved", [])) or "N/A"
            lines.append(f"Sync Directions Involved: {directions}")

        failures = raw.get("failures", [])
        if failures:
            lines.append(f"\nRecent Failures (up to 20):")
            for f in failures:
                ts = f.get("timestamp", "N/A")
                defect = f.get("defect_id", "N/A")
                direction = f.get("direction", "N/A")
                msg = f.get("message", "N/A")
                lines.append(f"  [{ts}] {defect} ({direction}): {msg}")
        else:
            lines.append("\nNo individual failure records found.")

    # --- Detailed mode ---
    else:
        detail_summary = raw.get("summary", {})
        if detail_summary:
            lines.append(f"Total Failures Analyzed: {detail_summary.get('total_failures', 0)}")
            lines.append(f"Unique Error Reasons: {detail_summary.get('unique_reasons', 0)}")

        top_reasons = raw.get("top_failure_reasons", [])
        if top_reasons:
            lines.append("\nTop Failure Reasons (ranked by frequency):")
            for i, item in enumerate(top_reasons, 1):
                count = item.get("count", 0)
                reason = item.get("reason", "Unknown")
                lines.append(f"  {i}. [{count} occurrences] {reason}")
        else:
            lines.append("\nNo failure reason data available.")

    return "\n".join(lines)


# ─────────────────────────────────────────────────────────────────────────────
# Tool 4 — Configuration Flag
# ─────────────────────────────────────────────────────────────────────────────

@tool
def get_config_tool(
    project_key: Optional[str] = None,
    process_name: Optional[str] = None,
    config_key: str = "all",
    oem: Optional[str] = None,
) -> str:
    """
    Retrieves a specific configuration flag or setting for a project/process.

    Args:
        project_key (str): The project key identifier.
        process_name (str): The specific process name.
        config_key (str): The setting being checked. Examples:
                          - "creation" or "create" for defect creation settings
                          - "comment" for comment transfer settings
                          - "attachment" for attachment sync settings
                          - "status exchange" for status exchange settings
                          - "transfer" for data transfer settings
                          - Any config key name directly
        oem (str, optional): OEM name for context.
    """
    raw = config_service.get_config_value_by_query(project_key, process_name, config_key)

    lines = [_header("CONFIGURATION RESULT", oem, project_key, process_name)]

    if not raw or raw.get("status") in ("not_found", "unknown_config"):
        lines.append(f"Queried Setting: {config_key}")
        lines.append("Status: NOT FOUND")
        lines.append(f"Message: {raw.get('message', 'No matching configuration key found.')}")
        return "\n".join(lines)

    lines.append(f"Configuration Key: {raw.get('config_key', config_key)}")
    lines.append(f"Value: {raw.get('value', 'N/A')}")
    return "\n".join(lines)


# ─────────────────────────────────────────────────────────────────────────────
# Tool 5 — Filter Query
# ─────────────────────────────────────────────────────────────────────────────

@tool
def get_filter_query_tool(
    project_key: Optional[str] = None,
    process_name: Optional[str] = None,
    oem: Optional[str] = None,
) -> str:
    """
    Retrieves the JQL (Jira Query Language) or filter criteria configured
    for this process — i.e. what records get pulled during synchronization.

    Args:
        project_key (str): The project key identifier.
        process_name (str): The specific process name.
        oem (str, optional): OEM name for context.
    """
    raw = config_service.get_filter_query(project_key, process_name)

    lines = [_header("FILTER QUERY RESULT", oem, project_key, process_name)]

    if not raw or raw.get("status") == "not_found":
        lines.append("Status: NOT FOUND")
        lines.append(f"Message: {raw.get('message', 'No filter or query configured.')}")
        return "\n".join(lines)

    config_key = raw.get("config_key", "N/A")
    query_value = raw.get("value", "N/A")

    lines.append(f"Configuration Key: {config_key}")
    lines.append(f"Filter Query (JQL):\n{query_value}\n")

    # Add explanation breakdown
    explanation = explain_jql(query_value)
    lines.append("Plain-English Breakdown:")
    projs = ", ".join(explanation["projects"]) if explanation["projects"] else "Any project (global)"
    types = ", ".join(explanation["issue_types"]) if explanation["issue_types"] else "Any issue type"
    statuses = ", ".join(explanation["statuses"]) if explanation["statuses"] else "Any status"
    lines.append(f"  • Target Project(s): {projs}")
    lines.append(f"  • Synced Issue Type(s): {types}")
    lines.append(f"  • Synced Status(es): {statuses}\n")

    # Add performance/security audit checks
    audit_results = audit_jql(query_value)
    lines.append("Audit / Performance Check:")
    for check in audit_results:
        emoji = "✅" if check["status"] == "pass" else ("⚠️" if check["status"] == "warn" else "❌")
        lines.append(f"  {emoji} **{check['rule']}**: {check['message']}")

    return "\n".join(lines)


# ─────────────────────────────────────────────────────────────────────────────
# Tool 6 — Defect / Ticket Sync History
# ─────────────────────────────────────────────────────────────────────────────

@tool
def get_defect_history_tool(defect_id: str) -> str:
    """
    Retrieves the full synchronization history for one or more defect/ticket IDs.

    Args:
        defect_id (str): The identifier(s) of the defect/ticket (e.g. "PROJ-1234",
                         "FORD-5678"). Can be a single ID, comma-separated list,
                         space-separated, or newline-separated.
    """
    from app.utils.defect_parser import extract_defect_ids

    # Robustly parse any format: comma, space, newline separated
    parsed_ids = extract_defect_ids(defect_id)

    if not parsed_ids:
        return (
            "=== DEFECT SYNC HISTORY ===\n"
            "Status: CLARIFICATION NEEDED\n"
            "Message: No valid defect IDs found. Please provide IDs in the format PROJECT-12345."
        )

    # Cap at 10 IDs to avoid overwhelming response
    if len(parsed_ids) > 10:
        parsed_ids = parsed_ids[:10]
        cap_note = f"\n\nNote: Showing results for the first 10 defects. {len(extract_defect_ids(defect_id)) - 10} more were truncated."
    else:
        cap_note = ""

    raw = exchange_service.get_history(",".join(parsed_ids))

    lines = [f"=== DEFECT SYNC HISTORY ===\nQueried: {', '.join(parsed_ids)} ({len(parsed_ids)} defects)"]

    if not raw or raw.get("status") == "not_found":
        lines.append("Status: NOT FOUND")
        lines.append("No synchronization history found for the given defect ID(s).")
        return "\n".join(lines)

    if raw.get("status") == "clarification_required":
        lines.append("Status: CLARIFICATION NEEDED")
        lines.append(f"Message: {raw.get('message', 'Please provide a valid defect ID.')}")
        return "\n".join(lines)

    results = raw.get("results", {})
    for defect, data in results.items():
        lines.append(f"\n--- {defect} ---")
        lines.append(f"Source ID:      {data.get('sourceid', 'N/A')}")
        lines.append(f"Destination ID: {data.get('destinationid', 'N/A')}")
        lines.append(f"Created On:     {data.get('Created', 'N/A')}")

        for group in data.get("history", []):
            direction = group.get("direction", "N/A")
            status = group.get("latest_status", "N/A")
            ts = group.get("latest_timestamp", "N/A")
            lines.append(f"\n  Direction: {direction}")
            lines.append(f"  Latest Status: {status} (at {ts})")
            if status == "Failed":
                lines.append(f"  Failure Reason: {group.get('failed_message', 'Unknown')}")
            lines.append("  Recent history (newest first):")
            for record in group.get("raw_data", [])[:5]:
                rec_ts = record.get("processid", "N/A")
                rec_status = record.get("status", "N/A")
                fail = record.get("failurereason", "")
                entry = f"    • {rec_ts} | {rec_status}"
                if fail:
                    entry += f" | {fail}"
                lines.append(entry)

    if cap_note:
        lines.append(cap_note)

    return "\n".join(lines)


# ─────────────────────────────────────────────────────────────────────────────
# Tool 7 — Sync Trigger
# ─────────────────────────────────────────────────────────────────────────────

@tool
async def trigger_sync_tool(
    project_key: Optional[str] = None,
    process_name: Optional[str] = None,
    oem: Optional[str] = None,
    defect_ids: Optional[str] = None,
) -> str:
    """
    Triggers a data exchange synchronization run for a specific OEM, project, and process.
    Pre-validates that at most 4 jobs are running and that this job is not already running.
    Optionally filters the sync to a specific comma-separated list of defect/ticket IDs (e.g. "JIRA-123, JIRA-456").

    Args:
        project_key (str): The project identifier key.
        process_name (str): The process name identifier.
        oem (str): The OEM name context.
        defect_ids (str, optional): Comma-separated list of defect IDs to sync.
    """
    from app.db.connection import get_pg_connection
    from app.exchange_trigger.process_service import ProcessService
    from app.exchange_trigger.connection_manager import ConnectionManager
    import uuid

    if not oem or not project_key or not process_name:
        return (
            "=== TRIGGER SYNC RESULT ===\n"
            "Status: ERROR\n"
            "Message: Missing required context (OEM, Project Key, or Process Name). "
            "Please ensure your active context settings are configured."
        )

    # 1. Resolve context IDs from database
    try:
        with get_pg_connection() as conn:
            # Resolve OEM
            oem_id = None
            with conn.cursor() as cur:
                cur.execute("SELECT id FROM oems WHERE LOWER(name) = LOWER(%s);", (oem,))
                row = cur.fetchone()
                if row:
                    oem_id = row[0]
            
            if not oem_id:
                return (
                    "=== TRIGGER SYNC RESULT ===\n"
                    "Status: ERROR\n"
                    f"Message: OEM '{oem}' not found in the database."
                )

            # Resolve Project
            project_id = None
            with conn.cursor() as cur:
                cur.execute("SELECT id FROM projects WHERE LOWER(project_key) = LOWER(%s) AND oem_id = %s;", (project_key, oem_id))
                row = cur.fetchone()
                if row:
                    project_id = row[0]

            if not project_id:
                return (
                    "=== TRIGGER SYNC RESULT ===\n"
                    "Status: ERROR\n"
                    f"Message: Project '{project_key}' for OEM '{oem}' not found in the database."
                )

            # Resolve Process
            with conn.cursor() as cur:
                cur.execute(
                    "SELECT project_id, process_name, java_process_name, configset_name, instance "
                    "FROM processes WHERE LOWER(process_name) = LOWER(%s) AND project_id = %s;",
                    (process_name, project_id)
                )
                process_row = cur.fetchone()

            if not process_row:
                return (
                    "=== TRIGGER SYNC RESULT ===\n"
                    "Status: ERROR\n"
                    f"Message: Process '{process_name}' under Project '{project_key}' not found in the database."
                )

            process_dict = {
                "project_id": process_row[0],
                "process_name": process_row[1],
                "java_process_name": process_row[2],
                "configset_name": process_row[3],
                "instance": process_row[4]
            }

    except Exception as dbe:
        return (
            "=== TRIGGER SYNC RESULT ===\n"
            "Status: ERROR\n"
            f"Message: Database resolution error: {str(dbe)}"
        )

    # 2. Perform validations and trigger sync
    try:
        # Instantiate process service using the global websocket connection manager
        from app.main import manager as app_manager
    except ImportError:
        app_manager = ConnectionManager()

    process_service = ProcessService(app_manager)
    job_id = str(uuid.uuid4())

    try:
        # Check running processes and duplicate limits
        validate_res = process_service.validate_process(
            str(oem_id),
            str(project_id),
            process_dict,
            defect_ids
        )
        if validate_res.get("status_code") != 200:
            return (
                "=== TRIGGER SYNC RESULT ===\n"
                "Status: VALIDATION_FAILED\n"
                f"Message: {validate_res.get('msg', 'Trigger criteria validation failed.')}"
            )
    except Exception as ve:
        return (
            "=== TRIGGER SYNC RESULT ===\n"
            "Status: ERROR\n"
            f"Message: Validation check failed with error: {str(ve)}"
        )

    # 3. Start sync job execution in backend asynchronously
    try:
        import asyncio
        loop = asyncio.get_running_loop()
        loop.create_task(
            process_service.start_process(
                job_id,
                str(oem_id),
                str(project_id),
                process_dict,
                defect_ids
            )
        )

        return (
            "=== TRIGGER SYNC RESULT ===\n"
            "Status: VALIDATED_AND_STARTED\n"
            f"Job ID: {job_id}\n"
            f"OEM: {oem}\n"
            f"Project: {project_key}\n"
            f"Process: {process_name}\n"
            "Message: Sync triggered successfully! Live progress logs will start streaming now."
        )
    except Exception as se:
        return (
            "=== TRIGGER SYNC RESULT ===\n"
            "Status: ERROR\n"
            f"Message: Failed to start sync run: {str(se)}"
        )


# ─────────────────────────────────────────────────────────────────────────────
# Registry — all tools available to the LangGraph agent
# ─────────────────────────────────────────────────────────────────────────────

AIDA_TOOLS = [
    get_schedule_tool,
    get_mappings_tool,
    get_health_and_failures_tool,
    get_config_tool,
    get_filter_query_tool,
    get_defect_history_tool,
    trigger_sync_tool,
]

