from typing import TypedDict, Annotated, Sequence, Optional, List, Any
from langchain_core.messages import BaseMessage
from langgraph.graph.message import add_messages
from app.auth.schema import AuthorizationContext


class AgentState(TypedDict):
    """
    The central state of the AIDA LangGraph workflow.

    Divided into five logical groups:
      1. Conversation  — the message thread passed to each LLM node
      2. Context       — OEM / Project / Process selected by the user in the UI
      3. Clarification — fields used when the agent needs more info
      4. Tool tracking — last tool name/result/error for transparency & debugging
      5. Response meta — intent label and readiness flag
    """

    # ── 1. Conversation ───────────────────────────────────────────────────────
    # LangGraph accumulates messages using the add_messages reducer so that
    # every node can append without overwriting previous entries.
    messages: Annotated[Sequence[BaseMessage], add_messages]

    # ── 2. Context (set by the UI — never re-asked when already present) ──────
    oem: Optional[str]           # e.g. "FORD"
    project_key: Optional[str]   # e.g. "P702_RCB"
    process_name: Optional[str]  # e.g. "Ford2Visteon_P708RCB"
    timezone: Optional[str]      # e.g. "Asia/Kolkata"

    # Tracks WHERE the context came from so the router LLM is told
    # "don't ask again — it's already set from the UI".
    # Values: "ui_selection" | "llm_extracted" | "none"
    context_source: str

    # ── 3. Clarification flow ─────────────────────────────────────────────────
    clarification_required: bool

    # Which field is missing: "oem" | "project" | "process"
    missing_context_field: Optional[str]

    # DB-sourced list of available choices to show the user as action chips.
    # Populated by context_checker_node so the frontend renders immediately
    # without a separate /trigger-options API call.
    clarification_options: Optional[List[Any]]

    # ── 4. Tool execution tracking ────────────────────────────────────────────
    last_tool_name: Optional[str]    # e.g. "get_schedule_tool"
    last_tool_result: Optional[str]  # Structured text block returned by tool
    tool_error: Optional[str]        # Exception message if the tool failed

    # ── 5. Response metadata ──────────────────────────────────────────────────
    # Propagated to the API response for logging / frontend routing decisions.
    intent: Optional[str]   # e.g. "schedule_query", "failure_summary", "ai"
    response_ready: bool     # Set True only after synthesizer produces final output

    authorization: AuthorizationContext #Jira Authorization context for the user, including email, jira_account_id, project_ids, project_keys, and oem_ids
