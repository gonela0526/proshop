"""AIDA Fallback Registry
======================
Configurable fallback registry mapping keywords and phrases to tools.
Helps routing queries when LLMs miss the tool-calling intent.
"""

from app.utils.defect_parser import extract_defect_ids

FALLBACK_KEYWORDS = {
    "get_schedule_tool": [
        "schedule", "schedul", "sched", "cron", "next run", "timing",
        "when does it run", "execution time", "run time", "frequency",
        "scehdule", "schdeule", "scedule", "schdule", "next schedule"
    ],
    "get_health_and_failures_tool": [
        "fail", "error", "broken", "issue", "health", "down",
        "problem", "not working", "defect failure", "failed item",
        "faliure", "fialure"
    ],
    "get_filter_query_tool": [
        "filter", "jql", "query used", "filter query", "search query",
        "filtre", "fliter"
    ],
    "get_mappings_tool": [
        "mapping", "field mapping", "value mapping", "mapped",
        "source field", "destination field", "mappings",
        "value map", "mapped to"
    ],
    "get_config_tool": [
        "config", "configuration", "setting", "parameter", "flag",
        "enabled", "disabled", "transfer", "comment", "attachment",
        "creation", "status exchange", "sync enabled",
        "is creation", "are we transferring", "is attachment",
        "is status", "comments enabled", "comments disabled"
    ],
    "get_defect_history_tool": [
        "history", "sync history", "exchange history", "track defect",
        "sync status", "not synced", "not got synced", "why not synced",
        "synced or not", "defect status"
    ],
    "trigger_sync_tool": [
        "trigger sync", "run sync", "start sync", "trigger process",
        "sync trigger", "start process", "execute sync", "synchronize"
    ]
}


def resolve_keyword_fallback(query: str) -> str | None:
    """Resolves a tool name from a query string using the fallback keyword registry."""
    q = query.lower().strip()

    # Check regular keyword triggers
    for tool_name, keywords in FALLBACK_KEYWORDS.items():
        if any(kw in q for kw in keywords):
            return tool_name

    # Check if the query contains defect IDs as a fallback
    defect_ids = extract_defect_ids(q)
    if defect_ids:
        return "get_defect_history_tool"

    return None
