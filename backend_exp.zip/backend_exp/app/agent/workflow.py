import os
import re
from dotenv import load_dotenv
from typing import Literal
from langgraph.graph import StateGraph, END
from langchain_ollama import ChatOllama
from langchain_core.messages import ToolMessage, HumanMessage, AIMessage, SystemMessage

from app.agent.state import AgentState
from app.utils.logger import setup_logger
from app.utils.defect_parser import extract_defect_ids
from app.agent.fallback_registry import resolve_keyword_fallback
from app.services.config_service import ConfigService

logger = setup_logger()

load_dotenv()

OLLAMA_BASE_URL = os.environ["OLLAMA_BASE_URL"]
ROUTER_MODEL = os.environ["OLLAMA_ROUTER_MODEL"]
SYNTH_MODEL = os.environ["OLLAMA_SYNTH_MODEL"]

# ─────────────────────────────────────────────────────────────────────────────
# LLM Initialisation (Ollama only)
# ─────────────────────────────────────────────────────────────────────────────

# The Needle: fast router / intent classifier — bound with all available tools
_router_llm_instance = None
def get_router_llm():
    global _router_llm_instance
    if _router_llm_instance is None:
        from app.tools.unified_tools import AIDA_TOOLS
        _router_llm_instance = ChatOllama(
            base_url=OLLAMA_BASE_URL,
            model=ROUTER_MODEL,
            temperature=0,
        ).bind_tools(AIDA_TOOLS)
    return _router_llm_instance

# The Sword: slower reasoning + synthesis model — NO tools bound
synth_llm = ChatOllama(
    base_url=OLLAMA_BASE_URL,
    model=SYNTH_MODEL,
    temperature=0.3,
)


# ─────────────────────────────────────────────────────────────────────────────
# Helper: build the context status block injected into every system prompt
# ─────────────────────────────────────────────────────────────────────────────

def _build_context_status(state: AgentState) -> str:
    oem = state.get("oem")
    project = state.get("project_key")
    process = state.get("process_name")
    tz = state.get("timezone") or "UTC"
    source = state.get("context_source", "none")

    set_parts = []
    missing_parts = []
    for label, val in [("OEM", oem), ("Project", project), ("Process", process)]:
        if val:
            set_parts.append(f"{label}={val}")
        else:
            missing_parts.append(label)

    lines = ["=== ACTIVE CONTEXT ==="]
    if set_parts:
        lines.append("Set: " + ", ".join(set_parts) + f"  (source: {source})")
    else:
        lines.append("Set: (none)")
    if missing_parts:
        lines.append("Missing: " + ", ".join(missing_parts))
    else:
        lines.append("Missing: (none — all context provided)")
    lines.append(f"Timezone: {tz}")
    lines.append("======================")
    return "\n".join(lines)


# ─────────────────────────────────────────────────────────────────────────────
# Node 1 — router_node  (The Needle)
# ─────────────────────────────────────────────────────────────────────────────

def router_node(state: AgentState) -> dict:
    """
    Fast intent-classification node.

    Responsibilities:
    - Receives the user message + full conversation history
    - Injects current context as a system message so the LLM knows what's set
    - Decides whether to call a tool or answer conversationally
    - CRITICAL: when context fields are set, the LLM must call the tool
      immediately — NOT ask the user to clarify them again
    """
    messages = state["messages"]
    context_status = _build_context_status(state)

    oem = state.get("oem")
    project = state.get("project_key")
    process = state.get("process_name")

    # Build a directive that prevents the LLM from re-asking for known context
    if oem and project and process:
        context_directive = (
            "CRITICAL RULE: The user has already selected their context via the UI settings panel. "
            "You MUST NOT ask the user for the OEM, project, or process — these are already set. "
            "When the user's question requires a tool call, invoke the tool immediately using "
            "the context values shown above."
        )
    elif oem or project or process:
        context_directive = (
            "Partial context is currently selected. "
            "If the user's request requires a tool, ALWAYS emit the tool call. "
            "Do NOT decide whether the context is sufficient. "
            "The context_checker node is responsible for validating missing OEM, "
            "project and process before any tool executes."
        )
    else:
        context_directive = (
            "No context is currently selected. If the user's question requires a specific "
            "project or process, the context_checker will handle asking for it — "
            "do NOT ask in your message; just call the appropriate tool."
        )

    system_content = (
        "AIDA (Agosense Intelligent Defect Assistant) is an AI-powered, chat-based self-service solution designed to help program teams access Agosense Exchange information without relying on the Engineering IT (EIT) team. It enables users to retrieve synchronization schedules, filter configurations, mapping details, and process status through natural language queries. It also supports manual sync requests through an approval workflow and notifies users of execution results. By integrating with Agosense, and knowledge repositories, AIDA improves operational efficiency, reduces support workload, and enhances self-service capabilities.\n\n"
        f"{context_status}\n\n"
        f"{context_directive}\n\n"
        "Available capabilities:\n"
        "- get_schedule_tool: Execution schedule (cron / next-run times)\n"
        "- get_mappings_tool: Field or value mapping configurations. IMPORTANT: If the user asks for \"value mapping\", set mapping_type=\"value\". If they ask for \"field mapping\" or just \"mapping details\", set mapping_type=\"field\".\n"
        "- get_health_and_failures_tool: Recent sync failures and top error reasons\n"
        "- get_config_tool: Specific configuration flag / setting lookup. Use this for ANY question about configuration, e.g. \"is creation enabled\", \"are we transferring comments\", \"is attachment sync on\", \"is status exchange enabled\".\n"
        "- get_filter_query_tool: The JQL / filter query used in a process\n"
        "- get_defect_history_tool: Sync history for specific defect/ticket IDs. Pass ALL defect IDs from the user's message (comma-separated).\n"
        "- trigger_sync_tool: Triggers a sync run for the active OEM, project, and process. Use this when the user asks to trigger, run, execute, start, or synchronize the data exchange.\n\n"
        "IMPORTANT RULES:\n"
        "- The ACTIVE CONTEXT above ALWAYS overrides any project/process names mentioned in older chat history messages.\n"
        "- For general questions about AIDA, greetings, or explanations: answer directly without tools.\n"
        "- Do NOT answer off-topic questions, jokes, or general knowledge queries. Politely decline and steer the user back to automotive data integration to save tokens."
    )

    router_llm = get_router_llm()
    logger.info("🧠 [ROUTER] Invoking Router LLM to determine intent...")

    # Get the user's raw query text for fallback detection
    user_query = ""
    for m in reversed(messages):
        if isinstance(m, HumanMessage):
            user_query = m.content.lower().strip()
            break

    response = router_llm.invoke(
        [SystemMessage(content=system_content)] + list(messages)
    )
    
    if response.tool_calls:
        logger.info(f"🛠️ [ROUTER] LLM decided to call tool: {response.tool_calls[0].get('name')}")
        return {
            "messages": [response],
            "response_ready": False,
        }
    else:
        # ── Keyword-based fallback when the small LLM misses the intent ──
        logger.warning(f"⚠️ [ROUTER] LLM did NOT emit a tool call. Running keyword fallback on: '{user_query}'")
        fallback_tool = _keyword_fallback(user_query)
        if fallback_tool:
            logger.info(f"🔄 [ROUTER] Keyword fallback matched tool: {fallback_tool}")
            # Create a NEW AIMessage with synthetic tool call — mutating response.tool_calls
            # doesn't work reliably because LangChain derives it from additional_kwargs.
            response = AIMessage(
                content="",
                tool_calls=[{
                    "name": fallback_tool,
                    "args": {},  # tool_node will inject context from state
                    "id": f"fallback_{fallback_tool}",
                }],
            )
            return {
                "messages": [response],
                "response_ready": False,
            }
        else:
            logger.info("🗣️ [ROUTER] No tool needed. Answering conversationally.")
            # Do NOT append the router's AIMessage, so synthesizer sees HumanMessage last
            return {
                "response_ready": False,
            }


def _keyword_fallback(query: str) -> str | None:
    """Simple keyword matcher as a safety net for when the LLM router

    (especially small models like qwen2.5:1.5b) fails to emit a tool call.
    Delegates to resolve_keyword_fallback.
    """
    return resolve_keyword_fallback(query)


# ─────────────────────────────────────────────────────────────────────────────
# Edge 1 — should_continue
# ─────────────────────────────────────────────────────────────────────────────

def should_continue(state: AgentState) -> Literal["context_checker", "synthesizer"]:
    """
    After the router runs:
    - Tool call requested → go to context_checker (validates context, then runs tool)
    - Direct answer      → go to synthesizer (polishes into natural language)

    NOTE: We NEVER go directly to __end__ — all responses pass through the
    synthesizer so the output is always consistent natural language.
    """
    last_message = state["messages"][-1]
    if getattr(last_message, "tool_calls", None):
        return "context_checker"
    return "synthesizer"


# ─────────────────────────────────────────────────────────────────────────────
# Node 2 — context_checker_node
# ─────────────────────────────────────────────────────────────────────────────

def context_checker_node(state: AgentState) -> dict:
    """
    Pure-Python validation node.

    Checks whether the context required by the chosen tool is present in state.
    If the LLM extracted project/process directly from the user's message (e.g.
    "Show me schedule for P702_RCB / Ford2Visteon"), those values are used.

    When context IS missing:
    - Queries the DB to get a list of available options
    - Stores them in clarification_options so the frontend can render action chips
    - Sets clarification_required=True — the ask_user node fires next
    """
    last_message = state["messages"][-1]

    logger.info(
    f"STATE -> OEM={state.get('oem')}, "
    f"PROJECT={state.get('project_key')}, "
    f"PROCESS={state.get('process_name')}"
)
    # --- Extract any context the LLM pulled from the user's message ---
    llm_project = None
    llm_process = None
    llm_oem = None
    llm_defect_id = None
    if last_message.tool_calls:
        args = last_message.tool_calls[0].get("args", {})
        llm_project = args.get("project_key")
        llm_process = args.get("process_name")
        llm_oem = args.get("oem")
        llm_defect_id = args.get("defect_ids") or args.get("defect_id")
    
    clarification_started = (
        state.get("oem") is not None
        or state.get("project_key") is not None
        or state.get("process_name") is not None
    )

    if clarification_started:
        # Once the clarification flow starts, trust only the UI selections.
        resolved_oem = state.get("oem")
        resolved_project = state.get("project_key")
        resolved_process = state.get("process_name")
    else:
        # First request: allow the LLM to extract context from the query.
        resolved_oem = state.get("oem") or llm_oem
        resolved_project = state.get("project_key") or llm_project
        resolved_process = state.get("process_name") or llm_process

    # Determine which tool is being called
    tool_name = last_message.tool_calls[0].get("name", "") if last_message.tool_calls else ""
    
    if tool_name == "trigger_sync_tool":
        if not llm_defect_id:
            from app.utils.defect_parser import extract_defect_ids
            user_query = ""
            for m in reversed(state["messages"]):
                if isinstance(m, HumanMessage):
                    user_query = m.content
                    break
            ids_from_query = extract_defect_ids(user_query)
            if ids_from_query:
                llm_defect_id = ",".join(ids_from_query)

    logger.info(f"🔎 [CONTEXT] Tool: {tool_name} | OEM: {resolved_oem} | Project: {resolved_project} | Process: {resolved_process}")

    # Tools that require project + process
    project_process_tools = {
        "get_schedule_tool",
        "get_mappings_tool",
        "get_config_tool",
        "get_filter_query_tool",
        "trigger_sync_tool",
    }
    # Tools that only need project
    project_only_tools = {"get_health_and_failures_tool"}

    # --- Check what's missing ---
    if not resolved_oem and tool_name in (project_process_tools | project_only_tools):
        options = _fetch_clarification_options(state,missing="oem")
        return {
            "clarification_required": True,
            "missing_context_field": "oem",
            "clarification_options": options,
        }

    if not resolved_project and tool_name in (project_process_tools | project_only_tools):
        options = _fetch_clarification_options(
            state,
            missing="project",
            oem=resolved_oem
        )
        return {
            "clarification_required": True,
            "missing_context_field": "project",
            "clarification_options": options,
        }

    if not resolved_process and tool_name in project_process_tools:
        options = _fetch_clarification_options(
            state,
            missing="process",
            project_key=resolved_project
        )
        return {
            "clarification_required": True,
            "missing_context_field": "process",
            "clarification_options": options,
        }

    # If OEM, Project, Process are resolved, check defect_id for trigger_sync_tool
    if tool_name == "trigger_sync_tool" and not llm_defect_id:
        return {
            "clarification_required": True,
            "missing_context_field": "defect_id",
            "clarification_options": [],
        }

    # --- All context present: update state with any LLM-extracted values ---
    update: dict = {
        "clarification_required": False,
        "missing_context_field": None,
        "clarification_options": None,
    }
    
    if not clarification_started:
        if llm_project and not state.get("project_key"):
            update["project_key"] = llm_project
            update["context_source"] = "llm_extracted"
            logger.info(f"🔍 [CONTEXT] Extracted project from query: {llm_project}")
        if llm_process and not state.get("process_name"):
            update["process_name"] = llm_process
            update["context_source"] = "llm_extracted"
            logger.info(f"🔍 [CONTEXT] Extracted process from query: {llm_process}")
        if llm_oem and not state.get("oem"):
            update["oem"] = llm_oem
            update["context_source"] = "llm_extracted"
            logger.info(f"🔍 [CONTEXT] Extracted OEM from query: {llm_oem}")

    logger.info("✅ [CONTEXT] Context is fully satisfied. Proceeding to execute tool.")
    return update



def _fetch_clarification_options(
    state: AgentState,
    missing: str,
    oem: str | None = None,
    project_key: str | None = None,
):
    """
    Returns clarification options restricted to the user's authorized scope.
    """

    auth = state["authorization"]
    authorized_projects = auth.projects

    svc = ConfigService()

    # ------------------------------------------------------------------
    # OEM
    # ------------------------------------------------------------------
    if missing == "oem":

        all_oems = svc.list_oems()

        authorized_oem_ids = {
            project.oem_id
            for project in authorized_projects
        }

        return [
            {
                "label": oem["name"],
                "value": oem["name"],
                "type": "oem",
            }
            for oem in all_oems
            if oem["id"] in authorized_oem_ids
        ]

    # ------------------------------------------------------------------
    # PROJECT
    # ------------------------------------------------------------------
    if missing == "project":

        all_oems = {
            o["id"]: o["name"]
            for o in svc.list_oems()
        }

        return [
            {
                "label": project.db_project_name,
                "value": project.project_key,
                "type": "project",
            }
            for project in authorized_projects
            if all_oems.get(project.oem_id) == oem
        ]

    # ------------------------------------------------------------------
    # PROCESS
    # ------------------------------------------------------------------
    if missing == "process":

        project = next(
            (
                p
                for p in authorized_projects
                if p.project_key == project_key
            ),
            None,
        )

        if project is None:
            return []

        processes = svc.list_processes(project_key)

        return [
            {
                "label": process["process_name"],
                "value": process["process_name"],
                "type": "process",
            }
            for process in processes
        ]

    return []



# def _fetch_clarification_options(
#     state: AgentState,
#     missing: str,
#     oem: str = None,
#     project_key: str = None
# ) -> list:

#     """
#     Fetches real options from the DB to populate action chips in the UI.
#     Returns a safe empty list on any DB error.
#     """
#     try:
#         from app.services.config_service import ConfigService
#         svc = ConfigService()
#         if missing == "oem":
#             oems = svc.list_oems()
#             return [{"label": o.get("name"), "value": o.get("name"),
#                      "type": "oem"} for o in oems]
#         elif missing == "project":
#             if oem:
#                 projects = svc.list_projects_by_oem(oem)
#                 return [{"label": p.get("project_name") or p.get("project_key"),
#                          "value": p.get("project_key"), "type": "project"}
#                         for p in projects]
#         elif missing == "process" and project_key:
#             processes = svc.list_processes(project_key)
#             return [{"label": p.get("process_name"), "value": p.get("process_name"),
#                      "type": "process"} for p in processes]
#     except Exception:
#         pass
#     return []


# ─────────────────────────────────────────────────────────────────────────────
# Edge 2 — tool_router
# ─────────────────────────────────────────────────────────────────────────────

def tool_router(state: AgentState) -> Literal["tools", "ask_user"]:
    if state.get("clarification_required"):
        return "ask_user"
    return "tools"


# ─────────────────────────────────────────────────────────────────────────────
# Node 3 — tool_node
# ─────────────────────────────────────────────────────────────────────────────

PROJECT_AUTHORIZED_TOOLS = {
    "get_config_tool",
    "get_mapping_tool",
    "get_schedule_tool",
    "trigger_sync_tool",
}

def _is_project_authorized(
    state: AgentState,
    project_key: str | None,
) -> bool:
    """
    Validates whether the selected project belongs to the authenticated user.
    """

    if project_key is None:
        return True

    authorization = state.get("authorization")

    if authorization is None:
        return False

    return any(
        project.project_key == project_key
        for project in authorization.projects
    )

async def tool_node(state: AgentState) -> dict:
    """
    Executes the tool function selected by the router LLM.

    Auto-injects ALL context fields (oem, project_key, process_name, timezone)
    from state into the tool call args when the LLM omitted them.
    Also smart-injects mapping_type and defect_id from the user's raw query.
    Records tool name, result, and any error for transparency.
    """
    logger.info("⚙️ [TOOL NODE] Executing tool...")
    from app.tools.unified_tools import AIDA_TOOLS
    last_message = state["messages"][-1]
    tool_responses = []
    last_tool_name = None
    last_tool_result = None
    tool_error = None

    # Get the user's raw query for smart injection
    user_query = ""
    for m in reversed(state["messages"]):
        if isinstance(m, HumanMessage):
            user_query = m.content
            break

    for tool_call in last_message.tool_calls:
        tool_name = tool_call["name"]
        last_tool_name = tool_name
        logger.info(f"⚙️ [TOOL NODE] Running tool: {tool_name}")

        # ------------------------------------------------------------------
        # Project Authorization
        # ------------------------------------------------------------------

        if tool_name in PROJECT_AUTHORIZED_TOOLS:

            project_key = tool_call["args"].get(
                "project_key",
                state.get("project_key"),
            )

            if not _is_project_authorized(
                state,
                project_key,
            ):

                logger.warning(
                    "[AUTHORIZATION] "
                    "email=%s "
                    "tool=%s "
                    "project=%s "
                    "status=DENIED",
                    state["authorization"].email,
                    tool_name,
                    project_key,
                )

                return {
                    **state,
                    "messages": state["messages"]
                    + [
                        AIMessage(
                            content=(
                                "You don't have permission to access the selected project. "
                                "Please choose one of your authorized projects."
                            )
                        )
                    ],
                    "last_tool_name": tool_name,
                    "last_tool_result": None,
                    "tool_error": "Unauthorized",
                    "response_ready": True,
                }

        # Find matching tool
        tool_instance = next(
            (t for t in AIDA_TOOLS if t.name == tool_name), None
        )
        if not tool_instance:
            err = f"Tool '{tool_name}' not found in AIDA_TOOLS registry."
            tool_responses.append(
                ToolMessage(content=err, tool_call_id=tool_call["id"])
            )
            tool_error = err
            continue

        # ALWAYS override context fields from state — UI selection is ground truth.
        # The LLM may hallucinate wrong project_key/process_name from chat history,
        # so we never trust its extracted context over what the user explicitly selected.
        args = dict(tool_call["args"])
        if state.get("oem"):
            args["oem"] = state["oem"]
        if state.get("project_key"):
            args["project_key"] = state["project_key"]
        if state.get("process_name"):
            args["process_name"] = state["process_name"]
        if state.get("timezone"):
            args["timezone"] = state["timezone"]

        # Smart-inject mapping_type and field_name from user query when LLM missed it
        if tool_name == "get_mappings_tool":
            q_lower = user_query.lower()
            if "value mapping" in q_lower or "value map" in q_lower:
                args["mapping_type"] = "value"
                logger.info("🔄 [TOOL NODE] Detected 'value mapping' in query — overriding mapping_type=value")

            # Extract the field name from the user's query so the service
            # can match the correct field in the DB via token intersection.
            # Strip common noise words to isolate the actual field name.
            if not args.get("field_name"):
                noise_words = {
                    "value", "field", "mapping", "mappings", "map", "maps",
                    "show", "get", "give", "me", "the", "for", "of", "what",
                    "is", "are", "can", "you", "please", "display", "list",
                    "all", "details", "detail", "a", "an", "my", "in",
                }
                tokens = [w for w in re.split(r'\s+', q_lower.strip()) if w and w not in noise_words]
                if tokens:
                    extracted_field = " ".join(tokens)
                    args["field_name"] = extracted_field
                    logger.info(f"🔄 [TOOL NODE] Extracted field_name from query: '{extracted_field}'")

        # Smart-inject defect_id from user query when LLM missed it
        if tool_name in ("get_defect_history_tool", "trigger_sync_tool"):
            arg_key = "defect_ids" if tool_name == "trigger_sync_tool" else "defect_id"
            if not args.get(arg_key) or args.get(arg_key, "").strip() == "":
                ids_from_query = extract_defect_ids(user_query)
                if ids_from_query:
                    args[arg_key] = ",".join(ids_from_query)
                    logger.info(f"🔄 [TOOL NODE] Extracted defect IDs from query: {ids_from_query}")

        logger.info(f"📋 [TOOL NODE] Final args for {tool_name}: {args}")

        try:
            result = await tool_instance.ainvoke(args)
            last_tool_result = str(result)
            logger.info(f"✅ [TOOL NODE] {tool_name} returned {len(last_tool_result)} chars. Preview: {last_tool_result[:200]}...")
            tool_responses.append(
                ToolMessage(content=last_tool_result, tool_call_id=tool_call["id"])
            )
        except Exception as exc:
            err = f"Tool '{tool_name}' raised an error: {exc}"
            logger.error(f"❌ [TOOL NODE] {err}")
            tool_error = err
            tool_responses.append(
                ToolMessage(content=err, tool_call_id=tool_call["id"])
            )

    # Determine precise intent if possible
    intent = None
    if last_tool_name == "get_health_and_failures_tool" and len(last_message.tool_calls) > 0:
        depth = last_message.tool_calls[0].get("args", {}).get("depth", "summary")
        if depth == "summary":
            intent = "failure_summary_query"
        else:
            intent = "top_failures_query"
    elif last_tool_name:
        intent_map = {
            "get_schedule_tool": "schedule_query",
            "get_mappings_tool": "mapping_query",
            "get_config_tool": "config_query",
            "get_filter_query_tool": "filter_query",
            "get_defect_history_tool": "defect_history_query",
            "trigger_sync_tool": "trigger_sync",
        }
        intent = intent_map.get(last_tool_name, "tool_call")

    return {
        "messages": tool_responses,
        "last_tool_name": last_tool_name,
        "last_tool_result": last_tool_result,
        "tool_error": tool_error,
        "intent": intent,
    }


# ─────────────────────────────────────────────────────────────────────────────
# Node 4 — synthesizer_node  (The Sword)
# ─────────────────────────────────────────────────────────────────────────────

def synthesizer_node(state: AgentState) -> dict:
    """
    Reasoning + synthesis node — ALWAYS runs last for every user-facing response.

    Takes the full message history (which now includes any ToolMessage result)
    and produces a single, clean, natural-language answer. This ensures the
    user never sees raw JSON, raw dicts, or "I'm not sure how to format this".
    """
    logger.info("🪄 [SYNTHESIZER] Formatting response for user...")
    messages = state["messages"]

    context_status = _build_context_status(state)
    tool_name = state.get("last_tool_name") or "none"
    has_tool_error = bool(state.get("tool_error"))

    system_content = (
        "AIDA (Agosense Intelligent Defect Assistant) is an AI-powered, chat-based self-service solution designed to help program teams access Agosense Exchange information without relying on the Engineering IT (EIT) team. It enables users to retrieve synchronization schedules, filter configurations, mapping details, and process status through natural language queries. It also supports manual sync requests through an approval workflow and notifies users of execution results. By integrating with Agosense, and knowledge repositories, AIDA improves operational efficiency, reduces support workload, and enhances self-service capabilities.\n\n"
        f"{context_status}\n\n"
        "Your task: produce a clear, concise, human-readable response based on the conversation above.\n\n"
        "CRITICAL RULES ON YOUR IDENTITY, PURPOSE & AGOSENSE:\n"
        "- When asked about contact information for Agosense or AIDA, you MUST provide the following details: Agosense Support (EIT-Agosense@visteon.com) and Alfred Miranda (amiran11@visteon.com).\n"
        "- When asked what you are, who you are, your purpose, or what you can do (e.g. \"what is aida\", \"what is your purpose\"), you MUST explain that you help users understand exchange schedules, mapping configurations, sync failures, configurations, filters, and defect histories, but you MUST limit your main/assist capabilities to ONLY these 2 points:\n"
        "  1. Data Integration: Helping with the seamless flow of data between different systems.\n"
        "  2. Process Optimization: Streamlining workflows to make them more efficient.\n"
        "  Do NOT present other features (such as mappings, logs, failure tables) as core assistant goals in your purpose intro list; describe them as tools if specifically asked, but stick strictly to these two points for your general purpose outline.\n"
        "- When asked about Agosense (e.g., \"what is agosense\", \"explain agosense\"), you MUST explain that it is an integration and data exchange platform designed to connect different ALM and ticketing tools (like Jira, IBM RTC, KPMGSB, STARC, TAEESI Octane) for data synchronization. You MUST dynamically build a context-aware explanation and ALWAYS include this exact hyperlink: [Agosense Presentation](https://visteon-my.sharepoint.com/personal/amiran11_visteon_com/_layouts/15/guestaccess.aspx?share=IQBWHTErg20VRpJQChuKrArKAXJ4Eil6R01DVBSGc5vUAhs&e=1P5wSt) which is a ppt about agosense.\n"
        "- Under NO circumstances are you allowed to tell jokes, tell jokes about Agosense, or answer off-topic queries (e.g. \"let me joke on agosense\", \"tell me a joke about data integration\"). If the user asks for a joke, joke about Agosense, or tries to engage in off-topic talk, you MUST POLITELY DECLINE to answer, state that you are an assistant for automotive data integration, and refuse the request to save system resources.\n"
        "- If the tool `trigger_sync_tool` was executed and returned `VALIDATED_AND_STARTED` with a `Job ID`, your response MUST be EXACTLY this: '✅ Sync triggered successfully! **Job ID:** `<uuid>` — Live progress updates will appear below. Ending the chat will NOT stop the triggered sync.' Do NOT add any other text, filler, emoji spam, or follow-up offers. Keep it compact.\n"
        "- If the tool `trigger_sync_tool` returned `VALIDATION_FAILED` or `ERROR`, present the error message clearly and suggest the user try again later.\n"
        "- NEVER use the words 'manual' or 'manually' when referring to triggering a sync. Always use 'Sync Trigger' or 'Trigger Sync'.\n\n"
        "CRITICAL CONTEXT RULE:\n"
        "- ONLY use the project/process/OEM names from the ACTIVE CONTEXT block above.\n"
        "- NEVER reference project or process names from older messages in the chat history — those may be stale from a previous context.\n\n"
        "CRITICAL RULES FOR FORMATTING TOOL RESULTS:\n"
        f"- The last tool executed was: {tool_name}\n"
        + ("- The tool returned an ERROR — acknowledge it gracefully and suggest next steps.\n"
           if has_tool_error else
           "- If the tool returned structured data (e.g. `=== SCHEDULE RESULT ===` or `=== FAILURE REPORT ===` or `=== TRIGGER SYNC RESULT ===`), "
           "you MUST reformat the raw text into a beautiful, easy-to-read markdown response. Use **bolding**, clean bulleted lists, or well-structured markdown tables to present the data elegantly. Do NOT output a raw wall of text.\n"
           "- If the tool returned markdown tables (e.g. for field mappings, value mappings, or summary mappings), you MUST preserve those tables EXACTLY and output them as-is without changing any column names, cell values, or structure.\n"
           "- Never expose internal python dicts or raw `=== HEADER ===` lines to the user.\n"
           "- Extract the actual values and present them conversationally but professionally.\n")
        + "- Always format times in 12-hour AM/PM format with the timezone clearly stated.\n"
        "- If no tool was called (direct answer), give a helpful, conversational response.\n"
        "- Be concise. Avoid repeating what the user just asked.\n"
        "- If data is empty or not found, say so clearly and suggest what the user can do next.\n"
        "- If the user asks a joke, unrelated off-topic questions, or general queries not related to automotive data integration, POLITELY DECLINE to answer. State that you are an automotive data integration assistant and refuse to answer to preserve tokens.\n\n"
        "TONE & STYLE RULES:\n"
        "- Use emojis generously to make responses warm and interactive (📅 ✅ 🔄 ⚠️ 🎯 📊 🔧 💡 🚀 etc).\n"
        "- Be conversational and human, NOT robotic.\n"
        "- NEVER end your response with generic filler like 'If you need more detailed information or have any other questions, feel free to ask!' or similar boilerplate. Just end naturally after presenting the data.\n"
        "- If you want to offer help, be specific: e.g. 'Want me to check the value mappings too?' instead of generic offers.\n"
    )

    response = synth_llm.invoke(
        [SystemMessage(content=system_content)] + list(messages)
    )

    return {
        "messages": [response],
        "response_ready": True,
    }


# ─────────────────────────────────────────────────────────────────────────────
# Node 5 — ask_user_node
# ─────────────────────────────────────────────────────────────────────────────

def ask_user_node(state: AgentState) -> dict:
    """
    Terminal node when clarification is required.

    Does not invoke any LLM — just lets the graph terminate gracefully.
    The API layer reads clarification_required=True and returns the
    clarification_options list to the frontend for action chip rendering.
    """
    # No LLM call needed — state already has clarification_required=True
    # and clarification_options populated by context_checker_node
    return {}


# ─────────────────────────────────────────────────────────────────────────────
# Build the LangGraph Workflow
# ─────────────────────────────────────────────────────────────────────────────

workflow = StateGraph(AgentState)

workflow.add_node("router", router_node)
workflow.add_node("context_checker", context_checker_node)
workflow.add_node("tools", tool_node)
workflow.add_node("synthesizer", synthesizer_node)
workflow.add_node("ask_user", ask_user_node)

workflow.set_entry_point("router")

# After router: tool call → context_checker | direct answer → synthesizer
workflow.add_conditional_edges(
    "router",
    should_continue,
    {"context_checker": "context_checker", "synthesizer": "synthesizer"},
)

# After context_checker: context OK → tools | missing → ask_user
workflow.add_conditional_edges(
    "context_checker",
    tool_router,
    {"tools": "tools", "ask_user": "ask_user"},
)

# Tools always feed into synthesizer for final NL formatting
workflow.add_edge("tools", "synthesizer")

# Synthesizer and ask_user are terminal
workflow.add_edge("synthesizer", END)
workflow.add_edge("ask_user", END)

aida_agent = workflow.compile()


