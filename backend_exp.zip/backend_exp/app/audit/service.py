from app.db.connection import get_pg_connection
from . import repository


class AuditService:

    def log_query(self, session_id, query, intent, execution_path, status, processing_time):

        with get_pg_connection() as conn:
            repository.insert_query_audit(
                conn,
                session_id,
                query,
                intent,
                execution_path,
                status,
                processing_time,
            )
