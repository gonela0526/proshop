"""Postgres connection pool.

Exports two helpers:
- `get_pg_pool_conn()`: returns a raw pooled `PooledConnection` object.
  Callers must call `.close()` themselves (put it back in the pool).
  Used by service classes that manage the lifecycle explicitly.

- `get_pg_connection()`: context manager that acquires a connection from
  the pool and guarantees it is returned when the block exits.
  Use with `with get_pg_connection() as conn:`.
"""

import os
from contextlib import contextmanager
from psycopg2 import pool
from app.utils.logger import setup_logger

logger = setup_logger()


class PooledConnection:
    """Wrap a pooled psycopg2 connection so `.close()` returns it to the pool."""

    def __init__(self, connection, pool_obj):
        self._connection = connection
        self._pool_obj = pool_obj
        self._closed = False

    def __getattr__(self, name):
        if self._closed:
            raise RuntimeError("Connection has already been released back to the pool.")
        return getattr(self._connection, name)

    def close(self):
        if not self._closed:
            self._pool_obj.putconn(self._connection)
            self._closed = True

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()
        return False


try:
    PG_POOL = pool.ThreadedConnectionPool(
        minconn=1,
        maxconn=20,
        host=os.getenv("DB_HOST", "136.16.208.30"),
        port=os.getenv("DB_PORT", "5432"),
        dbname=os.getenv("DB_NAME", "ai_test_db"),
        user=os.getenv("DB_USER", "app"),
        password=os.getenv("DB_PASSWORD", "agosense"),
    )
    logger.info("Postgres connection pool created successfully.")
except Exception as e:
    logger.error("Failed to initialize Postgres connection pool: %s", e)
    raise


def get_pg_pool_conn():
    """Return a raw pooled connection compatible with existing call sites.

    Callers must call `.close()` to return the connection to the pool.
    Prefer the `get_pg_connection()` context manager when possible.
    """
    connection = PG_POOL.getconn()
    return PooledConnection(connection, PG_POOL)


@contextmanager
def get_pg_connection():
    """Context manager: acquire a Postgres connection from the pool.

    Ensures the connection is returned to the pool automatically after use.

    Usage::

        with get_pg_connection() as conn:
            ...
    """
    conn = get_pg_pool_conn()
    try:
        yield conn
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Back-compat aliases — remove once all call sites have been migrated.
# ---------------------------------------------------------------------------
get_connection = get_pg_pool_conn          # was `get_connection`
get_db_connection = get_pg_connection      # was `get_db_connection`
