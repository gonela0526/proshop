-- =====================================
-- 1️⃣ OEMs
-- =====================================
CREATE TABLE IF NOT EXISTS oems (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) UNIQUE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- =====================================
-- 2️⃣ Projects
-- =====================================
CREATE TABLE IF NOT EXISTS projects (
    id SERIAL PRIMARY KEY,
    project_key VARCHAR(100) UNIQUE NOT NULL,
    oem_id INT REFERENCES oems(id) ON DELETE CASCADE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_project_oem
ON projects(oem_id);

-- =====================================
-- 3️⃣ Processes
-- =====================================
CREATE TABLE IF NOT EXISTS processes (
    id SERIAL PRIMARY KEY,
    project_id INT REFERENCES projects(id) ON DELETE CASCADE,
    process_name VARCHAR(255) NOT NULL,
    schedule VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_process_project
ON processes(project_id);

-- =====================================
-- 4️⃣ Config Entries (Dynamic)
-- =====================================
CREATE TABLE IF NOT EXISTS config_entries (
    id SERIAL PRIMARY KEY,
    process_id INT REFERENCES processes(id) ON DELETE CASCADE,
    config_key VARCHAR(255) NOT NULL,
    config_value TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_config_process
ON config_entries(process_id);

CREATE INDEX IF NOT EXISTS idx_config_key
ON config_entries(config_key);

-- =====================================
-- 5️⃣ Mapping Scenarios
-- =====================================
CREATE TABLE IF NOT EXISTS mapping_scenarios (
    id SERIAL PRIMARY KEY,
    process_id INT REFERENCES processes(id) ON DELETE CASCADE,
    scenario_name VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_mapping_process
ON mapping_scenarios(process_id);

-- =====================================
-- 6️⃣ Attribute Mappings (Field → Field)
-- =====================================
CREATE TABLE IF NOT EXISTS attribute_mappings (
    id SERIAL PRIMARY KEY,
    scenario_id INT REFERENCES mapping_scenarios(id) ON DELETE CASCADE,
    source_field VARCHAR(255) NOT NULL,
    destination_field VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_attr_scenario
ON attribute_mappings(scenario_id);

CREATE INDEX IF NOT EXISTS idx_attr_source
ON attribute_mappings(source_field);

CREATE INDEX IF NOT EXISTS idx_attr_destination
ON attribute_mappings(destination_field);

-- =====================================
-- 7️⃣ Value Mappings (Value → Value)
-- =====================================
CREATE TABLE IF NOT EXISTS value_mappings (
    id SERIAL PRIMARY KEY,
    attribute_mapping_id INT REFERENCES attribute_mappings(id) ON DELETE CASCADE,
    source_value VARCHAR(255) NOT NULL,
    destination_value VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_value_attr_map
ON value_mappings(attribute_mapping_id);

CREATE INDEX IF NOT EXISTS idx_value_source
ON value_mappings(source_value);

CREATE INDEX IF NOT EXISTS idx_value_destination
ON value_mappings(destination_value);


CREATE TABLE IF NOT EXISTS sessions (
    id UUID PRIMARY KEY,
    oem VARCHAR(100),
    project_key VARCHAR(100),
    process_name VARCHAR(255),
    last_query TEXT,
    pending_intent TEXT,
    last_response JSONB,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_sessions_updated
ON sessions(updated_at);


CREATE TABLE query_audit (
    id SERIAL PRIMARY KEY,

    session_id VARCHAR(100),
    query TEXT,

    detected_intent VARCHAR(100),
    execution_path VARCHAR(50),
    status VARCHAR(50),

    processing_time FLOAT,

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);



CREATE TABLE IF NOT EXISTS response_feedback (
    id SERIAL PRIMARY KEY,
    session_id UUID,
    query TEXT,
    intent VARCHAR(100),
    status VARCHAR(50),
    feedback VARCHAR(10), -- 'like' or 'dislike'
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_feedback_session
ON response_feedback(session_id);
