"""Oracle DB connection helper.

Exports `get_oracle_connection()` to clearly distinguish it from the
postgres pool in `app.db.connection` which exports `get_pg_connection()`.
"""

import os
import threading
import oracledb
from app.config.settings import ORACLE_DB_CONFIG
from app.utils.logger import setup_logger

logger = setup_logger()

_oracle_pool = None
_pool_lock = threading.Lock()
_oracle_client_initialized = False


def get_oracle_connection():
    """Acquire and return an Oracle DB connection from the shared session pool.

    Uses thick mode when an Instant Client path is configured and exists on disk;
    falls back to thin mode otherwise.
    The connection returned by `pool.acquire()` is compatible with existing `.close()` calls.
    """
    global _oracle_pool, _oracle_client_initialized

    if _oracle_pool is not None:
        return _oracle_pool.acquire()

    with _pool_lock:
        if _oracle_pool is None:
            lib_path = ORACLE_DB_CONFIG.get("path")
            if lib_path and os.path.exists(lib_path) and not _oracle_client_initialized:
                try:
                    oracledb.init_oracle_client(lib_dir=lib_path)
                    _oracle_client_initialized = True
                    logger.info("Oracle Instant Client initialized in thick mode.")
                except oracledb.ProgrammingError as e:
                    if "already initialized" in str(e).lower():
                        _oracle_client_initialized = True
                    else:
                        logger.error("Failed to initialize Oracle client in thick mode: %s", e)
                        raise

            try:
                # Create a session pool for Oracle
                _oracle_pool = oracledb.create_pool(
                    user=ORACLE_DB_CONFIG.get("user"),
                    password=ORACLE_DB_CONFIG.get("password"),
                    dsn=ORACLE_DB_CONFIG.get("dsn"),
                    min=1,
                    max=10,
                    increment=1,
                )
                logger.info("Oracle connection pool created successfully.")
            except Exception as e:
                logger.error("Failed to create Oracle connection pool: %s", e)
                raise

    return _oracle_pool.acquire()

