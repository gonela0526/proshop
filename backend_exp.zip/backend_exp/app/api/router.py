"""
AIDA Chat API Router
====================
Exposes POST /agent/chat — the single entry point for all Chainlit requests.

Key responsibilities:
1. Intercept __select_* magic tokens and return early without invoking the
   LangGraph agent (these are context-update signals from the UI, not queries).
2. Build the full AgentState from the request payload.
3. Invoke the compiled LangGraph workflow.
4. Map the final state to a clean HTTP response the frontend understands.
"""

from fastapi import APIRouter, Depends, Request
from pydantic import BaseModel
from typing import Optional, List, Dict, Any
from langchain_core.messages import HumanMessage, AIMessage, BaseMessage

from app.auth.dependencies import (
    get_authorization_context,
)

from app.auth.schema import (
    AuthorizationContext,
)

from app.agent.workflow import aida_agent

router = APIRouter()


# ─────────────────────────────────────────────────────────────────────────────
# Request model
# ─────────────────────────────────────────────────────────────────────────────

class ChatRequest(BaseModel):
    session_id: str
    query: str
    oem: Optional[str] = None
    project_key: Optional[str] = None
    process_name: Optional[str] = None
    timezone: Optional[str] = None
    # Expected: [{"role": "user", "content": "..."}, {"role": "ai", "content": "..."}]
    history: Optional[List[Dict[str, str]]] = None


# ─────────────────────────────────────────────────────────────────────────────
# Magic token interception helpers
# ─────────────────────────────────────────────────────────────────────────────

_MAGIC_PREFIXES = ("__select_oem__=", "__select_project__=", "__select_process__=")


def _is_magic_token(query: str) -> bool:
    return any(query.startswith(p) for p in _MAGIC_PREFIXES)


def _handle_magic_token(query: str, oem, project_key, process_name) -> dict:
    """
    Returns a lightweight 'context_update' response without invoking the agent.
    The actual context values are carried in the request payload fields
    (oem, project_key, process_name) which the frontend always sends correctly.
    We just need to acknowledge the update.
    """
    if query.startswith("__select_oem__="):
        val = query.split("=", 1)[1]
        return {
            "status": "success",
            "intent": "context_update",
            "data": f"OEM context updated to **{val}**.",
        }
    if query.startswith("__select_project__="):
        val = query.split("=", 1)[1]
        return {
            "status": "success",
            "intent": "context_update",
            "data": f"Project context updated to **{val}**.",
        }
    if query.startswith("__select_process__="):
        val = query.split("=", 1)[1]
        return {
            "status": "success",
            "intent": "context_update",
            "data": f"Process context updated to **{val}**.",
        }
    return {"status": "success", "intent": "context_update", "data": "Context updated."}


# ─────────────────────────────────────────────────────────────────────────────
# Chat endpoint
# ─────────────────────────────────────────────────────────────────────────────

@router.post("/chat")
async def handle_chat(
    http_request: Request,
    request: ChatRequest,
    authorization: AuthorizationContext = Depends(
        get_authorization_context
    )):
    # ── 1. Intercept magic context-update tokens (don't run the LLM for these) ──
    if request.query.strip() and _is_magic_token(request.query.strip()):
        return _handle_magic_token(
            request.query.strip(),
            request.oem,
            request.project_key,
            request.process_name,
        )

    # ── 2. Build LangChain message history ────────────────────────────────────
    langchain_messages: List[BaseMessage] = []
    if request.history:
        for msg in request.history:
            role = msg.get("role", "")
            content = msg.get("content", "")
            # Skip any magic token messages that leaked into history
            if content.startswith("__select_"):
                continue
            if role == "user":
                langchain_messages.append(HumanMessage(content=content))
            elif role == "ai":
                langchain_messages.append(AIMessage(content=content))

    # Append current query as the latest human message
    query = request.query.strip()
    if query:
        langchain_messages.append(HumanMessage(content=query))

    # ── 3. Determine context_source ───────────────────────────────────────────
    # If the frontend has sent oem/project/process, it means the user explicitly
    # selected them via the settings panel — mark as ui_selection so the router
    # LLM knows NOT to ask for them again.
    has_ui_context = bool(request.oem or request.project_key or request.process_name)
    context_source = "ui_selection" if has_ui_context else "none"

    # ── 4. Build AgentState ───────────────────────────────────────────────────
    state = {
        "messages": langchain_messages,
        "authorization": authorization,
        # Context group
        "oem": request.oem,
        "project_key": request.project_key,
        "process_name": request.process_name,
        "timezone": request.timezone or "America/New_York",
        "context_source": context_source,
        # Clarification group (defaults)
        "clarification_required": False,
        "missing_context_field": None,
        "clarification_options": None,
        # Tool tracking group (defaults)
        "last_tool_name": None,
        "last_tool_result": None,
        "tool_error": None,
        # Response metadata group (defaults)
        "intent": None,
        "response_ready": False,
    }

    # ── 5. Run the LangGraph agent ────────────────────────────────────────────
    try:
        final_state = await aida_agent.ainvoke(state)
    except Exception as exc:
        return {
            "status": "error",
            "intent": "error",
            "message": f"An unexpected error occurred: {exc}",
        }

    # ── 6. Map final state → HTTP response ────────────────────────────────────

    # Clarification required — return options list for frontend chip rendering
    if final_state.get("clarification_required"):
        missing = final_state.get("missing_context_field", "context")
        options = final_state.get("clarification_options") or []
        
        msg = f"I need a bit more context. Please select a {missing} to continue."
        if missing == "defect_id":
            msg = "Please provide the defect ID(s) you would like to sync (e.g. JIRA-123)."
            
        return {
            "status": "clarification_required",
            "missing": missing,
            "message": msg,
            "clarification_options": options,
        }

    # Normal success — extract the last synthesized message
    messages = final_state.get("messages", [])
    if not messages:
        return {
            "status": "error",
            "intent": "error",
            "message": "The agent returned an empty response.",
        }

    last_msg = messages[-1]
    final_text = getattr(last_msg, "content", "") or ""

    # Strip any accidental empty responses
    if not final_text.strip():
        return {
            "status": "error",
            "intent": "error",
            "message": "The agent returned a blank response. Please try again.",
        }

    # Calculate token usage and tool call counts for new messages in this turn
    try:
        from langchain_core.messages import ToolMessage
        num_input_messages = len(langchain_messages)
        new_messages = messages[num_input_messages:]
        input_tokens = 0
        output_tokens = 0
        tool_calls_count = 0
        for msg in new_messages:
            if isinstance(msg, AIMessage):
                meta = getattr(msg, "response_metadata", {}) or {}
                token_usage = meta.get("token_usage") or {}
                p_tokens = meta.get("prompt_eval_count") or token_usage.get("prompt_tokens") or 0
                c_tokens = meta.get("eval_count") or token_usage.get("completion_tokens") or 0
                input_tokens += p_tokens
                output_tokens += c_tokens
            elif isinstance(msg, ToolMessage):
                tool_calls_count += 1

        tool_used = final_state.get("last_tool_name") or final_state.get("intent") or "general"

        from app.monitoring import log_conversation
        log_conversation(
            session_id=request.session_id,
            question=request.query,
            response_given=final_text,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            tool_used=tool_used,
            tool_calls_count=tool_calls_count,
            oem=request.oem,
            project_key=request.project_key,
            process_name=request.process_name
        )
    except Exception as log_exc:
        # Silently fail logging so it doesn't block user chat responses
        pass

    # Extract Job ID from raw tool result for trigger_sync so the frontend
    # doesn't have to regex-parse the LLM's reformatted prose.
    job_id = None
    intent = final_state.get("intent") or "ai"
    if intent == "trigger_sync":
        raw_tool_result = final_state.get("last_tool_result") or ""
        import re
        job_match = re.search(r"Job ID:\s*([a-fA-F0-9\-]{36})", raw_tool_result)
        if job_match:
            job_id = job_match.group(1)

    result = {
        "status": "success",
        "intent": intent,
        "data": final_text,
        # Optional debug metadata (frontend can ignore)
        "meta": {
            "tool_used": final_state.get("last_tool_name"),
            "tool_error": final_state.get("tool_error"),
            "context_source": final_state.get("context_source"),
        },
    }
    if job_id:
        result["job_id"] = job_id
    return result


