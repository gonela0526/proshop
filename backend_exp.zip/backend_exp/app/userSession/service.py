from app.userSession.repository import UserSessionRepository

from app.jiraOAuth.service import JiraOAuthService
from app.auth.service import AuthService
from app.userSession.schema import (
    UserInfo,
    SessionContext,
    SessionResponse,
)

from datetime import datetime
from fastapi import Request


class UserSessionService:

    def __init__(self):
        self.jira_service = JiraOAuthService()
        self.repository = UserSessionRepository()
        self.auth_service = AuthService()

    def create_session(self, email: str):

        return self.repository.create_session(email)

    def validate_session(self, session_id: str):

        return self.repository.get_session(session_id)

    def extend_session(self, session_id: str):

        self.repository.update_session(session_id)

    def logout(self, session_id: str):

        self.repository.delete_session(session_id)

    async def initialize_session(self, session_id: str | None):
    
            if session_id is None:
                return SessionResponse(
                    connected=False,
                    authorization_url=None,
                    user=None,
                    context=None
                )
    
            user_session = self.validate_session(session_id)
    
            if user_session is None:
                return SessionResponse(
                    connected=False,
                    authorization_url=None,
                    user=None,
                    context=None
                )
    
            # extend browser session
            self.extend_session(session_id)
    
            email = user_session["email"]
            print("email =", email)
    
            jira_response = await self.jira_service.get_projects(email)
    
            if not jira_response.connected:
                authorization_url = await self.auth_service.start_authentication()
    
                return SessionResponse(
                    connected=False,
                    authorization_url=authorization_url,
                    user=None,
                    context=None
                )
    
            connection = self.jira_service.repository.get_connection(email)
    
            return SessionResponse(
                connected=True,
                authorization_url=None,
                user=UserInfo(
                    jira_account_id=connection["jira_account_id"]
                ),
                context=SessionContext(
                    initialized_at=datetime.utcnow(),
                    projects=jira_response.projects
                )
            )


    async def bootstrap(self, request: Request):
    
            session_id = request.cookies.get("AIDA_SESSION")
    
            if session_id is None:
                authorization_url = await self.auth_service.start_authentication()
                return authorization_url
    
            session = self.validate_session(session_id)
    
            if session is None:
                authorization_url = await self.auth_service.start_authentication()
                return authorization_url
    
            self.extend_session(session_id)
    
            return "/chat"