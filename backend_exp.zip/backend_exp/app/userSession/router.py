from dataclasses import asdict

from fastapi import APIRouter, Request, HTTPException

from app.userSession.service import UserSessionService

router = APIRouter(
    prefix="/api/session",
    tags=["Session"]
)

service = UserSessionService()


@router.post("/init")
async def initialize(request: Request):

    session_id = request.cookies.get(
        "AIDA_SESSION"
    )
    print("Session ID from cookie:", session_id)

    response =  await service.initialize_session(
        session_id
    )
    print("Session Response:", response)
    return asdict(response)



@router.get("/me")
async def get_current_user(request: Request):

    session_id = request.cookies.get("AIDA_SESSION")

    if not session_id:
        raise HTTPException(
            status_code=401,
            detail="AIDA session not found."
        )

    user_session = service.validate_session(session_id)

    if not user_session:
        raise HTTPException(
            status_code=401,
            detail="Invalid or expired AIDA session."
        )

    return {
        "authenticated": True,
        "email": user_session["email"]
    }