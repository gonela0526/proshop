import uuid
from datetime import datetime, timedelta

from app.db.connection import get_pg_connection


class UserSessionRepository:

    SESSION_DURATION_HOURS = 8

    def create_session(self, email: str):

        session_id = str(uuid.uuid4())

        expires_at = datetime.now() + timedelta(hours=self.SESSION_DURATION_HOURS)

        with get_pg_connection() as conn:
            cursor = conn.cursor()
            try:
                cursor.execute(
                    """
                    INSERT INTO user_sessions
                    (
                        session_id,
                        email,
                        expires_at
                    )
                    VALUES
                    (
                        %s,
                        %s,
                        %s
                    )
                    """,
                    (
                        session_id,
                        email,
                        expires_at
                    )
                )

                conn.commit()
            finally:
                cursor.close()
                conn.close()

        return session_id

    def get_session(self, session_id: str):
        with get_pg_connection() as conn:
            try:
                cursor = conn.cursor()
                cursor.execute(
                    """
                    SELECT
                        email,
                        expires_at
                    FROM user_sessions
                    WHERE session_id=%s
                    """,
                    (session_id,)
                )
                row = cursor.fetchone()
                if row is None:
                    return None
                
                if row[1] < datetime.now():
                    return None

                return { "email": row[0] }
            finally:
                cursor.close()
                conn.close()

        

    def update_session(self, session_id: str):

        expires_at = datetime.now() + timedelta(hours=self.SESSION_DURATION_HOURS)

        with get_pg_connection() as conn:
            try:
                cursor = conn.cursor()
                cursor.execute(
                    """
                    UPDATE user_sessions
                    SET
                        last_accessed=%s,
                        expires_at=%s
                    WHERE session_id=%s
                    """,
                    (
                        datetime.now(),
                        expires_at,
                        session_id
                    )
                )

                conn.commit()
                
            finally:
                cursor.close()
                conn.close()


        

    def delete_session(self, session_id: str):

        with get_pg_connection() as conn:
            try:
                cursor = conn.cursor()

                cursor.execute(
                    """
                    DELETE FROM user_sessions
                    WHERE session_id=%s
                    """,
                    (session_id,)
                )

                conn.commit()

            finally:
                cursor.close()
                conn.close()
