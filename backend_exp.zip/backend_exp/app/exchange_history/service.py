"""Exchange history service.

Queries Oracle DB for defect sync history, failure summaries, and top
failure reasons.  All DB access goes through `get_oracle_connection()`.
"""

from app.db.oracle_connection import get_oracle_connection
from app.utils.logger import setup_logger
from . import repository
from app.utils.defect_parser import extract_defect_ids
from app.utils.time_parser import extract_time_range
from collections import defaultdict
from datetime import datetime
import re

logger = setup_logger()


class ExchangeHistoryService:

    # ------------------------------------------------------------------
    # Defect History
    # ------------------------------------------------------------------

    def get_history(self, query_text: str):
        defect_ids = extract_defect_ids(query_text)
        _, _ = extract_time_range(query_text)  # parsed but not used here yet

        if not defect_ids:
            return {
                "status": "clarification_required",
                "message": "Please provide at least one defect ID.",
            }

        conn = get_oracle_connection()
        try:
            rows = repository.get_exchange_history_for_defects(conn, defect_ids)
        finally:
            conn.close()

        if not rows:
            return {"status": "not_found", "defects": defect_ids}

        return {"status": "success", "results": rows}

    # ------------------------------------------------------------------
    # Failure Summary
    # ------------------------------------------------------------------

    def get_failure_summary(self, query_text: str, project_key: str):

        # --- Extract direction ---
        direction_match = re.search(r"\b(\w+to\w+)\b", query_text)
        direction = direction_match.group(1) if direction_match else None

        # --- Extract time range ---
        start_time, end_time = extract_time_range(query_text)

        conn = get_oracle_connection()
        try:
            rows = repository.get_failed_defects(
                conn,
                project_key=project_key,
                direction=direction,
            )
        except Exception as e:
            logger.error("DB error in get_failed_defects: %s", e)
            raise
        finally:
            conn.close()

        results = []
        unique_defects: set = set()
        directions_seen: set = set()

        for row in rows:
            source_id, dest_id, status, desc, processid = row

            timestamp_part, dir_value = processid.split("_", 1)
            dt = datetime.strptime(timestamp_part, "%y%m%d%H%M%S")

            # --- Apply time filter ---
            if start_time and end_time:
                if not (start_time <= dt <= end_time):
                    continue

            defect_id = source_id if source_id else dest_id

            results.append(
                {
                    "defect_id": defect_id,
                    "timestamp": dt.isoformat(),
                    "direction": dir_value,
                    "message": desc,
                }
            )

            unique_defects.add(defect_id)
            directions_seen.add(dir_value)

        # Sort once, AFTER the loop — not inside it
        results.sort(key=lambda x: x["timestamp"], reverse=True)

        page = 1
        page_size = 20
        start_index = (page - 1) * page_size
        end_index = start_index + page_size
        paginated_results = results[start_index:end_index]

        return {
            "status": "success",
            "filters_applied": {
                "project_key": project_key,
                "direction": direction,
                "time_range": {
                    "start": start_time.isoformat() if start_time else None,
                    "end": end_time.isoformat() if end_time else None,
                },
            },
            "summary": {
                "total_failures": len(results),
                "unique_defects": len(unique_defects),
                "directions_involved": list(directions_seen),
            },
            "failures": paginated_results,
        }

    def get_failure_summary_direct(self, project_key: str, direction: str = None, hours: int = 24):
        """Clean method that takes direct parameters instead of regex parsing a query text."""
        from datetime import timedelta
        now = datetime.utcnow()
        start_time = now - timedelta(hours=hours)
        end_time = now
        
        conn = get_oracle_connection()
        try:
            rows = repository.get_failed_defects(
                conn,
                project_key=project_key,
                direction=direction,
            )
        except Exception as e:
            logger.error("DB error in get_failed_defects: %s", e)
            raise
        finally:
            conn.close()

        results = []
        unique_defects: set = set()
        directions_seen: set = set()

        for row in rows:
            source_id, dest_id, status, desc, processid = row

            timestamp_part, dir_value = processid.split("_", 1)
            dt = datetime.strptime(timestamp_part, "%y%m%d%H%M%S")

            # Apply time filter
            if start_time and end_time:
                if not (start_time <= dt <= end_time):
                    continue

            defect_id = source_id if source_id else dest_id

            results.append(
                {
                    "defect_id": defect_id,
                    "timestamp": dt.isoformat(),
                    "direction": dir_value,
                    "message": desc,
                }
            )

            unique_defects.add(defect_id)
            directions_seen.add(dir_value)

        results.sort(key=lambda x: x["timestamp"], reverse=True)

        page = 1
        page_size = 20
        start_index = (page - 1) * page_size
        end_index = start_index + page_size
        paginated_results = results[start_index:end_index]

        return {
            "status": "success",
            "filters_applied": {
                "project_key": project_key,
                "direction": direction,
                "time_range": {
                    "start": start_time.isoformat() if start_time else None,
                    "end": end_time.isoformat() if end_time else None,
                },
            },
            "summary": {
                "total_failures": len(results),
                "unique_defects": len(unique_defects),
                "directions_involved": list(directions_seen),
            },
            "failures": paginated_results,
        }

    # ------------------------------------------------------------------
    # Top Failure Reasons
    # ------------------------------------------------------------------

    def get_top_failure_reasons(self, query_text: str):
        query_upper = query_text.upper()

        # --- Extract project ---
        project_match = re.search(r"for\s+([A-Z0-9]+)", query_upper)
        project_key = project_match.group(1) if project_match else None

        # --- Extract direction ---
        direction_match = re.search(r"\b(\w+to\w+)\b", query_text)
        direction = direction_match.group(1) if direction_match else None

        # --- Extract time ---
        start_time, end_time = extract_time_range(query_text)

        conn = get_oracle_connection()
        try:
            rows = repository.get_failed_defects(
                conn,
                project_key=project_key,
                direction=direction,
            )
        finally:
            conn.close()

        reason_counter: dict = defaultdict(int)
        total_failures = 0

        for row in rows:
            source_id, dest_id, status, desc, processid = row

            timestamp_part, _ = processid.split("_", 1)
            dt = datetime.strptime(timestamp_part, "%y%m%d%H%M%S")

            # Apply time filter
            if start_time and end_time:
                if not (start_time <= dt <= end_time):
                    continue

            reason_counter[desc] += 1
            total_failures += 1

        sorted_reasons = sorted(
            reason_counter.items(),
            key=lambda x: x[1],
            reverse=True,
        )

        top_n = 5
        top_reasons = [
            {"reason": reason, "count": count}
            for reason, count in sorted_reasons[:top_n]
        ]

        return {
            "status": "success",
            "filters_applied": {
                "project_key": project_key,
                "direction": direction,
                "time_range": {
                    "start": start_time.isoformat() if start_time else None,
                    "end": end_time.isoformat() if end_time else None,
                },
            },
            "summary": {
                "total_failures": total_failures,
                "unique_reasons": len(reason_counter),
            },
            "top_failure_reasons": top_reasons,
        }

    def get_top_failure_reasons_direct(self, project_key: str, direction: str = None, hours: int = 24):
        """Clean method that takes direct parameters instead of regex parsing a query text."""
        from datetime import timedelta
        now = datetime.utcnow()
        start_time = now - timedelta(hours=hours)
        end_time = now

        conn = get_oracle_connection()
        try:
            rows = repository.get_failed_defects(
                conn,
                project_key=project_key,
                direction=direction,
            )
        finally:
            conn.close()

        reason_counter: dict = defaultdict(int)
        total_failures = 0

        for row in rows:
            source_id, dest_id, status, desc, processid = row

            timestamp_part, _ = processid.split("_", 1)
            dt = datetime.strptime(timestamp_part, "%y%m%d%H%M%S")

            # Apply time filter
            if start_time and end_time:
                if not (start_time <= dt <= end_time):
                    continue

            reason_counter[desc] += 1
            total_failures += 1

        sorted_reasons = sorted(
            reason_counter.items(),
            key=lambda x: x[1],
            reverse=True,
        )

        top_n = 5
        top_reasons = [
            {"reason": reason, "count": count}
            for reason, count in sorted_reasons[:top_n]
        ]

        return {
            "status": "success",
            "filters_applied": {
                "project_key": project_key,
                "direction": direction,
                "time_range": {
                    "start": start_time.isoformat() if start_time else None,
                    "end": end_time.isoformat() if end_time else None,
                },
            },
            "summary": {
                "total_failures": total_failures,
                "unique_reasons": len(reason_counter),
            },
            "top_failure_reasons": top_reasons,
        }

    # ------------------------------------------------------------------
    # Global Health
    # ------------------------------------------------------------------

    def get_global_health(self):
        from datetime import timedelta

        now = datetime.utcnow()
        last_1_days = now - timedelta(days=1)
        previous_1_days = last_1_days - timedelta(days=1)

        conn = get_oracle_connection()
        try:
            rows = repository.get_all_failures(conn)
        finally:
            conn.close()

        total_today = 0
        total_last_1 = 0
        total_previous_1 = 0
        direction_counter: dict = {}

        for row in rows:
            source_id, dest_id, status, desc, processid = row

            timestamp_part, direction = processid.split("_", 1)
            dt = datetime.strptime(timestamp_part, "%y%m%d%H%M%S")

            if dt.date() == now.date():
                total_today += 1

            if last_1_days <= dt <= now:
                total_last_1 += 1

            if previous_1_days <= dt < last_1_days:
                total_previous_1 += 1

            direction_counter[direction] = direction_counter.get(direction, 0) + 1

        trend = None
        if total_previous_1 > 0:
            trend = round(
                ((total_last_1 - total_previous_1) / total_previous_1) * 100, 2
            )

        return {
            "summary": {
                "failures_today": total_today,
                "failures_last_1_days": total_last_1,
                "failures_previous_1_days": total_previous_1,
                "trend_percentage": trend,
                "direction_distribution": direction_counter,
            }
        }
