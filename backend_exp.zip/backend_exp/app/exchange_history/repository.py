from datetime import datetime, timedelta
from collections import defaultdict
from app.utils.time_parser import extract_date_from_process_id


def get_exchange_history_for_defects_old(conn, defect_ids: list):
    final_output = {}
    cur = conn.cursor()

    try:
        for input_id in defect_ids:
            # --- STEP 1: Get 'Created' metadata ---
            query_meta = """
                SELECT sourcewiid, destinationwiid, processid
                FROM exchangedescription 
                WHERE (sourcewiid = :id OR destinationwiid = :id) 
                  AND status = 'Created'
                ORDER BY processid DESC
            """
            cur.execute(query_meta, {"id": input_id})
            meta_row = cur.fetchone()

            related_ids = [meta_row[0], meta_row[1]] if meta_row else [input_id]
            
            created_date = "N/A"
            if meta_row and len(meta_row[2]) >= 6:
                p_id = meta_row[2]
                created_date = f"{p_id[4:6]}-{p_id[2:4]}-20{p_id[0:2]}"

            # --- STEP 2: Fetch Top 5 History Rows ---
            placeholders = [f":v{i}" for i in range(len(related_ids))]
            history_sql = f"""
                SELECT * FROM (
                    SELECT ed.*, 
                    ROW_NUMBER() OVER (PARTITION BY ed.sourcewiid ORDER BY ed.processid DESC) as rank_per_id
                    FROM exchangedescription ed 
                    WHERE ed.sourcewiid IN ({",".join(placeholders)})
                ) WHERE rank_per_id <= 5
                ORDER BY processid DESC
            """
            
            bind_params = {f"v{i}": val for i, val in enumerate(related_ids)}
            cur.execute(history_sql, bind_params)
            
            cols = [col[0].lower() for col in cur.description]
            history_rows = [dict(zip(cols, row)) for row in cur.fetchall()]

            # --- STEP 3: Group by Direction ---
            # Using a dictionary to group rows by their direction string
            grouped_history = defaultdict(list)
            for row in history_rows:
                proc_id = str(row.get('processid', ''))
                direction = proc_id.split('_')[-1] if '_' in proc_id else "unknown"
                grouped_history[direction].append(row)
                row['processid'] = extract_date_from_process_id(proc_id)  # Convert processid to date format for output

            # --- STEP 4: Format the Grouped History ---
            formatted_history_list = []
            for direction, rows in grouped_history.items():
                # Since we ordered by processid DESC, the first row is the latest
                latest_row = rows[0]
                failed_message = ""
                if latest_row.get('status') == 'Failed':
                    failed_message = latest_row.get('description')
                
                formatted_history_list.append({
                    "direction": direction,
                    "latest_status": latest_row.get('status'),
                    "failed_message": failed_message,
                    "latest_timestamp": latest_row.get('processid'),
                    "raw_data": rows  # This now contains all 5 (or fewer) rows for this direction
                })

            # --- STEP 5: Final Object ---
            final_output[input_id] = {
                "Created": created_date,
                "sourceid": meta_row[0] if meta_row else input_id,
                "destinationid": meta_row[1] if meta_row else "N/A",
                "history": formatted_history_list
            }

        return final_output
    

    except Exception as e:
        import logging
        logging.getLogger("exchange_engine").error("Database error in get_exchange_history_for_defects_old: %s", e)
        return {}
    finally:
        cur.close()



def get_exchange_history_for_defects(conn, defect_ids: list):
    if not defect_ids:
        return {}

    final_output = {}
    cur = conn.cursor()
    
    try:
        # STEP 1: Batch fetch 'Created' metadata for ALL IDs at once
        placeholders = [f":id{i}" for i in range(len(defect_ids))]
        meta_sql = f"""
            SELECT sourcewiid, destinationwiid, processid
            FROM exchangedescription 
            WHERE (sourcewiid IN ({','.join(placeholders)}) 
               OR destinationwiid IN ({','.join(placeholders)}))
              AND status = 'Created'
        """
        # Map IDs to bind variables
        bind_meta = {f"id{i}": d_id for i, d_id in enumerate(defect_ids)}
        cur.execute(meta_sql, bind_meta)
        
        # Store relations in a lookup map
        # We use a set for related_ids to ensure uniqueness
        id_relations = {d_id: {d_id} for d_id in defect_ids}
        meta_data_map = {}

        for s_id, d_id, p_id in cur.fetchall():
            # Find which input_id this record belongs to
            for input_id in defect_ids:
                if s_id == input_id or d_id == input_id:
                    id_relations[input_id].add(s_id)
                    id_relations[input_id].add(d_id)
                    meta_data_map[input_id] = (s_id, d_id, p_id)

        # STEP 2: Collect every unique ID we need to look up in history
        all_unique_lookups = list({item for sublist in id_relations.values() for item in sublist})
        
        # STEP 3: Batch fetch Top 5 History for ALL unique IDs in ONE query
        h_placeholders = [f":h{i}" for i in range(len(all_unique_lookups))]
        history_sql = f"""
            SELECT * FROM (
                SELECT ed.*, 
                ROW_NUMBER() OVER (PARTITION BY ed.sourcewiid ORDER BY ed.processid DESC) as rank_per_id
                FROM exchangedescription ed 
                WHERE ed.sourcewiid IN ({",".join(h_placeholders)})
            ) WHERE rank_per_id <= 5
        """
        bind_history = {f"h{i}": val for i, val in enumerate(all_unique_lookups)}
        cur.execute(history_sql, bind_history)
        
        cols = [col[0].lower() for col in cur.description]
        all_raw_rows = [dict(zip(cols, row)) for row in cur.fetchall()]

        # STEP 4: Reconstruct the results in Python (No more DB calls)
        for input_id in defect_ids:
            related_set = id_relations[input_id]
            meta = meta_data_map.get(input_id)
            
            # Filter history rows belonging to this specific input_id group
            relevant_history = [r for r in all_raw_rows if r['sourcewiid'] in related_set]
            
            # Group by direction
            grouped_history = defaultdict(list)
            for row in relevant_history:
                direction = str(row['processid']).split('_')[-1] if '_' in str(row['processid']) else "unknown"
                grouped_history[direction].append(row)
                row['processid'] = extract_date_from_process_id(str(row['processid']))  # Convert processid to date format for output

            # Format history list
            formatted_history = []
            for direction, rows in grouped_history.items():
                latest = rows[0]
                failed_message = ""
                if latest.get('status') == 'Failed':
                    failed_message = latest.get('description')
                formatted_history.append({
                    "direction": direction,
                    "latest_status": latest.get('status'),
                    "failed_message": failed_message,
                    "latest_timestamp": latest.get('processid'),
                    "raw_data": rows
                })

            # Extract date for the 'Created' field
            p_id_created = meta[2] if meta else "N/A"
            created_fmt = "N/A"
            if p_id_created != "N/A" and len(p_id_created) >= 6:
                created_fmt = f"{p_id_created[4:6]}-{p_id_created[2:4]}-20{p_id_created[0:2]}"

            final_output[input_id] = {
                "Created": created_fmt,
                "sourceid": meta[0] if meta else input_id,
                "destinationid": meta[1] if meta else "N/A",
                "history": formatted_history
            }

        return final_output

    finally:
        cur.close()


def get_failed_defects(conn, project_key=None, start_time=None, end_time=None, direction=None):
    # Build the inner query
    inner = """
        SELECT 
            ed.sourcewiid,
            ed.destinationwiid,
            ed.status,
            ed.description,
            ed.processid
        FROM exchangedescription ed
        WHERE UPPER(ed.status) = 'FAILED'
    """

    params = {}

    # Date range: last 1 day (as in your example)
    inner += " AND TO_DATE(SUBSTR(ed.processid, 1, 12), 'YYMMDDHH24MISS') BETWEEN :start_dt AND :end_dt"
    today = datetime.now()
    today_start = today.replace(hour=0, minute=0, second=0, microsecond=0)
    start_dt = today_start - timedelta(days=1)
    end_dt = today
    params["start_dt"] = start_dt
    params["end_dt"] = end_dt

    if project_key:
        inner += " AND (UPPER(ed.sourcewiid) LIKE :src OR UPPER(ed.destinationwiid) LIKE :dest)"
        prefix = f"{project_key.upper()}-%"
        params["src"] = prefix
        params["dest"] = prefix

    if direction:
        inner += " AND UPPER(ed.processid) LIKE :direction"
        params["direction"] = f"%{direction.upper()}%"

    # Optional: guard to avoid TO_DATE errors if processid isn't 12-digit prefix
    # inner += " AND REGEXP_LIKE(ed.processid, '^[0-9]{12}_')"

    # Order in inner query, then apply ROWNUM <= 50 outside
    inner += """
        ORDER BY TO_DATE(SUBSTR(ed.processid, 1, 12), 'YYMMDDHH24MISS') DESC
    """

    query = f"""
        SELECT * FROM (
            {inner}
        )
        WHERE ROWNUM <= 50
    """

    cur = conn.cursor()
    cur.execute(query, params)
    rows = cur.fetchall()
    cur.close()
    return rows


def get_all_failures(conn):
    cur = conn.cursor()
    cur.execute("""
        SELECT sourcewiid, destinationwiid, status, description, processid
        FROM exchangedescription
        WHERE status = 'Failed'
    """)
    rows = cur.fetchall()
    cur.close()
    return rows

