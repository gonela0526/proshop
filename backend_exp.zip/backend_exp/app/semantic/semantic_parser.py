import json
import os
import re
import requests
from dotenv import load_dotenv
from app.utils.logger import setup_logger

logger = setup_logger()
load_dotenv()


class SemanticParser:

    def __init__(self, model=None):
        self.model = model or os.getenv("OLLAMA_MODEL", "qwen2.5:7b")
        self.url = os.getenv("OLLAMA_BASE_URL", "http://136.16.200.40:11434/api/chat").rstrip("/")

    def parse(self, query: str):

        prompt = f"""
    You are a strict JSON parser.

    Return ONLY a valid JSON object with fields:
    intent, project_key, direction, time_filter.

    Allowed intents:
    defect_history_query
    failure_summary_query
    top_failure_reason_query
    schedule_query
    mapping_query
    config_query
    unknown

    If query contains ABC-123 or 123 → defect_history_query.
    If query contains issues/problems/failures → failure_summary_query.
    If query contains recently/lately → last_7_days.
    If no time mentioned → none.

    Do NOT invent values.
    Use null if project_key or direction not present.

    Query: {query}
    """

        try:
            response = requests.post(
            self.url,
            json={
                "model": self.model,
                "messages": [
                    {
                        "role": "system",
                        "content": "Respond ONLY with valid JSON. No explanations."
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                "stream": False,
                "options": {
                    "temperature": 0,
                    "num_predict": 150
                }
            },
            timeout=30
        )

            raw_text = response.json()["message"]["content"]
            logger.debug("semantic_parser raw_llm_output=%r", raw_text)
        except Exception as e:
            logger.error("semantic_parser error: %s", e)
            return {"intent": "unknown"}

        try:
            parsed = json.loads(raw_text)
            return parsed
        except:
            return {"intent": "unknown"}
