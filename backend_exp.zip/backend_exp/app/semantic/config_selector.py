import os
import requests
from dotenv import load_dotenv
from app.utils.logger import setup_logger

logger = setup_logger()
load_dotenv()

OLLAMA_URL = os.getenv("OLLAMA_BASE_URL", "http://136.16.200.40:11434/api/chat").rstrip("/")
MODEL_NAME = os.getenv("OLLAMA_MODEL", "qwen2.5:7b")


def select_config_key_via_llm(query: str, config_keys: list):

    logger.debug("select_config_key_via_llm called")

    if not config_keys:
        return None

    # Build numbered list
    key_list = "\n".join([f"{i+1}. {key}" for i, key in enumerate(config_keys)])

    prompt = f"""
You are a strict config key selector.

You must choose ONE config key from the provided list.

Rules:
- Return ONLY the exact config key name.
- Do NOT explain.
- Do NOT modify spelling.
- If none match, return NONE.

Config Keys:
{key_list}

User Query:
"{query}"
"""

    try:
        response = requests.post(
            OLLAMA_URL,
            json={
                "model": MODEL_NAME,
                "messages": [
                    {"role": "user", "content": prompt}
                ],
                "temperature": 0,
                "stream":False
            },
            timeout=20
        )

        data = response.json()
        logger.debug("config_selector raw_json=%s", data)

        raw_text = None

        # Handle both possible formats
        if "message" in data and "content" in data["message"]:
            raw_text = data["message"]["content"].strip()
        elif "response" in data:
            raw_text = data["response"].strip()

        if not raw_text:
            logger.warning("config_selector: LLM returned empty content")
            return None

        logger.debug("config_selector raw_output=%r", raw_text)

        cleaned = raw_text.replace('"', '').replace("`", "").strip()

        # Exact match
        if cleaned in config_keys:
            return cleaned

        # Substring match
        for key in config_keys:
            if key.lower() in cleaned.lower():
                return key

        return None

    except Exception as e:
        logger.error("config_selector error: %s", e)
        return None

