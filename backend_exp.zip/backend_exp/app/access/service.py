from app.jiraOAuth.service import JiraOAuthService
from app.userSession.service import UserSessionService
from app.auth.schema import AuthorizationContext


class AccessService:

    def __init__(self):
        self.jira_service = JiraOAuthService()
        self.user_session_service = UserSessionService()

    async def get_authorized_projects(
        self,
        session_id: str
    ):

        # 1. Validate browser authentication session
        user_session = (
            self.user_session_service.validate_session(
                session_id
            )
        )

        if not user_session:
            raise ValueError(
                "Invalid or expired AIDA session."
            )

        email = user_session["email"]

        # 2. JiraOAuthService already:
        #
        # Jira projects
        #       ∩
        # AIDA DB projects
        #
        # because we implemented this earlier.
        jira_response = await self.jira_service.get_projects(
            email
        )

        if not jira_response.connected:
            raise ValueError(
                "Jira connection is not available."
            )

        return jira_response.projects

    
    async def build_authorization_context(
        self,
        session_id: str) -> AuthorizationContext:
        
        user_session = self.user_session_service.validate_session(
            session_id
        )

        if not user_session:
            raise ValueError(
                "Invalid or expired AIDA session."
            )

        email = user_session["email"]

        authorized_projects = await self.get_authorized_projects(
            session_id
        )

        connection = self.jira_service.repository.get_connection(
            email
        )

        return AuthorizationContext(
            email=email,
            jira_account_id=connection["jira_account_id"],
            project_ids=[
                project.db_project_id
                for project in authorized_projects
            ],
            project_keys=[
                project.project_key
                for project in authorized_projects
            ],
            oem_ids=list(
                {
                    project.oem_id
                    for project in authorized_projects
                }
            ),
            projects=authorized_projects,
            session_id=session_id
        )