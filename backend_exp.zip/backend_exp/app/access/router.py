from dataclasses import asdict

from fastapi import APIRouter, Request, HTTPException

from app.access.service import AccessService


router = APIRouter(
    prefix="/api/access",
    tags=["Access"]
)

service = AccessService()


@router.get("/projects")
async def get_authorized_projects(
    request: Request
):

    session_id = request.cookies.get(
        "AIDA_SESSION"
    )

    if not session_id:
        raise HTTPException(
            status_code=401,
            detail="Authentication required."
        )

    try:
        projects = await service.get_authorized_projects(
            session_id
        )

        return {
            "projects": [
                asdict(project)
                for project in projects
            ]
        }

    except ValueError as exc:
        raise HTTPException(
            status_code=401,
            detail=str(exc)
        )