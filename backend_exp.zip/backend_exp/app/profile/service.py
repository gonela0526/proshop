from app.userSession.service import UserSessionService
from app.jiraOAuth.service import JiraOAuthService
from app.profile.schema import UserProfile


class ProfileService:

    def __init__(self):

        self.session_service = UserSessionService()

        self.jira_service = JiraOAuthService()

    async def get_profile(
        self,
        session_id: str,
    ) -> UserProfile:

        session = self.session_service.validate_session(
            session_id
        )

        if session is None:
            raise ValueError(
                "Invalid session."
            )

        profile = await self.jira_service.get_profile(
            session["email"]
        )

        return UserProfile(**profile)