from pydantic import BaseModel


class UserProfile(BaseModel):

    display_name: str

    email: str

    jira_account_id: str

    connected: bool