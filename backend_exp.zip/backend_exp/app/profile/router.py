from fastapi import APIRouter
from fastapi import Depends

from app.profile.service import ProfileService
from app.profile.schema import UserProfile
from app.auth.dependencies import (
    get_authorization_context,
)

router = APIRouter()

service = ProfileService()


@router.get( "/user/profile", response_model=UserProfile,)
async def get_profile(
    authorization=Depends(get_authorization_context),
    ):

    return await service.get_profile(
        authorization.session_id
    )