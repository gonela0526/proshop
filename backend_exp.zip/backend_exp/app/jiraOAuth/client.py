from urllib.parse import urlencode

import httpx

from app.config.settings import settings


class JiraClient:

    @staticmethod
    def get_authorization_url(state:str):

        params = {
            "audience": "api.atlassian.com",
            "client_id": settings.JIRA_CLIENT_ID,
            "scope": "offline_access read:me read:jira-user read:jira-work",
            "redirect_uri": settings.JIRA_REDIRECT_URI,
            "response_type": "code",
            "prompt": "consent",
            "state": state
        }

        return f"{settings.JIRA_AUTH_URL}?{urlencode(params)}"

    @staticmethod
    async def exchange_code(code: str):

        async with httpx.AsyncClient(
            proxy=settings.JIRA_PROXY,
            timeout=30) as client:

            response = await client.post(
                settings.JIRA_TOKEN_URL,
                data={
                    "grant_type": "authorization_code",
                    "client_id": settings.JIRA_CLIENT_ID,
                    "client_secret": settings.JIRA_CLIENT_SECRET,
                    "code": code,
                    "redirect_uri": settings.JIRA_REDIRECT_URI
                }
            )

        response.raise_for_status()
        return response.json()

    @staticmethod
    async def get_me(access_token: str):

        async with httpx.AsyncClient(
            proxy=settings.JIRA_PROXY,
            timeout=30) as client:

            response = await client.get(
                "https://api.atlassian.com/me",
                headers={
                    "Authorization": f"Bearer {access_token}"
                }
            )

        response.raise_for_status()

        return response.json()

    @staticmethod
    async def get_accessible_resources(access_token: str):

        async with httpx.AsyncClient(
            proxy=settings.JIRA_PROXY,
            timeout=30) as client:

            response = await client.get(
                "https://api.atlassian.com/oauth/token/accessible-resources",
                headers={
                    "Authorization": f"Bearer {access_token}"
                }
            )

        response.raise_for_status()

        return response.json()
    
    @staticmethod
    async def refresh_access_token(refresh_token: str):

        async with httpx.AsyncClient(
            proxy=settings.JIRA_PROXY,
            timeout=30
        ) as client:

            response = await client.post(
                settings.JIRA_TOKEN_URL,
                json={
                    "grant_type": "refresh_token",
                    "client_id": settings.JIRA_CLIENT_ID,
                    "client_secret": settings.JIRA_CLIENT_SECRET,
                    "refresh_token": refresh_token
                }
            )

        response.raise_for_status()

        return response.json()
    


    @staticmethod
    async def get_projects(
        cloud_id: str,
        access_token: str
    ):

        url = (
            f"https://api.atlassian.com/ex/jira/"
            f"{cloud_id}/rest/api/3/project"
        )

        async with httpx.AsyncClient(
            proxy=settings.JIRA_PROXY,
            timeout=30
        ) as client:

            response = await client.get(
                url,
                headers={
                    "Authorization": f"Bearer {access_token}",
                    "Accept": "application/json"
                }
            )

        response.raise_for_status()

        return response.json()