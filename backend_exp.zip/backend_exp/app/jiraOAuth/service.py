from datetime import datetime, timedelta

from app.jiraOAuth.client import JiraClient
from app.jiraOAuth.repository import JiraOAuthRepository
from app.jiraOAuth.schema import (
    JiraProject,
    JiraProjectsResponse
)

from app.services.config_service import ConfigService
from app.auth.repository import AuthRepository
from app.userSession.repository import UserSessionRepository
from app.config.settings import settings
from app.db.connection import get_pg_pool_conn as get_connection


class JiraOAuthService:

    def __init__(self):
        self.repository = JiraOAuthRepository()
        self.auth_repository = AuthRepository()
        self.config_service = ConfigService()
        self.user_session_repository = UserSessionRepository()

    async def exchange_code(self, code: str, state: str):

        # Validate OAuth state
        auth_request = self.auth_repository.get_request(state)

        if not auth_request:
            raise ValueError("Invalid OAuth state.")

        # Exchange authorization code
        token = await JiraClient.exchange_code(code)

        access_token = token["access_token"]
        refresh_token = token["refresh_token"]

        expires_at = datetime.now() + timedelta(
            seconds=token["expires_in"]
        )

        # Logged in Jira user
        me = await JiraClient.get_me(access_token)
        jira_email = me["email"]

        # Get Cloud Id
        resources = await JiraClient.get_accessible_resources(
            access_token
        )

        if not resources:
            raise Exception("No Jira Cloud instance found.")
        
        if not settings.JIRA_SITE_URL:
            raise ValueError("JIRA_SITE_URL is not set in the environment.")
        
        expected_site_url = settings.JIRA_SITE_URL.rstrip("/").lower()

        # IMPORTANT:
        # Never use resources[0].
        #
        # accessible-resources can contain multiple Jira sites,
        # and Atlassian does not guarantee their ordering.
        selected_resource = next(
            (
                resource
                for resource in resources
                if resource.get("url", "")
                .rstrip("/")
                .lower() == expected_site_url
            ),
            None
        )

        if selected_resource is None:
            available_sites = [
                resource.get("url")
                for resource in resources
                if resource.get("url")
            ]
            print(
                "Accessible Jira sites:",
                available_sites
            )

            raise ValueError(
                f"AIDA is restricted to Jira site "
                f"'{expected_site_url}', but the authenticated "
                f"user/token does not have access to that site."
            )


        cloud_id = selected_resource["id"]

        print(
            "Selected Jira site:",
            selected_resource.get("url")
        )

        print(
            "Selected Jira cloud_id:",
            cloud_id
        )

        # Save / Update OAuth details
        self.repository.save(
            email=jira_email,
            jira_account_id=me["account_id"],
            cloud_id=cloud_id,
            access_token=access_token,
            refresh_token=refresh_token,
            expires_at=expires_at
        )

        # Create browser session
        session_id = self.user_session_repository.create_session(
            jira_email
        )

        # OAuth state no longer needed
        self.auth_repository.delete_request(state)

        return session_id

    
    async def get_projects(self,email: str):
        connection = await self._get_valid_connection(email)

        if connection is None:

            return JiraProjectsResponse(
                connected=False,
                projects=[]
            )

        access_token = connection["access_token"]

        if datetime.now() >= connection["expires_at"]:

            token = await JiraClient.refresh_access_token(
                connection["refresh_token"]
            )

            access_token = token["access_token"]

            new_refresh_token = token.get("refresh_token", connection["refresh_token"])

            self.repository.update_tokens(
                connection["jira_account_id"],
                token["access_token"],
                new_refresh_token,
                datetime.now() + timedelta(
                    seconds=token["expires_in"]
                )
            )

        jira_projects = await JiraClient.get_projects(
            connection["cloud_id"],
            access_token
        )

        db_projects = self.config_service.list_all_projects()


        db_project_map = {
            project["project_key"].strip().upper(): project
            for project in db_projects
        }

        matched_projects = []

        for jira_project in jira_projects:

            project_key = jira_project["key"].strip().upper()

            db_project = db_project_map.get(project_key)

            if db_project is None:
                continue

            matched_projects.append(
                JiraProject(
                    jira_project_id=jira_project["id"],
                    project_key=project_key,
                    jira_project_name=jira_project["name"],
                    db_project_id=db_project["project_id"],
                    db_project_name=db_project["project_name"],
                    oem_id=db_project["oem_id"]
                )
            )

        return JiraProjectsResponse(
            connected=True,
            projects=matched_projects
        )

    
    async def get_profile( self, email: str, ):
        connection = await self._get_valid_connection(
            email
        )

        if connection is None:
            return None

        me = await JiraClient.get_me(
            connection["access_token"]
        )

        return {
            "display_name": me["display_name"],
            "email": me["email"],
            "jira_account_id": me["account_id"],
            "connected": True,
        }
    
    
    async def _get_valid_connection(self, email: str):

        connection = self.repository.get_connection(email)

        if connection is None:
            return None

        if datetime.now() < connection["expires_at"]:
            return connection

        token = await JiraClient.refresh_access_token(
            connection["refresh_token"]
        )

        self.repository.update_tokens(
            connection["jira_account_id"],
            token["access_token"],
            token.get(
                "refresh_token",
                connection["refresh_token"],
            ),
            datetime.now()
            + timedelta(seconds=token["expires_in"]),
        )

        return self.repository.get_connection(email)