from fastapi import APIRouter
from fastapi.responses import RedirectResponse

from app.jiraOAuth.service import JiraOAuthService
from dataclasses import asdict

CHAINLIT_URL = "http://reaenv0006.ctsread.visteon.com:8080/chat"

router = APIRouter(
    prefix="/api/jira/oauth",
    tags=["Jira OAuth"]
)

service = JiraOAuthService()


@router.get("/callback")
async def callback(code: str, state: str):

    session_id = await service.exchange_code(code, state)

    response =  RedirectResponse(
        url=CHAINLIT_URL
    )

    response.set_cookie(
        key="AIDA_SESSION",
        value=session_id,
        httponly=True,
        secure=False,
        samesite="lax",
        max_age=8 * 60 * 60
    )

    return response


@router.get("/projects")
async def get_projects(email: str):

    response = await service.get_projects(email)
    return asdict(response)