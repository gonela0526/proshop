import uuid

from app.db.connection import get_pg_connection


class JiraOAuthRepository:

    def save(
        self,
        email: str,
        jira_account_id: str,
        cloud_id: str,
        access_token: str,
        refresh_token: str,
        expires_at,
    ):
        query = """
            INSERT INTO jira_oauth (
                id,
                email,
                jira_account_id,
                cloud_id,
                access_token,
                refresh_token,
                expires_at
            )
            VALUES (%s, %s, %s, %s, %s, %s, %s)
            ON CONFLICT (jira_account_id)
            DO UPDATE SET
                email = EXCLUDED.email,
                cloud_id = EXCLUDED.cloud_id,
                access_token = EXCLUDED.access_token,
                refresh_token = EXCLUDED.refresh_token,
                expires_at = EXCLUDED.expires_at,
                updated_at = NOW();
        """

        params = (
            str(uuid.uuid4()),
            email,
            jira_account_id,
            cloud_id,
            access_token,
            refresh_token,
            expires_at,
        )

        # Context managers auto-commit and clean up connections reliably
        with get_pg_connection() as conn:
            try:
                cursor = conn.cursor()
                cursor.execute(query, params)
                conn.commit()
            finally:
                cursor.close()
                conn.close()



    def get_connection(self,email: str):

        with get_pg_connection() as conn:
            cursor = conn.cursor()
            try:
                cursor.execute("""
                        SELECT
                            jira_account_id,
                            cloud_id,
                            access_token,
                            refresh_token,
                            expires_at
                        FROM jira_oauth
                        WHERE email = %s
                """, (email,))
                
                row = cursor.fetchone()

                if row is None:
                    return None
            finally:
                cursor.close()
                conn.close()

        return {
            "jira_account_id": row[0],
            "cloud_id": row[1],
            "access_token": row[2],
            "refresh_token": row[3],
            "expires_at": row[4]
        }


    def update_tokens(
        self,
        jira_account_id,
        access_token,
        refresh_token,
        expires_at
    ):

        with get_pg_connection() as conn:
            try:
                cursor = conn.cursor()

                cursor.execute(
                    """
                    UPDATE jira_oauth
                    SET
                        access_token=%s,
                        refresh_token=%s,
                        expires_at=%s,
                        updated_at=NOW()
                    WHERE jira_account_id=%s
                    """,
                    (
                        access_token,
                        refresh_token,
                        expires_at,
                        jira_account_id
                    )
                )

                conn.commit()
            finally:
                cursor.close()
                conn.close()