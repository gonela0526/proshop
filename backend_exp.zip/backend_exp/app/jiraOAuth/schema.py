from dataclasses import dataclass
from datetime import datetime


@dataclass
class JiraOAuth:

    id: str

    jira_account_id: str

    cloud_id: str

    access_token: str

    refresh_token: str

    expires_at: datetime


@dataclass
class JiraProject:

    jira_project_id: str
    project_key: str
    jira_project_name: str
    db_project_id: int
    db_project_name: str
    oem_id: int


@dataclass
class JiraProjectsResponse:

    connected: bool
    projects: list[JiraProject]