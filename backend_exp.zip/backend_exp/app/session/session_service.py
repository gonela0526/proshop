from app.db.connection import get_pg_connection
from app.session import session_repository as repo


class SessionService:
    def create_session(self) -> str:
        with get_pg_connection() as conn:
            return repo.create_session(conn)

    def build_conversation_summary(self, current_summary, query, response):
        if current_summary and len(str(current_summary)) > 300:
            try:
                from app.ai.llm_service import LLMService
                llm = LLMService()
                compressed = llm.summarize_history(current_summary, query, response)
                if compressed:
                    return compressed
            except Exception:
                pass

        parts = []
        if current_summary:
            parts.append(str(current_summary))

        if query:
            parts.append(f"User asked: {query}")

        if isinstance(response, dict):
            intent = response.get("intent")
            status = response.get("status")
            if intent:
                parts.append(f"Handled as {intent}")
            if status:
                parts.append(f"Status: {status}")

        if not parts:
            return None

        summary = " | ".join(part for part in parts if part)
        return summary[:500]

    def get_session(self, session_id: str):
        with get_pg_connection() as conn:
            return repo.get_session(conn, session_id)

    def update_context(self,
                       session_id: str,
                       new_oem=None,
                       new_project=None,
                       new_process=None,
                       new_last_query=None,
                       new_pending_intent=None,
                       new_last_response=None):
                       
        with get_pg_connection() as conn:
            current = repo.get_session(conn, session_id)
            if not current:
                return None
                
            oem = current["oem"]
            project = current["project_key"]
            process = current["process_name"]
            last_query = current.get("last_query")
            pending_intent = current.get("pending_intent")
            last_response = current.get("last_response")

            # ----------------------------
            # Context Policy Rules
            # ----------------------------
            if new_oem is not None and new_oem != oem:
                oem = new_oem
                project = None
                process = None
            if new_project is not None and new_project != project:
                project = new_project
                process = None
            if new_process is not None:
                process = new_process
            if new_last_query is not None:
                last_query = new_last_query
            if new_last_response is not None:
                last_response = new_last_response
                if isinstance(last_response, dict):
                    current_summary = None
                    if isinstance(current.get("last_response"), dict):
                        current_summary = current["last_response"].get("conversation_summary")

                    last_response = dict(last_response)
                    last_response["conversation_summary"] = self.build_conversation_summary(
                        current_summary,
                        new_last_query if new_last_query is not None else last_query,
                        last_response
                    )
            if new_pending_intent is not None:
                pending_intent = new_pending_intent

            repo.update_session(
                conn,
                session_id=session_id,
                oem=oem,
                project_key=project,
                process_name=process,
                last_query=last_query,
                pending_intent=pending_intent,
                last_response=last_response
            )
            return {
                "oem": oem,
                "project_key": project,
                "process_name": process,
                "last_query": last_query,
                "pending_intent": pending_intent,
                "last_response": last_response
            }

    def store_feedback(self, session_id: str, query: str, intent: str, feedback: str):
        with get_pg_connection() as conn:
            repo.insert_feedback(
                conn,
                session_id,
                query,
                intent,
                feedback
            )