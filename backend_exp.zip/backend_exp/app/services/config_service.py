from typing import Optional, Dict, List
from app.db.connection import get_pg_pool_conn as get_connection
from app.utils.cron_utils import build_schedule_response
from app.utils.token_intersection import tokenize
from app.repositories import config_repository as repo
from app.utils.cache import timed_cache
from app.utils.logger import setup_logger

logger = setup_logger()


class ConfigService:

    # --------------------------------------------
    # OEM + Project Lookup
    # --------------------------------------------

    @timed_cache(ttl_seconds=300)
    def list_oems(self) -> List[Dict]:
        conn = get_connection()
        try:
            oems = repo.get_oems(conn)
            logger.debug("list_oems cache miss — fetched %d OEMs from DB", len(oems))
            return oems
        finally:
            conn.close()

    @timed_cache(ttl_seconds=300)
    def list_projects_by_oem(self, oem_name: str) -> List[Dict]:
        if not oem_name:
            return []
        conn = get_connection()
        try:
            projects = repo.get_projects_by_oem(conn, oem_name)
            logger.debug("list_projects_by_oem oem=%s cache miss — %d projects", oem_name, len(projects))
            return projects
        finally:
            conn.close()

    def find_project(self, identifier: str) -> List[Dict]:
        """
        Supports both:
        - Exact key match
        - Fuzzy name match
        """
        conn = get_connection()
        try:
            # Try exact key
            exact = repo.find_project_by_key(conn, identifier)
            if exact:
                return [exact]

            # Try fuzzy name
            return repo.find_project_by_name_fuzzy(conn, identifier)

        finally:
            conn.close()

    # --------------------------------------------
    # Process + Schedule
    # --------------------------------------------

    @timed_cache(ttl_seconds=300)
    def list_processes(self, project_key: str) -> List[Dict]:
        conn = get_connection()
        try:
            processes = repo.get_processes(conn, project_key)
            logger.debug("list_processes project=%s cache miss — %d processes", project_key, len(processes))
            return processes
        finally:
            conn.close()

    @timed_cache(ttl_seconds=600)
    def get_schedule(self, project_key: str, process_name: str, timezone: str = "America/New_York") -> Dict:
        """
        Schedule queries require project + process.
        No aggregation allowed.
        """
        conn = get_connection()
        try:
            schedule = repo.get_schedule(conn, project_key, process_name)
            oem = repo.get_oem_by_project(conn, project_key)
        finally:
            conn.close()

        if not schedule:
            return {
                "status": "not_found",
                "message": "Schedule not found for given project and process."
            }

        return build_schedule_response(
            project_key=project_key,
            process_name=process_name,
            cron_expression=schedule,
            timezone=timezone,
            oem=oem
        )

    # --------------------------------------------
    # Config Key Lookup
    # --------------------------------------------

    def get_config_value(
        self,
        project_key: str,
        process_name: str,
        config_key: str
    ) -> Dict:

        conn = get_connection()
        try:
            value = repo.get_config_value(
                conn,
                project_key,
                process_name,
                config_key
            )
        finally:
            conn.close()

        if not value:
            return {
                "status": "not_found",
                "message": "Config key not found."
            }

        return {
            "status": "success",
            "project_key": project_key,
            "process_name": process_name,
            "config_key": config_key,
            "value": value
        }

    # --------------------------------------------
    # Mapping Queries (Aggregation Allowed)
    # --------------------------------------------

    def get_field_mappings(
        self,
        field_name: str,
        oem_name: Optional[str] = None,
        project_key: Optional[str] = None,
        process_name: Optional[str] = None
    ) -> Dict:

        conn = get_connection()
        try:
            rows = repo.get_field_mappings(
                conn,
                field_name,
                oem_name=oem_name,
                project_key=project_key
            )
        finally:
            conn.close()

        if not rows:
            return {
                "status": "not_found",
                "message": f"No mappings found for field '{field_name}'."
            }

        # Group by project
        grouped = {}

        for r in rows:
            pk = r["project_key"]
            pn = r["process_name"]
            sn = r["scenario_name"]

            # Navigate/Create the hierarchy: Project -> Process -> Scenario
            project_layer = grouped.setdefault(pk, {})
            process_layer = project_layer.setdefault(pn, {})
            scenario_layer = process_layer.setdefault(sn, [])
            
            # Append the field mapping to the scenario list
            scenario_layer.append({
                "source_field": r["source_field"],
                "destination_field": r["destination_field"]
            })
           

        return {
            "status": "success",
            "project_key": project_key,
            "process_name": None,  # since we allow aggregation across processes
            "field": field_name,
            "results": grouped
        }

    # --------------------------------------------
    # Multi-hop Traversal
    # --------------------------------------------

    def get_multi_hop_mappings(
        self,
        field_name: str,
        oem_name: Optional[str] = None,
        project_key: Optional[str] = None
    ) -> Dict:

        conn = get_connection()
        try:
            rows = repo.get_multi_hop_mappings(
                conn,
                field_name,
                oem_name=oem_name,
                project_key=project_key
            )
        finally:
            conn.close()

        if not rows:
            return {
                "status": "not_found",
                "message": f"No multi-hop mappings found for '{field_name}'."
            }

        grouped = {}

        for r in rows:
            pk = r["project_key"]
            grouped.setdefault(pk, []).append({
                "process_name": r["process_name"],
                "source_field": r["source_field"],
                "destination_field": r["destination_field"]
            })

        return {
            "status": "success",
            "field": field_name,
            "results": grouped
        }
    
    @timed_cache(ttl_seconds=300)
    def get_config_keys(self, project_key: str, process_name: str):

        conn = get_connection()
        try:
            return repo.get_config_keys(conn, project_key, process_name)
        finally:
            conn.close()


    @timed_cache(ttl_seconds=300)
    def get_all_mapping_fields(self, oem_name: str, project_key: str):

        conn = get_connection()
        try:
            return repo.get_all_mapping_fields(conn, oem_name, project_key)
        finally:
            conn.close()


    def get_oem_by_project(self, project_key: str):

        conn = get_connection()
        try:
            return repo.get_oem_by_project(conn, project_key)
        finally:
            conn.close()

    
    def list_all_projects(self):
        conn = get_connection()
        try:
            return repo.get_all_projects(conn)
        finally:
            conn.close()

    def get_all_mappings(self, project_key: str, process_name: str = None):

        conn = get_connection()
        try:
            rows = repo.get_all_attribute_mappings(conn, project_key, process_name)
        finally:
            conn.close()

        if not rows:
            return {
                "status": "not_found",
                "message": "No mappings found."
            }

        # Group by source_field
        grouped = {}

        for r in rows:
            src = r["source_field"]
            grouped.setdefault(src, []).append({
                "destination_field": r["destination_field"],
                "process_name": r.get("process_name")
            })

        return {
            "status": "success",
            "project_key": project_key,
            "process_name": process_name,
            "details": {
                "fields": grouped
            }
        }


    def get_value_mappings(
        self,
        project_key: str,
        field_name: str,
        process_name: str = None,
        limit: int = 100,
        offset: int = 0
    ):

        conn = get_connection()
        try:
            total = repo.count_value_mappings_for_field(
                conn, project_key, field_name, process_name
            )

            values = repo.get_value_mappings_for_field(
                conn, project_key, field_name, process_name, limit, offset
            )

            # Assuming 'values' contains the raw rows from your DB query
            raw_rows = values  

            grouped_scenarios = {}

            for r in raw_rows:
                sn = r["scenario_name"]
                sf = r["source_field"]
                df = r["destination_field"]
                sv = r["source_value"]
                dv = r["destination_value"]
                
                # Initialize scenario if not present
                if sn not in grouped_scenarios:
                    grouped_scenarios[sn] = {
                        "source_fields": {},
                        "destination_fields": {}
                    }
                
                # Group source values under source field
                if sf not in grouped_scenarios[sn]["source_fields"]:
                    grouped_scenarios[sn]["source_fields"][sf] = []
                grouped_scenarios[sn]["source_fields"][sf].append(sv)
                
                # Group destination values under destination field
                if df not in grouped_scenarios[sn]["destination_fields"]:
                    grouped_scenarios[sn]["destination_fields"][df] = []
                grouped_scenarios[sn]["destination_fields"][df].append(dv)

            # Return not_found when there's no data
            if total == 0:
                return {
                    "status": "not_found",
                    "message": f"No value mappings found for field '{field_name}'.",
                    "total": 0,
                    "values": {}
                }

            # Update your return statement
            return {
                "status": "success",
                "total": total,
                "limit": limit,
                "offset": offset,
                "values": grouped_scenarios
            }
        finally:
            conn.close()

    
    # Synonym expansion map: user-facing terms → config key terms
    _SYNONYM_MAP = {
        "creation": ["create", "creation", "new"],
        "create": ["create", "creation", "new"],
        "comment": ["comment", "comments", "note", "remark"],
        "comments": ["comment", "comments", "note", "remark"],
        "attachment": ["attachment", "attachments", "file", "files"],
        "attachments": ["attachment", "attachments", "file", "files"],
        "status": ["status", "state", "statusexchange"],
        "exchange": ["exchange", "sync", "transfer", "statusexchange"],
        "transfer": ["transfer", "exchange", "sync"],
        "transferring": ["transfer", "exchange", "sync"],
        "enabled": ["enable", "enabled", "on", "active", "true"],
        "disabled": ["disable", "disabled", "off", "inactive", "false"],
        "sync": ["sync", "synchronize", "exchange", "transfer"],
    }

    def get_config_value_by_query(self, project_key: str, process_name: str, query: str):

        config_keys = self.get_config_keys(project_key, process_name)

        if not config_keys:
            return {
                "status": "not_found",
                "message": "No configuration found for given project and process."
            }

        query_lower = query.lower()

        # Expand query with synonyms for better matching
        query_words = query_lower.split()
        expanded_words = set(query_words)
        for word in query_words:
            if word in self._SYNONYM_MAP:
                expanded_words.update(self._SYNONYM_MAP[word])

        # Deterministic scoring with synonym expansion
        scored = []

        for key in config_keys:
            score = 0
            key_lower = key.lower()

            # Exact phrase match (original query)
            if key_lower in query_lower:
                score += 5

            # Token overlap scoring using expanded words
            for word in expanded_words:
                if word in key_lower:
                    score += 1

            # Bonus: check if original query words appear as substrings in key
            for word in query_words:
                if len(word) > 3 and word in key_lower:
                    score += 2

            if score > 0:
                scored.append((key, score))

        if not scored:
            return {
                "status": "unknown_config",
                "message": "No matching config key found."
            }

        # Pick highest scoring key
        scored.sort(key=lambda x: x[1], reverse=True)
        best_key = scored[0][0]

        return self.get_config_value(
            project_key,
            process_name,
            best_key
        )
    
    def get_mapping_by_query(self, oem_name: str, project_key: str, process_name: str, query: str):
        query_lower = query.lower()

        # Determine if user explicitly asked for value mapping
        is_value_query = "value" in query_lower or "values" in query_lower

        # Find all distinct field names for this project/oem
        fields = self.get_all_mapping_fields(oem_name=oem_name, project_key=project_key)

        # Get query tokens, excluding common noise/command words
        noise_words = {
            "value", "values", "field", "fields", "mapping", "mappings", "map", "maps",
            "show", "get", "give", "me", "please", "all", "schema", "details", "detail",
            "what", "is", "are", "can", "you", "for", "of", "and", "or", "with", "to", "it"
        }
        query_tokens = tokenize(query_lower) - noise_words

        # Find all matching fields
        matched_fields = []
        for field in fields:
            field_tokens = set(field.lower().split())
            # Check overlap with remaining query tokens
            if field_tokens & query_tokens:
                matched_fields.append(field)

        # Case 1: Specific field(s) requested
        if matched_fields:
            if is_value_query:
                # Return value mappings for matched fields only
                combined_values = {}
                total_count = 0
                for field in matched_fields:
                    res = self.get_value_mappings(
                        project_key=project_key,
                        field_name=field,
                        process_name=process_name
                    )
                    if res.get("status") == "success" and res.get("values"):
                        for scenario, data in res["values"].items():
                            scen_data = combined_values.setdefault(scenario, {
                                "source_fields": {},
                                "destination_fields": {}
                            })
                            scen_data["source_fields"].update(data["source_fields"])
                            scen_data["destination_fields"].update(data["destination_fields"])
                        total_count += res.get("total", 0)
                
                if combined_values:
                    return {
                        "status": "success",
                        "project_key": project_key,
                        "process_name": process_name,
                        "values": combined_values,
                        "total": total_count
                    }
                else:
                    return {
                        "status": "not_found",
                        "message": f"No value mappings found for: {', '.join(matched_fields)}."
                    }
            else:
                # Return field mappings for matched fields only
                combined_results = {}
                for field in matched_fields:
                    res = self.get_field_mappings(
                        field_name=field,
                        oem_name=oem_name,
                        project_key=project_key,
                        process_name=process_name
                    )
                    if res.get("status") == "success" and res.get("results"):
                        for pk, process_data in res["results"].items():
                            pk_data = combined_results.setdefault(pk, {})
                            for proc, scenario_data in process_data.items():
                                proc_data = pk_data.setdefault(proc, {})
                                for scen, mappings in scenario_data.items():
                                    scen_mappings = proc_data.setdefault(scen, [])
                                    # Avoid duplicates
                                    for m in mappings:
                                        if m not in scen_mappings:
                                            scen_mappings.append(m)
                
                if combined_results:
                    return {
                        "status": "success",
                        "project_key": project_key,
                        "process_name": process_name,
                        "results": combined_results,
                        "field": ", ".join(matched_fields)
                    }
                else:
                    return {
                        "status": "not_found",
                        "message": f"No mappings found for: {', '.join(matched_fields)}."
                    }

        # Case 2: General / All mappings query
        if is_value_query:
            # Retrieve all mappings, filter and return only those with value mappings
            summary = self.get_mapping_summary(project_key, process_name)
            if summary.get("status") == "success" and summary.get("mappings"):
                all_value_mappings = {}
                for scenario, items in summary["mappings"].items():
                    for m in items:
                        val_maps = m.get("value_mappings", [])
                        if val_maps:
                            src = m["source_field"]
                            dst = m["destination_field"]
                            
                            scenario_data = all_value_mappings.setdefault(scenario, {
                                "source_fields": {},
                                "destination_fields": {}
                            })
                            
                            src_vals = [vm["src_val"] for vm in val_maps]
                            dst_vals = [vm["dst_val"] for vm in val_maps]
                            
                            scenario_data["source_fields"][src] = src_vals
                            scenario_data["destination_fields"][dst] = dst_vals
                
                if all_value_mappings:
                    return {
                        "status": "success",
                        "project_key": project_key,
                        "process_name": process_name,
                        "values": all_value_mappings
                    }
            
            return {
                "status": "not_found",
                "message": "No value mappings configured for this process."
            }

        # Otherwise, return general mapping summary
        return self.get_mapping_summary(project_key, process_name)

    

    def get_filter_query(self, project_key: str, process_name: str):

        config = self.get_full_config(project_key, process_name)

        if not config:
            return {
                "status": "not_found",
                "message": "Config not found."
            }

        # Search for filter-related key
        for key, value in config.items():
            if "filter" in key.lower() or "query" in key.lower():
                return {
                    "status": "success",
                    "project_key": project_key,
                    "process_name": process_name,
                    "config_key": key,
                    "value": value
                }

        return {
            "status": "not_found",
            "message": "No filter or query configured."
        }



    def get_full_config(self, project_key: str, process_name: str):

        conn = get_connection()
        try:
            return repo.get_full_config(conn, project_key, process_name)
        finally:
            conn.close()

    
    def get_mapping_summary(self, project_key: str, process_name: str):

        conn = get_connection()
        try:
            rows = repo.get_all_attribute_mappings(
                conn, project_key, process_name
            )
        finally:
            conn.close()

        if not rows:
            return {
                "status": "not_found",
                "message": "No mappings found."
            }

        grouped = {}

        for r in rows:
            grouped.setdefault(r["scenario_name"], []).append({
                "source_field": r["source_field"],
                "destination_field": r["destination_field"],
                "value_mappings": r.get("value_mappings", [])
            })

        return {
            "status": "success",
            "project_key": project_key,
            "process_name": process_name,
            "mappings": grouped
        }

    


