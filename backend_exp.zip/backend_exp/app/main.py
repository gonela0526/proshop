import time
import os
import threading
from fastapi.staticfiles import StaticFiles
from collections import defaultdict, deque
from uuid import uuid4
from typing import Optional, Union

from fastapi import FastAPI, Body, WebSocket, WebSocketDisconnect, Request, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, RedirectResponse

# New API Router for LangGraph
from app.api.router import router as chat_router

# Legacy Core Components
from app.db.connection import get_pg_connection
from app.db.oracle_connection import get_oracle_connection
from app.session.session_service import SessionService
from app.exchange_trigger.trigger_service import TriggerService
from app.exchange_trigger.tirgger_models import ProcessRequest
from app.exchange_trigger.process_service import ProcessService
from app.exchange_trigger.connection_manager import ConnectionManager
from app.access.service import AccessService
from app.utils.logger import setup_logger
from app.utils.cache import cache_stats
from app.jiraOAuth.router import router as jira_oauth_router
from app.userSession.service import UserSessionService
from chainlit.utils import mount_chainlit
from app.access.router import router as access_router
from app.userSession.router import router as user_session_router
from app.profile.router import router as profile_router


frontend_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "../frontend/chainlit_app.py")

logger = setup_logger()

# ---------------------------------------------------------------------------
# Application services
# ---------------------------------------------------------------------------
manager = ConnectionManager()
process_service = ProcessService(manager)
session_service = SessionService()
trigger_service = TriggerService()
user_session_service = UserSessionService()
access_service = AccessService()

# ---------------------------------------------------------------------------
# FastAPI app
# ---------------------------------------------------------------------------
app = FastAPI(title="AIDA Backend (Agentic)", version="2.0.0")

app.mount(
    "/chat/public",
    StaticFiles(directory=os.path.join(os.path.dirname(os.path.abspath(__file__)), "../frontend/public"), html=True),
    name="public",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.middleware("http")
async def authenticate_chat_requests(
    request: Request,
    call_next,
):
    path = request.url.path.rstrip("/")

    # Protect ONLY the initial Chainlit page
    if request.method == "GET" and path == "/chat":

        redirect_url = await user_session_service.bootstrap(
            request
        )

        # bootstrap() returns:
        #   "/chat"      -> authenticated
        #   OAuth URL    -> not authenticated

        if redirect_url != "/chat":
            return RedirectResponse(
                url=redirect_url,
                status_code=302,
            )

    return await call_next(request)

# ---------------------------------------------------------------------------
# Mount the Jira OAuth routers
# ---------------------------------------------------------------------------
app.include_router(jira_oauth_router)
app.include_router(user_session_router)
app.include_router(access_router)
app.include_router(profile_router)

mount_chainlit(
    app=app,
    target=str(frontend_path),
    path="/chat"
)

@app.get("/")
async def home(request: Request):

    redirect_url = await user_session_service.bootstrap(request)

    return RedirectResponse(url=redirect_url)

# ---------------------------------------------------------------------------
# Mount the new LangGraph Chat Router
# ---------------------------------------------------------------------------
app.include_router(chat_router, prefix="/agent", tags=["Chat"])

# ---------------------------------------------------------------------------
# Metrics collection (in-memory, lightweight)
# ---------------------------------------------------------------------------

_metrics_lock = threading.Lock()
_metrics = {
    "requests_total": 0,
    "requests_by_path": defaultdict(int),
    "errors_total": 0,
    "latency_samples": deque(maxlen=100),   # last 100 request durations in ms
}


def _record_request(path: str, duration_ms: float, is_error: bool = False):
    with _metrics_lock:
        _metrics["requests_total"] += 1
        _metrics["requests_by_path"][path] += 1
        if is_error:
            _metrics["errors_total"] += 1
        _metrics["latency_samples"].append(duration_ms)


# ---------------------------------------------------------------------------
# Rate limiter (per-IP sliding window, in-memory)
# ---------------------------------------------------------------------------

_RATE_LIMIT = int(os.getenv("AIDA_RATE_LIMIT_RPM", "60"))   # requests per minute per IP
_rate_lock = threading.Lock()
_ip_windows: dict = defaultdict(lambda: deque())             # ip -> deque of timestamps


def _is_rate_limited(client_ip: str) -> bool:
    if _RATE_LIMIT <= 0:
        return False
    now = time.monotonic()
    cutoff = now - 60.0
    with _rate_lock:
        window = _ip_windows[client_ip]
        # Remove stale entries
        while window and window[0] < cutoff:
            window.popleft()
        if len(window) >= _RATE_LIMIT:
            return True
        window.append(now)
    return False


# ---------------------------------------------------------------------------
# Middleware: request logging + metrics + rate limiting
# ---------------------------------------------------------------------------

@app.middleware("http")
async def request_middleware(request: Request, call_next):
    # Rate limiting
    client_ip = request.client.host if request.client else "unknown"
    if _is_rate_limited(client_ip):
        logger.warning("rate_limit_exceeded ip=%s path=%s", client_ip, request.url.path)
        return JSONResponse(
            status_code=429,
            content={
                "status": "error",
                "message": "Too many requests. Please slow down and try again shortly.",
            },
        )

    started_at = time.perf_counter()
    is_error = False
    try:
        response = await call_next(request)
        if response.status_code >= 500:
            is_error = True
    except Exception:
        is_error = True
        logger.exception("Unhandled request error for %s %s", request.method, request.url.path)
        raise

    elapsed_ms = round((time.perf_counter() - started_at) * 1000, 2)
    _record_request(request.url.path, elapsed_ms, is_error)

    return response


# ---------------------------------------------------------------------------
# Global error handler
# ---------------------------------------------------------------------------

@app.exception_handler(Exception)
async def handle_unexpected_error(request: Request, exc: Exception):
    logger.exception("Unhandled exception for %s %s", request.method, request.url.path)
    return JSONResponse(
        status_code=500,
        content={
            "status": "error",
            "message": "An unexpected error occurred while processing your request.",
        },
    )


# ---------------------------------------------------------------------------
# Legacy Routes Preserved
# ---------------------------------------------------------------------------

@app.get("/health")
def health_check():
    checks: dict = {}
    try:
        with get_pg_connection() as pg_conn:
            cur = pg_conn.cursor()
            cur.execute("SELECT 1")
            cur.close()
        checks["postgres"] = "ok"
    except Exception as exc:
        checks["postgres"] = f"error: {exc}"

    try:
        oc = get_oracle_connection()
        cur = oc.cursor()
        cur.execute("SELECT 1 FROM dual")
        cur.close()
        oc.close()
        checks["oracle"] = "ok"
    except Exception as exc:
        checks["oracle"] = f"error: {exc}"

    overall = "healthy" if all(v == "ok" for k, v in checks.items()) else "degraded"
    return {"status": overall, "checks": checks}


@app.get("/create-session")
def create_session(session_id: Optional[str] = None):
    if session_id:
        from app.db.connection import get_pg_connection
        from datetime import datetime
        try:
            with get_pg_connection() as conn:
                cur = conn.cursor()
                cur.execute("SELECT 1 FROM sessions WHERE id = %s;", (session_id,))
                if not cur.fetchone():
                    cur.execute("INSERT INTO sessions (id, updated_at) VALUES (%s, %s);", (session_id, datetime.utcnow()))
                    conn.commit()
                cur.close()
        except Exception as exc:
            logger.error("Failed to pre-insert session %s: %s", session_id, exc)
        return {"session_id": session_id}
    return {"session_id": session_service.create_session()}


@app.get("/trigger-options")
async def get_trigger_options(request: Request):

    session_id = request.cookies.get("AIDA_SESSION")

    if not session_id:
        raise HTTPException(
            status_code=401,
            detail="Authentication required."
        )

    # processes_list = trigger_service.get_process_list()
    # return {
    #     "oems": processes_list.get("oems", []),
    #     "projects": processes_list.get("projects", []),
    #     "processes": processes_list.get("processes", []),
    # }

    try:

        authorized_projects = await access_service.get_authorized_projects(
            session_id
        )

        project_ids = [
            project.db_project_id
            for project in authorized_projects
            if project.db_project_id is not None
        ]

        process_list = trigger_service.get_process_list(
            project_ids
        )

        return {
            "oems": process_list["oems"],
            "projects": process_list["projects"],
            "processes": process_list["processes"]
        }

    except ValueError as ex:

        raise HTTPException(
            status_code=401,
            detail=str(ex)
        )


@app.post("/trigger")
def trigger_exchange(
    oemId: str = Body(...),
    projectId: str = Body(...),
    process: dict = Body(...),
    defectIds: Optional[Union[str, list]] = Body(None),
):
    return trigger_service.trigger(oemId, projectId, process, defectIds)


@app.post("/process/start")
async def start_process(request: ProcessRequest):
    job_id = str(uuid4())
    validate_response = process_service.validate_process(
        request.oemId,
        request.projectId,
        request.process,
        request.defectIds
    )
    if validate_response.get("status_code") != 200:
        return validate_response

    await process_service.start_process(
        job_id,
        request.oemId,
        request.projectId,
        request.process,
        request.defectIds
    )
    return {"job_id": job_id}


@app.post("/feedback")
def store_feedback(
    session_id: str = Body(...),
    feedback: str = Body(...),
    comment: Optional[str] = Body(None),
):
    from app.monitoring import update_conversation_feedback
    update_conversation_feedback(session_id, feedback, comment)
    return {"status": "success"}


@app.on_event("startup")
def startup_db_init():
    try:
        from app.monitoring.schema import init_db
        init_db()
    except Exception as exc:
        logger.error("Failed to run monitoring DB initialization: %s", exc)


@app.websocket("/ws/{job_id}")
async def websocket_endpoint(websocket: WebSocket, job_id: str):
    await manager.connect(job_id, websocket)
    from app.exchange_trigger.process_store import jobs
    if job_id in jobs:
        try:
            await websocket.send_json(jobs[job_id])
        except Exception:
            pass
    try:
        while True:
            await websocket.receive_text()
    except WebSocketDisconnect:
        manager.disconnect(job_id, websocket)




