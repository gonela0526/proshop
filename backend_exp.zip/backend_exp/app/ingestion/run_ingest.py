"""Ingestion script: loads JSON program files into the Postgres database.

This is a one-shot admin script, not part of the web application runtime.
Run from the backend root with:

    python -m app.ingestion.run_ingest

The back-compat alias `get_db_connection` still works but we use
`get_pg_pool_conn` explicitly so the intent is clear.
"""

from app.ingestion.ingest_config import ingest_program
from app.db.connection import get_pg_pool_conn
from pathlib import Path
import logging

logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(message)s")
log = logging.getLogger("ingest")

# Initialize connection — disable autocommit for one atomic transaction.
conn = get_pg_pool_conn()
conn.autocommit = False
json_dir = Path("/opt/AIDA/scripts/JSON")

try:
    with conn.cursor() as cur:
        for json_file in json_dir.glob("*.json"):
            log.info("Processing: %s", json_file.name)
            ingest_program(str(json_file), cur)

    conn.commit()
    log.info("✅ Success! All data updated with zero downtime.")

except Exception as e:
    conn.rollback()
    log.error("❌ Error encountered: %s", e)
    log.error("Transaction rolled back. No changes were made to the database.")

finally:
    conn.close()
