import requests
from typing import List, Dict, Any, Optional, Tuple

class ConfigManager:
    """Manages retrieving and updating configuration settings via a persistent authenticated REST API session."""
    
    def __init__(self, base_url: str, component_name: str, config_set_name: str, username: str, password: str):
        self.base_url = base_url.rstrip('/')
        self.component_name = component_name
        self.config_set_name = config_set_name
        self.username = username
        self.password = password
        
        self.config_set_id: Optional[int] = None
        self.raw_config_values: List[Dict[str, Any]] = []
        
        # Initialize and configure the persistent session
        self.session = requests.Session()
        self.session.auth = (self.username, self.password)
        self.session.headers.update({
            "accept": "application/json;charset=utf-8",
            "Content-Type": "application/json;charset=utf-8",
            "X-CSRF": "null"
        })

    def fetch_config_values(self) -> List[Dict[str, Any]]:
        """Fetches the configuration values from the server using the active session."""
        url = f"{self.base_url}/getConfigValuesByNames"
        payload = {
            "componentName": self.component_name,
            "configSetName": self.config_set_name
        }
        
        try:
            response = self.session.post(url, json=payload, verify=False)
            response.raise_for_status()
            
            data = response.json()
            
            self.raw_config_values = data.get("configValues", [])
            
            if self.raw_config_values:
                self.config_set_id = self.raw_config_values[0].get("configSet", {}).get("id")
                
            return self.raw_config_values
        except requests.exceptions.RequestException as e:
            print(f"Error fetching configurations: {e}")
            return []

    def update_and_save_param(self, param_name: str, new_value: Any) -> Tuple[bool, Optional[str]]:
        """
        Captures the old value, maps the configuration block to the payload structure, 
        and updates it to the new custom value.
        
        Returns:
            Tuple[bool, Optional[str]]: (success_status, old_parameter_value)
        """
        if not self.raw_config_values:
            self.fetch_config_values()
            
        target_config = None
        for config in self.raw_config_values:
            if config.get("paramName") == param_name:
                target_config = config.copy()  # Prevent state corruption before a successful API call
                break
                
        if not target_config:
            print(f"Parameter '{param_name}' not found in the configuration set.")
            return False, None
            
        if self.config_set_id is None:
            print("Config Set ID could not be resolved.")
            return False, None

        # --- Capture the value BEFORE updating ---
        old_value = target_config.get("paramValue")
        print(f"Found parameter '{param_name}'. Old value was: '{old_value}'")

        # Apply your custom new value change
        target_config["paramValue"] = str(new_value)
        
        url = f"{self.base_url}/setConfigValues"
        update_payload = {
            "configSetId": self.config_set_id,
            "configValues": [target_config]
        }
        
        try:
            print(f"Updating '{param_name}' to custom value: '{new_value}'...")
            response = self.session.post(url, json=update_payload, verify=False)
            response.raise_for_status()
            print("Configuration updated successfully.")
            
            # Refresh local cached properties upon success
            self.fetch_config_values()
            return True, old_value
        except requests.exceptions.RequestException as e:
            print(f"Failed to update configuration: {e}")
            return False, old_value
            
    def close(self):
        """Closes the underlying requests session cleanly."""
        self.session.close()
