from enum import Enum
from pydantic import BaseModel
from typing import Optional,Union


class ProcessStatus(str, Enum):
    STARTED = "STARTED"
    RUNNING = "RUNNING"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"


class ProcessRequest(BaseModel):
    oemId: str
    projectId: str
    process: dict
    defectIds: Optional[Union[str,list]]


class ProcessUpdate(BaseModel):
    job_id: str
    status: ProcessStatus
    progress: int
    message: str = ""
