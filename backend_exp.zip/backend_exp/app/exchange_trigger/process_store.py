import sqlite3
import json
import os
from typing import Dict, Any, List, Tuple

class PersistentJobsStore:
    """A thread-safe dictionary-like store backed by a local SQLite database.
    
    This ensures that background job states survive application restarts.
    """

    def __init__(self):
        base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        self.db_path = os.path.join(base_dir, "jobs.db")
        self._init_db()

    def _init_db(self):
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS jobs (
                    job_id TEXT PRIMARY KEY,
                    data TEXT NOT NULL
                )
            """)
            conn.commit()

    def __getitem__(self, key: str) -> Dict[str, Any]:
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT data FROM jobs WHERE job_id = ?", (key,))
            row = cursor.fetchone()
            if row is None:
                raise KeyError(key)
            return json.loads(row[0])

    def __setitem__(self, key: str, value: Dict[str, Any]):
        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                "INSERT OR REPLACE INTO jobs (job_id, data) VALUES (?, ?)",
                (key, json.dumps(value))
            )
            conn.commit()

    def __contains__(self, key: str) -> bool:
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT 1 FROM jobs WHERE job_id = ?", (key,))
            return cursor.fetchone() is not None

    def get(self, key: str, default: Any = None) -> Any:
        try:
            return self[key]
        except KeyError:
            return default

    def keys(self) -> List[str]:
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT job_id FROM jobs")
            return [row[0] for row in cursor.fetchall()]

    def items(self) -> List[Tuple[str, Dict[str, Any]]]:
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT job_id, data FROM jobs")
            return [(row[0], json.loads(row[1])) for row in cursor.fetchall()]


jobs = PersistentJobsStore()
