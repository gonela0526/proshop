import asyncio
import re
from app.exchange_trigger.process_store import jobs
from app.exchange_trigger.agosense_job_service import trigger_process, monitor_job_progress , validate_job_process
from app.config.settings import PROD1_CONFIG, PROD2_CONFIG, QA2_CONFIG
from app.exchange_trigger.config_manager import ConfigManager


class ProcessService:

    def __init__(self, manager):
        self.manager = manager
        self.username = "your_username"
        self.password = "your_password"
        self.config_url = "https://your-internal-endpoint:8443/api/config"
        self.trigger_url = "https://your-internal-endpoint:8443/api/trigger"
        self.monitor_url = "https://your-internal-endpoint:8443/api/monitor"
        self.config_set = "your_default_config_set"

    async def start_process(
            self,
            job_id,
            oemId,
            projectId,
            process,
            defectIds):

        
        if process is None:
            raise ValueError("Process cannot be None")
        

        if process.get("instance") == "PROD1":
            print("Starting process for PROD1 environment")
            self.config_set = process.get("configset_name")  
            self.trigger_url = PROD1_CONFIG["trigger_url"]
            self.monitor_url = PROD1_CONFIG["monitor_url"]
            self.config_url = PROD1_CONFIG["config_url"]
            self.username = PROD1_CONFIG["username"]
            self.password = PROD1_CONFIG["password"]

        elif process.get("instance") == "PROD2":
            print("Starting process for PROD2 environment")
            self.config_set = process.get("configset_name")  
            self.trigger_url = PROD2_CONFIG["trigger_url"]
            self.monitor_url = PROD2_CONFIG["monitor_url"]
            self.config_url = PROD2_CONFIG["config_url"]
            self.username = PROD2_CONFIG["username"]
            self.password = PROD2_CONFIG["password"]

        elif process.get("instance") == "QA2":
            print("Starting process for QA2 environment")
            self.config_set = process.get("configset_name")  
            self.trigger_url = QA2_CONFIG["trigger_url"]
            self.monitor_url = QA2_CONFIG["monitor_url"]
            self.config_url = QA2_CONFIG["config_url"]
            self.username = QA2_CONFIG["username"]
            self.password = QA2_CONFIG["password"]
    
        
        #updating the configset with user mentioned defectids
        config_manager = ConfigManager(
            base_url=self.config_url,
            component_name=process.get('java_process_name'),
            config_set_name=self.config_set,
            username=self.username,
            password=self.password
        )

        try:
            target_param = "mahindraFilterquery"
            jql_query = self.generate_jql(defectIds)
            
            # Execute the update pipeline and destructure the returned status and original value
            success, captured_old_value = config_manager.update_and_save_param(target_param, jql_query)

            if success:
                print(f"\n--- Summary ---")
                print(f"Parameter: {target_param}")
                print(f"Previous Value: {captured_old_value}")
                print(f"Updated Value: {jql_query}")
        

                #triggering the process using the trigger_process function
                trigger_response = trigger_process(
                    job_id,
                    process.get('java_process_name'),
                    self.config_set,
                    self.username,
                    self.password,
                    self.trigger_url
                )

                if trigger_response != 200:
                    raise ValueError("Failed to trigger process")

                jobs[job_id] = {
                    "status": "STARTED",
                    "progress": 0,
                    "job_id": job_id,
                    "configset": self.config_set,
                    "process": process
                }

                await asyncio.sleep(10) 

                asyncio.create_task(
                    self.monitor_process(
                        job_id,
                        self.config_set,
                        process
                    )
                )

                success_2, restored_value = config_manager.update_and_save_param(target_param, captured_old_value)
        finally:
            config_manager.close()

    async def monitor_process(
            self,
            job_id,
            configset,
            process):

        # execution = await start_external_process(
        #     configset,
        #     process
        # )

        # execution_id = execution[
        #     "execution_id"
        # ]

        progress = 0

        while True:

            # status_response = (
            #     await get_process_status(
            #         execution_id,
            #         progress
            #     )
            # )

            status_response = await monitor_job_progress(
                job_id,
                self.monitor_url,
                self.username,
                self.password
            )

            progress = (
                status_response["progress"]
            )

            print(f"Status Reponse Object: {status_response}")

            jobs[job_id] = {
                "job_id": job_id,
                "status":
                    status_response["status"],
                "progress": progress,
                "total": status_response["total"],
                "succeeded": status_response["succeeded"],
                "failed": status_response["failed"],
                "configset": configset,
                "process": process
            }

            await self.manager.broadcast(
                job_id,
                jobs[job_id]
            )

            if (
                status_response["status"]
                == "COMPLETED"
            ):
                break

            await asyncio.sleep(5)

    
    def validate_process(
        self,
            oemId,
            projectId,
            process,
            defectIds
        ):

        jql_query = self.generate_jql(defectIds)
        no_of_defects = self.count_jira_defects(jql_query)
        
        if no_of_defects > 30:
            return {
                "status_code": 403,
                "msg": f"Too many defects provided: {no_of_defects}. Please provide 30 or fewer."
            }

        if process is None:
            raise ValueError("Process cannot be None")
        

        if process.get("instance") == "PROD1":
            print("Starting process for PROD1 environment")
            self.config_set = process.get("configset_name")  
            self.trigger_url = PROD1_CONFIG["trigger_url"]
            self.monitor_url = PROD1_CONFIG["monitor_url"]
            self.username = PROD1_CONFIG["username"]
            self.password = PROD1_CONFIG["password"]
        elif process.get("instance") == "PROD2":
            print("Starting process for PROD2 environment")
            self.config_set = process.get("configset_name")  
            self.trigger_url = PROD2_CONFIG["trigger_url"]
            self.monitor_url = PROD2_CONFIG["monitor_url"]
            self.username = PROD2_CONFIG["username"]
            self.password = PROD2_CONFIG["password"]
        elif process.get("instance") == "QA2":
            print("Starting process for QA2 environment")
            self.config_set = process.get("configset_name")  
            self.trigger_url = QA2_CONFIG["trigger_url"]
            self.monitor_url = QA2_CONFIG["monitor_url"]
            self.username = QA2_CONFIG["username"]
            self.password = QA2_CONFIG["password"]

        validate_response = validate_job_process(process.get('java_process_name'),
        self.config_set,
        self.username,
        self.password,
        self.monitor_url)

        return validate_response


    
    def generate_jql(self,text_input):
        # Regex to find Jira keys (e.g., PROJ-123) anywhere in the text
        jira_id_pattern = r'[A-Z]+-\d+'
        
        text_input = text_input if isinstance(text_input, str) else str(text_input)
        # Extract all matches into a list
        jira_ids = re.findall(jira_id_pattern, text_input)
        
        # If no IDs are found, return an empty JQL structure
        if not jira_ids:
            return "key in ()"
        
        # Format each ID with single quotes and join them with commas
        formatted_ids = ", ".join(f"'{jira_id}'" for jira_id in jira_ids)
        
        return f"key in ({formatted_ids})"

    
    def count_jira_defects(self, jql_query: str) -> int:
        # Pattern matches standard Jira keys: 1+ uppercase letters, a hyphen, and digits
        jira_key_pattern = r"\b[A-Z]+-\d+\b"

        # Find all matching keys in the string
        found_keys = re.findall(jira_key_pattern, jql_query)

        # Use set() if you only want unique keys, or keep as a list to count all instances
        unique_keys = set(found_keys)

        print(f"Extracted Keys ({len(unique_keys)}): {sorted(list(unique_keys))}")
        return len(unique_keys)
