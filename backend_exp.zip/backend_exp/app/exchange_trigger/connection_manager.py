from collections import defaultdict
from fastapi import WebSocket


class ConnectionManager:

    def __init__(self):
        self.connections = defaultdict(list)

    async def connect(
            self,
            job_id: str,
            websocket: WebSocket):

        await websocket.accept()

        self.connections[job_id].append(
            websocket
        )

    def disconnect(
            self,
            job_id: str,
            websocket: WebSocket):

        if job_id in self.connections:

            if websocket in self.connections[job_id]:

                self.connections[job_id].remove(
                    websocket
                )

            if not self.connections[job_id]:

                del self.connections[job_id]

    async def broadcast(
            self,
            job_id: str,
            data: dict):

        if job_id not in self.connections:
            return

        dead_connections = []

        for ws in self.connections[job_id]:

            try:
                await ws.send_json(data)

            except Exception:
                dead_connections.append(ws)

        for ws in dead_connections:
            self.disconnect(job_id, ws)
