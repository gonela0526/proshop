from app.db.connection import get_pg_connection
from app.exchange_trigger import repo
from typing import Optional, Union
from app.config.settings import PROD1_CONFIG, PROD2_CONFIG
from app.utils.logger import setup_logger
import requests
import time
import uuid

logger = setup_logger()


class TriggerService:
    def __init__(self):
        # Credentials and URLs are resolved per-call from environment config.
        # No hardcoded placeholders — a missing or unrecognised instance will
        # raise a ValueError early in trigger().
        self._username: str = ""
        self._password: str = ""
        self._trigger_url: str = ""
        self._monitor_url: str = ""
        self._config_set: str = ""

    def trigger(self, oemId: str, projectId: str, process: dict, defectIds: Optional[Union[str, list]]):

        if process is None:
            raise ValueError("Process information is required to trigger the exchange.")
            
        if process.get("instance") == "PROD1":
            logger.info("trigger: using PROD1 config")
            self._config_set = process.get("configset_name", "")
            self._trigger_url = PROD1_CONFIG["trigger_url"]
            self._monitor_url = PROD1_CONFIG["monitor_url"]
            self._username = PROD1_CONFIG["username"]
            self._password = PROD1_CONFIG["password"]
        elif process.get("instance") == "PROD2":
            logger.info("trigger: using PROD2 config")
            self._config_set = process.get("configset_name", "")
            self._trigger_url = PROD2_CONFIG["trigger_url"]
            self._monitor_url = PROD2_CONFIG["monitor_url"]
            self._username = PROD2_CONFIG["username"]
            self._password = PROD2_CONFIG["password"]
        else:
            raise ValueError(
                f"Unknown process instance '{process.get('instance')}'. "
                "Must be 'PROD1' or 'PROD2'."
            )

        random_id = str(uuid.uuid4())
        yield f"Generated Job ID: {random_id}\n"
        yield f"Triggering process '{process.get('java_process_name')}' for OEM: {oemId}, Project: {projectId}...\n"

        payload = {
            "jobId": random_id,
            "processName": process.get("java_process_name"),
            "processDomain": self._config_set,
            "processConfigSet": self._config_set,
        }
        
        headers = {
            'accept': 'application/json;charset=utf-8',
            'Content-Type': 'application/json;charset=utf-8',
            'X-CSRF': 'null'
        }

        # --- STEP 1: TRIGGER THE PROCESS ---
        try:
            with requests.Session() as session:
                session.auth = (self._username, self._password)
                response = session.post(self._trigger_url, json=payload, headers=headers, verify=False)
                response.raise_for_status()
                
                data = response.json()
                yield f"✔ Process triggered successfully. Status Code: {response.status_code}\n"
        except Exception as e:
            yield f"❌ Failed to trigger process: {str(e)}\n"
            yield "🏁 [EOF]\n"  # Ensure EOF is sent if it dies early
            return  

        # --- STEP 2: MONITOR THE JOB PROGRESS ---
        yield f"⏳ Monitoring Job: {random_id}...\n"
        
        # Wrapping the entire monitoring loop inside one master try...finally block
        try:
            with requests.Session() as session:
                session.auth = (self._username, self._password)

                while True:
                    try:
                        response = session.post(self._monitor_url, json={"jobId": random_id}, headers=headers, verify=False)
                        response.raise_for_status()
                        
                        data = response.json()
                        jobs = data.get("jobProgressList", [])
                        target_job = next((j for j in jobs if j["jobId"] == random_id), None)

                        if target_job:
                            succeeded = target_job["numberSucceededTasks"]
                            total = target_job["initialTaskCount"]
                            status = target_job["jobStatus"]
                            
                            progress = (succeeded / total * 100) if total > 0 else 0
                            yield f"Status: {status} | Progress: {progress:.1f}% ({succeeded}/{total})\n"

                            if status != 3:
                                yield f"🎉 Job Finished with Status: {status}.\n"
                                break 
                        else:
                            yield "⚠️ Job ID not found in the status list yet. Retrying...\n"

                    except Exception as e:
                        yield f"⚠️ Monitoring Warning: {e}\n"
                    
                    time.sleep(2)
        finally:
            # This block now perfectly encompasses the monitoring loop step
            yield "🏁 [EOF]\n"

    def get_process_list_old(self):
        with get_pg_connection() as conn:
            return repo.get_processes_list(conn)

    def get_process_list(self, project_ids):

        # User has no authorized AIDA projects
        if not project_ids:
            return {
                "oems": [],
                "projects": [],
                "processes": []
            }

        with get_pg_connection() as conn:
            return repo.get_processes_list(
                conn,
                project_ids
            )
