import argparse
from app.db.connection import get_pg_connection
from app.utils.logger import setup_logger

logger = setup_logger()

CREATE_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS conversations (
    id SERIAL PRIMARY KEY,
    session_id UUID NOT NULL,
    question TEXT NOT NULL,
    response_given TEXT NOT NULL,
    feedback VARCHAR(10), -- 'like' or 'dislike'
    comment TEXT,         -- statement of what should be improved
    input_tokens INT DEFAULT 0,
    output_tokens INT DEFAULT 0,
    total_tokens INT DEFAULT 0,
    tool_calls_count INT DEFAULT 0,
    tool_used VARCHAR(100) DEFAULT 'general', -- intent/category of request
    oem VARCHAR(100),
    project_key VARCHAR(100),
    process_name VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_conversations_session ON conversations(session_id);
"""

DROP_TABLE_SQL = "DROP TABLE IF EXISTS conversations CASCADE;"

def init_db():
    logger.info("Initializing monitoring database...")
    try:
        with get_pg_connection() as conn:
            with conn.cursor() as cur:
                cur.execute(CREATE_TABLE_SQL)
                conn.commit()
        logger.info("Monitoring database initialized successfully.")
    except Exception as e:
        logger.error("Failed to initialize monitoring database: %s", e)
        raise

def reset_db():
    logger.warning("Resetting monitoring database (dropping tables)...")
    try:
        with get_pg_connection() as conn:
            with conn.cursor() as cur:
                cur.execute(DROP_TABLE_SQL)
                cur.execute(CREATE_TABLE_SQL)
                conn.commit()
        logger.info("Monitoring database reset successfully.")
    except Exception as e:
        logger.error("Failed to reset monitoring database: %s", e)
        raise

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Manage monitoring database schema.")
    parser.add_argument("--reset", action="store_true", help="Drop and recreate the monitoring tables.")
    args = parser.parse_args()

    if args.reset:
        reset_db()
    else:
        init_db()
