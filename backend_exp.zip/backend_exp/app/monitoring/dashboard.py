import os
import sys
import streamlit as st
import pandas as pd
import plotly.express as px
from datetime import datetime, timedelta

# Set up path to import app modules
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../..")))

from app.db.connection import get_pg_connection
from dotenv import load_dotenv

load_dotenv()

st.set_page_config(
    page_title="AIDA Analytics & Feedback Dashboard",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── 1. Inject Premium Custom CSS (Theme Adaptive Color Variables) ────────────
st.markdown("""
<style>
    /* Google Fonts */
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
    
    /* Main body styling */
    .stApp {
        font-family: 'Inter', sans-serif;
    }
    
    /* Sidebar styling */
    [data-testid="stSidebar"] {
        background-color: var(--secondary-background-color) !important;
        border-right: 1px solid rgba(128, 128, 128, 0.2);
    }
    
    [data-testid="stSidebar"] .stMarkdown, [data-testid="stSidebar"] label {
        color: var(--text-color) !important;
        font-family: 'Inter', sans-serif;
    }
    
    /* Styled Metric Card Container */
    .kpi-card {
        background-color: var(--secondary-background-color);
        border: 1px solid rgba(128, 128, 128, 0.2);
        border-radius: 12px;
        padding: 22px;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.08);
        text-align: center;
        margin-bottom: 20px;
    }
    .kpi-value {
        font-size: 2.2rem;
        font-weight: 700;
        color: #4361ee;
        margin-bottom: 4px;
    }
    .kpi-label {
        font-size: 0.85rem;
        font-weight: 600;
        color: var(--text-color);
        opacity: 0.7;
        text-transform: uppercase;
        letter-spacing: 0.8px;
    }
    
    /* Tab Styling (50% / 50% width centered) */
    .stTabs [data-baseweb="tab-list"] {
        display: flex !important;
        width: 100% !important;
        gap: 0px !important;
        border-bottom: 1px solid rgba(128, 128, 128, 0.2);
        padding-bottom: 4px;
    }
    .stTabs [data-baseweb="tab"] {
        flex: 1 !important;
        text-align: center !important;
        justify-content: center !important;
        font-family: 'Inter', sans-serif;
        color: var(--text-color) !important;
        opacity: 0.6;
        font-weight: 600;
        font-size: 1.05rem;
        padding: 12px 18px;
        background-color: transparent !important;
        border: none !important;
    }
    .stTabs [aria-selected="true"] {
        color: #4361ee !important;
        opacity: 1.0 !important;
        border-bottom: 3px solid #4361ee !important;
    }
    
    /* Custom Headers */
    h1, h2, h3 {
        font-family: 'Inter', sans-serif;
        font-weight: 700;
    }
</style>
""", unsafe_allow_html=True)

# ── 2. Render Sidebar Logo & Heading ─────────────────────────────────────────
logo_path = os.path.join(os.path.dirname(__file__), "../../../frontend/public/logo_dark.png")
if os.path.exists(logo_path):
    st.sidebar.image(logo_path, width=160)
else:
    st.sidebar.title("🤖 AIDA")

st.sidebar.markdown("<h3 style='margin-top: 0;'>Control Panel</h3>", unsafe_allow_html=True)
st.sidebar.markdown("---")

# ── 3. Load DB Telemetry Records ─────────────────────────────────────────────
def load_data():
    try:
        with get_pg_connection() as conn:
            query = """
                SELECT 
                    id, 
                    session_id, 
                    question, 
                    response_given, 
                    feedback, 
                    comment, 
                    input_tokens, 
                    output_tokens, 
                    total_tokens, 
                    tool_calls_count,
                    tool_used, 
                    oem,
                    project_key,
                    process_name,
                    created_at 
                FROM conversations
                ORDER BY created_at DESC;
            """
            df = pd.read_sql(query, conn)
            if not df.empty:
                df['created_at'] = pd.to_datetime(df['created_at'])
            return df
    except Exception as e:
        st.error(f"Error loading database records: {e}")
        return pd.DataFrame()

df = load_data()

if df.empty:
    st.info("No telemetry logs found in the database. Start chat sessions to populate.")
else:
    # Fill N/As for context columns to allow clean sorting
    df['oem'] = df['oem'].fillna("N/A")
    df['project_key'] = df['project_key'].fillna("N/A")
    df['process_name'] = df['process_name'].fillna("N/A")

    # ── 4. Sidebar Hierarchical Filters ──────────────────────────────────────
    
    # 1. OEM Dropdown
    oems = sorted(list(df['oem'].unique()))
    selected_oem = st.sidebar.selectbox("Filter OEM", ["All"] + oems)
    
    # 2. Project Dropdown (Hierarchical - nested inside OEM)
    if selected_oem != "All":
        oem_filtered_df = df[df['oem'] == selected_oem]
    else:
        oem_filtered_df = df
        
    projects = sorted(list(oem_filtered_df['project_key'].unique()))
    selected_project = st.sidebar.selectbox("Filter Project", ["All"] + projects)
    
    # 3. Process Dropdown (Hierarchical - nested inside OEM + Project)
    if selected_project != "All":
        project_filtered_df = oem_filtered_df[oem_filtered_df['project_key'] == selected_project]
    else:
        project_filtered_df = oem_filtered_df
        
    processes = sorted(list(project_filtered_df['process_name'].unique()))
    selected_process = st.sidebar.selectbox("Filter Process", ["All"] + processes)
    
    # Apply context filters
    context_filtered_df = project_filtered_df
    if selected_process != "All":
        context_filtered_df = context_filtered_df[context_filtered_df['process_name'] == selected_process]

    # 4. Date selection (Placed at bottom of sidebar so calendar picker opens upwards, preventing cutoff)
    if not context_filtered_df.empty:
        min_date = context_filtered_df['created_at'].min().date()
        max_date = context_filtered_df['created_at'].max().date()
    else:
        min_date = datetime.now().date()
        max_date = datetime.now().date()
        
    date_range = st.sidebar.date_input(
        "Date Range",
        [min_date, max_date],
        min_value=min_date,
        max_value=max_date
    )
    
    start_date = date_range[0] if len(date_range) > 0 else min_date
    end_date = date_range[1] if len(date_range) > 1 else max_date
    
    # Apply final filters (Context + Date)
    filtered_df = context_filtered_df[
        (context_filtered_df['created_at'].dt.date >= start_date) & 
        (context_filtered_df['created_at'].dt.date <= end_date)
    ]

    # ── 5. Main Title & Navigation Tabs ──────────────────────────────────────
    st.markdown("## 📊 AIDA Analytics Dashboard")
    st.write(f"Showing logs from `{start_date}` to `{end_date}` | OEM: `{selected_oem}` | Project: `{selected_project}` | Process: `{selected_process}`")
    
    tab_token, tab_feedback = st.tabs(["⚡ Token & Tool Analytics", "💬 Feedback & Customer Satisfaction"])

    # ─────────────────────────────────────────────────────────────────────────
    # TAB 1: TOKEN & TOOL ANALYTICS
    # ─────────────────────────────────────────────────────────────────────────
    with tab_token:
        # KPI Metric Cards
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            total_tokens = filtered_df['total_tokens'].sum()
            st.markdown(f"""
            <div class="kpi-card">
                <div class="kpi-value">{total_tokens:,}</div>
                <div class="kpi-label">Total Tokens Used</div>
            </div>
            """, unsafe_allow_html=True)
            
        with col2:
            input_tokens = filtered_df['input_tokens'].sum()
            st.markdown(f"""
            <div class="kpi-card">
                <div class="kpi-value">{input_tokens:,}</div>
                <div class="kpi-label">Input Prompt Tokens</div>
            </div>
            """, unsafe_allow_html=True)
            
        with col3:
            output_tokens = filtered_df['output_tokens'].sum()
            st.markdown(f"""
            <div class="kpi-card">
                <div class="kpi-value">{output_tokens:,}</div>
                <div class="kpi-label">Output Gen Tokens</div>
            </div>
            """, unsafe_allow_html=True)
            
        with col4:
            tool_invocations = filtered_df['tool_calls_count'].sum()
            st.markdown(f"""
            <div class="kpi-card">
                <div class="kpi-value">{tool_invocations:,}</div>
                <div class="kpi-label">Total Tool Calls</div>
            </div>
            """, unsafe_allow_html=True)
            
        st.markdown("---")
        
        # Visual breakdown charts
        chart_col1, chart_col2 = st.columns(2)
        
        with chart_col1:
            st.markdown("### Token Distribution Ratio")
            if total_tokens > 0:
                ratio_df = pd.DataFrame({
                    "Type": ["Input Tokens", "Output Tokens"],
                    "Count": [input_tokens, output_tokens]
                })
                fig_ratio = px.pie(
                    ratio_df,
                    names='Type',
                    values='Count',
                    color='Type',
                    color_discrete_map={'Input Tokens': '#4361ee', 'Output Tokens': '#2eca7f'},
                    hole=0.45
                )
                fig_ratio.update_layout(
                    paper_bgcolor='rgba(0,0,0,0)',
                    plot_bgcolor='rgba(0,0,0,0)',
                    font_family="Inter",
                    font_color="#888888"
                )
                st.plotly_chart(fig_ratio, use_container_width=True)
            else:
                st.info("No token records in selected context.")
                
        with chart_col2:
            st.markdown("### Token Allocation by Tool Category")
            if not filtered_df.empty:
                token_by_tool = filtered_df.groupby('tool_used')['total_tokens'].sum().reset_index()
                fig_tool_tokens = px.bar(
                    token_by_tool,
                    x='total_tokens',
                    y='tool_used',
                    orientation='h',
                    color='tool_used',
                    labels={'total_tokens': 'Total Tokens', 'tool_used': 'Tool Category'}
                )
                fig_tool_tokens.update_layout(
                    paper_bgcolor='rgba(0,0,0,0)',
                    plot_bgcolor='rgba(0,0,0,0)',
                    font_family="Inter",
                    font_color="#888888",
                    showlegend=False
                )
                st.plotly_chart(fig_tool_tokens, use_container_width=True)
            else:
                st.info("No logs found.")
                
        st.markdown("---")
        
        # Data-Heavy Tool Invocation Matrix
        st.markdown("### 🛠️ Detailed Tool Invocation Matrix (By OEM, Project, Process)")
        if not filtered_df.empty:
            matrix_df = filtered_df.groupby(['oem', 'project_key', 'process_name', 'tool_used']).agg(
                invocations=('tool_calls_count', 'sum'),
                total_tokens=('total_tokens', 'sum'),
                avg_tokens=('total_tokens', 'mean'),
                turns_handled=('id', 'count')
            ).reset_index()
            
            # Format numbers
            matrix_df['avg_tokens'] = matrix_df['avg_tokens'].round(1)
            
            st.dataframe(
                matrix_df.rename(columns={
                    "oem": "OEM",
                    "project_key": "Project Key",
                    "process_name": "Process",
                    "tool_used": "Tool/Intent Name",
                    "invocations": "Tool Executions",
                    "total_tokens": "Total Tokens Used",
                    "avg_tokens": "Avg Tokens/Turn",
                    "turns_handled": "Total Chat Turns"
                }),
                use_container_width=True
            )
        else:
            st.info("No data in selected context.")

    # ─────────────────────────────────────────────────────────────────────────
    # TAB 2: FEEDBACK & CUSTOMER SATISFACTION
    # ─────────────────────────────────────────────────────────────────────────
    with tab_feedback:
        # Ratings calculations
        fb_df = filtered_df[filtered_df['feedback'].notna() & (filtered_df['feedback'] != '')]
        total_feedback = len(fb_df)
        likes = len(fb_df[fb_df['feedback'] == 'like'])
        dislikes = len(fb_df[fb_df['feedback'] == 'dislike'])
        csat = round((likes / total_feedback) * 100, 1) if total_feedback > 0 else 100.0
        
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.markdown(f"""
            <div class="kpi-card">
                <div class="kpi-value">{csat}%</div>
                <div class="kpi-label">Satisfaction Rate (CSAT)</div>
            </div>
            """, unsafe_allow_html=True)
            
        with col2:
            st.markdown(f"""
            <div class="kpi-card">
                <div class="kpi-value">{total_feedback}</div>
                <div class="kpi-label">Total Feedbacks</div>
            </div>
            """, unsafe_allow_html=True)
            
        with col3:
            st.markdown(f"""
            <div class="kpi-card" style="border-bottom: 4px solid #2eca7f;">
                <div class="kpi-value" style="color: #2eca7f;">{likes}</div>
                <div class="kpi-label">Thumbs Up (Likes)</div>
            </div>
            """, unsafe_allow_html=True)
            
        with col4:
            st.markdown(f"""
            <div class="kpi-card" style="border-bottom: 4px solid #e05c5c;">
                <div class="kpi-value" style="color: #e05c5c;">{dislikes}</div>
                <div class="kpi-label">Thumbs Down (Dislikes)</div>
            </div>
            """, unsafe_allow_html=True)
            
        st.markdown("---")
        
        chart_col1, chart_col2 = st.columns(2)
        
        with chart_col1:
            st.markdown("### User Ratings Breakdown")
            if total_feedback > 0:
                ratings_df = pd.DataFrame({
                    "Rating": ["Likes (👍)", "Dislikes (👎)"],
                    "Count": [likes, dislikes]
                })
                fig_ratings = px.pie(
                    ratings_df,
                    names='Rating',
                    values='Count',
                    color='Rating',
                    color_discrete_map={'Likes (👍)': '#2eca7f', 'Dislikes (👎)': '#e05c5c'},
                    hole=0.45
                )
                fig_ratings.update_layout(
                    paper_bgcolor='rgba(0,0,0,0)',
                    plot_bgcolor='rgba(0,0,0,0)',
                    font_family="Inter",
                    font_color="#888888"
                )
                st.plotly_chart(fig_ratings, use_container_width=True)
            else:
                st.info("No ratings received in the selected context.")
                
        with chart_col2:
            st.markdown("### Tool-Wise Satisfaction Comparison")
            if total_feedback > 0:
                tool_csat_df = fb_df.groupby(['tool_used', 'feedback']).size().unstack(fill_value=0).reset_index()
                
                # Verify columns exist
                if 'like' not in tool_csat_df.columns:
                    tool_csat_df['like'] = 0
                if 'dislike' not in tool_csat_df.columns:
                    tool_csat_df['dislike'] = 0
                    
                fig_tool_csat = px.bar(
                    tool_csat_df,
                    x='tool_used',
                    y=['like', 'dislike'],
                    barmode='group',
                    labels={'value': 'Count', 'variable': 'Rating', 'tool_used': 'Tool Category'},
                    color_discrete_map={'like': '#2eca7f', 'dislike': '#e05c5c'}
                )
                fig_tool_csat.update_layout(
                    paper_bgcolor='rgba(0,0,0,0)',
                    plot_bgcolor='rgba(0,0,0,0)',
                    font_family="Inter",
                    font_color="#888888"
                )
                st.plotly_chart(fig_tool_csat, use_container_width=True)
            else:
                st.info("No feedback metrics received yet.")
                
        st.markdown("---")
        
        # Improvement suggestions
        st.markdown("### 💬 Improvement Opportunities (Disliked Chats with Comments)")
        disliked_df = filtered_df[filtered_df['feedback'] == 'dislike'][
            ['created_at', 'oem', 'project_key', 'process_name', 'question', 'response_given', 'comment']
        ]
        
        if not disliked_df.empty:
            st.dataframe(
                disliked_df.rename(columns={
                    "created_at": "Timestamp",
                    "oem": "OEM",
                    "project_key": "Project Key",
                    "process_name": "Process",
                    "question": "User Query",
                    "response_given": "AI Response",
                    "comment": "Correction / Improvement Suggestion"
                }),
                use_container_width=True
            )
        else:
            st.success("No improvement suggestions in the selected context!")

        st.markdown("---")
        
        # General search logs
        st.markdown("### 🔍 Telemetry Search & Raw Logs")
        search_query = st.text_input("Filter raw logs by keyword (searches query and response content)")
        
        search_df = filtered_df.copy()
        if search_query:
            search_df = search_df[
                search_df['question'].str.contains(search_query, case=False, na=False) |
                search_df['response_given'].str.contains(search_query, case=False, na=False)
            ]
            
        st.dataframe(
            search_df[['created_at', 'session_id', 'question', 'response_given', 'tool_used', 'total_tokens', 'feedback', 'comment']].rename(columns={
                "created_at": "Timestamp",
                "session_id": "Session ID",
                "question": "User Query",
                "response_given": "AI Response",
                "tool_used": "Tool Intent",
                "total_tokens": "Tokens Used",
                "feedback": "Feedback",
                "comment": "Comment"
            }),
            use_container_width=True
        )
