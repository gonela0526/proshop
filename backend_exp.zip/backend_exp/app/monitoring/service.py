from app.db.connection import get_pg_connection
from app.utils.logger import setup_logger

logger = setup_logger()

def log_conversation(session_id: str, question: str, response_given: str, input_tokens: int, output_tokens: int, tool_used: str, tool_calls_count: int, oem: str, project_key: str, process_name: str):
    logger.info("Logging conversation for session %s (tool: %s)", session_id, tool_used)
    total_tokens = (input_tokens or 0) + (output_tokens or 0)
    try:
        with get_pg_connection() as conn:
            with conn.cursor() as cur:
                cur.execute("""
                    INSERT INTO conversations
                    (session_id, question, response_given, input_tokens, output_tokens, total_tokens, tool_calls_count, tool_used, oem, project_key, process_name)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s);
                """, (
                    session_id,
                    question,
                    response_given,
                    input_tokens or 0,
                    output_tokens or 0,
                    total_tokens,
                    tool_calls_count or 0,
                    tool_used or "general",
                    oem,
                    project_key,
                    process_name
                ))
                conn.commit()
    except Exception as e:
        logger.error("Failed to log conversation for session %s: %s", session_id, e)

def update_conversation_feedback(session_id: str, feedback: str, comment: str):
    logger.info("Updating feedback for session %s: %s", session_id, feedback)
    try:
        with get_pg_connection() as conn:
            with conn.cursor() as cur:
                # Find the most recent conversation exchange for this session
                cur.execute("""
                    UPDATE conversations
                    SET feedback = %s, comment = %s
                    WHERE id = (
                        SELECT id FROM conversations
                        WHERE session_id = %s
                        ORDER BY created_at DESC
                        LIMIT 1
                    );
                """, (feedback, comment, session_id))
                conn.commit()
    except Exception as e:
        logger.error("Failed to update feedback for session %s: %s", session_id, e)
