"""JQL Parser & Auditor Utility
=============================
Utility functions to parse Jira Query Language (JQL) filters to explain
them in plain English and audit them for security and performance issues.
"""

import re


def explain_jql(jql: str) -> dict:
    """Parses key clauses from a JQL query to build a friendly breakdown of what it targets."""
    explanation = {"projects": [], "issue_types": [], "statuses": []}

    # Normalise whitespace
    normalized = re.sub(r"\s+", " ", jql.strip())

    # Regex helper for values (either single value or in-list)
    def extract_values(field: str) -> list[str]:
        pattern = rf"\b{field}\s*(=|in)\s*(\([^)]+\)|'[^\']+'|\"[^\"]+\"|[^\s\)]+)"
        matches = re.finditer(pattern, normalized, re.IGNORECASE)
        results = []
        for match in matches:
            val_group = match.group(2).strip()
            if val_group.startswith("(") and val_group.endswith(")"):
                # Split elements by comma, strip quotes
                for v in re.split(r"\s*,\s*", val_group[1:-1]):
                    clean_v = v.strip("'\" ")
                    if clean_v:
                        results.append(clean_v)
            else:
                clean_v = val_group.strip("'\" ")
                if clean_v:
                    results.append(clean_v)
        return results

    explanation["projects"] = extract_values("project")
    explanation["issue_types"] = extract_values("issuetype") + extract_values("type")
    explanation["statuses"] = extract_values("status")

    return explanation


def audit_jql(jql: str) -> list[dict]:
    """Audits a JQL query for performance and security risks.

    Returns a list of check results with status (pass, warn, fail) and message.
    """
    checks = []
    normalized = jql.lower()

    # 1. Project Scope check
    if "project =" in normalized or "project in" in normalized:
        checks.append(
            {
                "status": "pass",
                "rule": "Project Scope",
                "message": "The query is properly scoped to specific project(s).",
            }
        )
    else:
        checks.append(
            {
                "status": "fail",
                "rule": "Project Scope",
                "message": "CRITICAL: No project clause found. This query is global and will scan all projects, risking synchronization performance degradation and connection timeouts.",
            }
        )

    # 2. Issue Type check
    if any(k in normalized for k in ["issuetype =", "issuetype in", "type =", "type in"]):
        checks.append(
            {
                "status": "pass",
                "rule": "Issue Type Scope",
                "message": "The query specifies target issue types.",
            }
        )
    else:
        checks.append(
            {
                "status": "warn",
                "rule": "Issue Type Scope",
                "message": "WARNING: No issue type clause found. The sync will query all issue types (Stories, Tasks, Bugs, etc.) which may cause sync failures if some types are unmapped.",
            }
        )

    # 3. Time bounds check
    if any(k in normalized for k in ["updated >", "updated <", "updateddate", "created >", "created <"]):
        checks.append(
            {
                "status": "pass",
                "rule": "Time Bounds",
                "message": "The query has chronological bounds configured (e.g. updated date checks).",
            }
        )
    else:
        checks.append(
            {
                "status": "warn",
                "rule": "Time Bounds",
                "message": "WARNING: No time constraints (like `updated >= -7d` or similar) were detected. The process will scan the entire historical list of matching tickets, which reduces sync performance.",
            }
        )

    return checks
