import logging
import sys

def setup_logger():
    """
    Sets up a structured logger for the exchange_engine.
    Includes function name and line number for better traceability.
    """
    logger = logging.getLogger("exchange_engine")
    
    # Prevent adding multiple handlers if the logger is already initialized
    if not logger.handlers:
        handler = logging.StreamHandler(sys.stdout)
        formatter = logging.Formatter(
            "%(asctime)s | %(levelname)s | [%(name)s] | %(funcName)s:%(lineno)d | %(message)s"
        )
        handler.setFormatter(formatter)
        logger.addHandler(handler)
        logger.setLevel(logging.INFO)
        
    return logger
