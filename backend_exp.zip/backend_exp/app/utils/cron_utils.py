from datetime import datetime
from typing import List, Dict
from cron_descriptor import get_description
from croniter import croniter
import pytz


DEFAULT_TIMEZONE = "UTC"


def clean_cron(cron_expression: str) -> str:
    """
    Cleans cron expression: converts 6/7 field Quartz cron to standard 5-field cron,
    and replaces '?' with '*'.
    """
    parts = cron_expression.strip().split()
    if len(parts) >= 6:
        parts = parts[1:6]
    parts = [p.replace('?', '*') for p in parts]
    return " ".join(parts)


def cron_to_readable(cron_expression: str) -> str:
    """
    Convert cron expression into readable English format.
    """
    cron_clean = clean_cron(cron_expression)
    try:
        return get_description(cron_clean)
    except Exception:
        return "Invalid cron expression"


from dateutil import tz

def get_next_run_times(
    cron_expression: str,
    count: int = 3,
    timezone: str = DEFAULT_TIMEZONE
) -> List[str]:
    """
    Returns next N run times in readable format.
    Assumes cron is configured in America/New_York (server timezone) and converts
    occurrences to target timezone (user's browser timezone).
    """
    cron_clean = clean_cron(cron_expression)

    try:
        server_tz = pytz.timezone("America/New_York")
        # dateutil.tz handles 'IST', 'India Standard Time', etc. much better than pytz
        target_tz = tz.gettz(timezone) or pytz.timezone("America/New_York")
    except Exception:
        server_tz = pytz.timezone("America/New_York")
        target_tz = server_tz

    try:
        now_server = datetime.now(server_tz)
        iterator = croniter(cron_clean, now_server)

        runs = []
        for _ in range(count):
            next_run_server = iterator.get_next(datetime)
            # Ensure it is timezone-aware in server timezone before converting
            if next_run_server.tzinfo is None:
                next_run_server = server_tz.localize(next_run_server)
                
            next_run_target = next_run_server.astimezone(target_tz)
            runs.append(next_run_target.strftime("%Y-%m-%d %I:%M %p %Z"))

        return runs

    except Exception as e:
        return [f"Error calculating next runs: {e}"]


def get_timezone_adjusted_schedule(cron_expression: str, target_tz_name: str) -> str:
    """
    Convert cron expression execution times into target timezone if different from server timezone.
    """
    cron_clean = clean_cron(cron_expression)

    try:
        server_tz = pytz.timezone("America/New_York")
        target_tz = tz.gettz(target_tz_name) or pytz.timezone("America/New_York")
    except Exception:
        server_tz = pytz.timezone("America/New_York")
        target_tz = server_tz

    readable_base = cron_to_readable(cron_expression)

    # Check if target_tz is the same as server_tz or has the same current offset
    now = datetime.now()
    try:
        # Standard way to get offset that works for both pytz and dateutil
        server_offset = datetime.now(server_tz).utcoffset()
        target_offset = datetime.now(target_tz).utcoffset()
    except Exception:
        return readable_base

    if server_offset == target_offset:
        # Same timezone offset, no conversion needed!
        return readable_base

    # Different offset! We need to convert the execution times.
    try:
        now_server = datetime.now(server_tz)
        iterator = croniter(cron_clean, now_server)

        unique_times = set()
        # Look at the next 24 runs to find the unique times of day in target timezone
        for _ in range(24):
            next_run_server = iterator.get_next(datetime)
            if next_run_server.tzinfo is None:
                next_run_server = server_tz.localize(next_run_server)
                
            next_run_target = next_run_server.astimezone(target_tz)
            unique_times.add(next_run_target.strftime("%H:%M"))

        sorted_times = sorted(list(unique_times))
        if not sorted_times:
            return readable_base

        # Format times as 12h AM/PM format
        formatted_times = []
        for t_str in sorted_times:
            try:
                dt_obj = datetime.strptime(t_str, "%H:%M")
                formatted_times.append(dt_obj.strftime("%I:%M %p").lstrip('0'))
            except Exception:
                formatted_times.append(t_str)

        if len(formatted_times) == 1:
            local_time_part = f"at {formatted_times[0]}"
        elif len(formatted_times) == 2:
            local_time_part = f"at {formatted_times[0]} and {formatted_times[1]}"
        elif len(formatted_times) <= 6:
            times_str = ", ".join(formatted_times[:-1]) + f", and {formatted_times[-1]}"
            local_time_part = f"at {times_str}"
        else:
            # Too many execution times (e.g. hourly/minutely), timezone-agnostic base description is better
            return readable_base

        # Merge with day/week details
        parts = readable_base.split(',', 1)
        local_cap = local_time_part[0].upper() + local_time_part[1:]
        if len(parts) > 1:
            return local_cap + ", " + parts[1].strip()
        return local_cap

    except Exception:
        return readable_base


def build_schedule_response(
    project_key: str,
    process_name: str,
    cron_expression: str,
    timezone: str = DEFAULT_TIMEZONE,
    oem: str = None
) -> Dict:
    """
    Unified structured schedule response.
    """
    readable = cron_to_readable(cron_expression)
    local_readable = get_timezone_adjusted_schedule(cron_expression, timezone)

    return {
        "status": "success",
        "project_key": project_key,
        "process_name": process_name,
        "oem": oem,
        "cron_expression": cron_expression,
        "readable_schedule": readable,
        "local_schedule": local_readable,
        "timezone": timezone,
        "next_runs": get_next_run_times(
            cron_expression,
            count=3,
            timezone=timezone
        )
    }
