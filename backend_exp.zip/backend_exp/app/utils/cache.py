"""In-memory TTL cache for expensive config/metadata lookups.

Usage::

    from app.utils.cache import timed_cache

    @timed_cache(ttl_seconds=300)
    def expensive_lookup(key: str) -> dict:
        ...

The cache is keyed on all positional and keyword arguments.
It is process-level (not shared across workers) and is suitable for
read-heavy, rarely-changing data like OEM lists, project maps, and
config keys.
"""

import time
import threading
from functools import wraps
from typing import Any, Callable, Dict, Tuple

_lock = threading.Lock()


class _CacheEntry:
    __slots__ = ("value", "expires_at")

    def __init__(self, value: Any, expires_at: float):
        self.value = value
        self.expires_at = expires_at


_STORE: Dict[Tuple, _CacheEntry] = {}


def timed_cache(ttl_seconds: int = 300):
    """Decorator factory that caches function return values for `ttl_seconds`.

    Thread-safe.  A stale entry is silently discarded and the function is
    re-called to repopulate the cache.
    """

    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*args, **kwargs):
            key = (func.__module__, func.__qualname__, args, tuple(sorted(kwargs.items())))
            now = time.monotonic()

            with _lock:
                entry = _STORE.get(key)
                if entry is not None and entry.expires_at > now:
                    return entry.value

            # Outside the lock to avoid blocking other threads while computing
            value = func(*args, **kwargs)

            with _lock:
                _STORE[key] = _CacheEntry(value, now + ttl_seconds)

            return value

        def invalidate(*args, **kwargs):
            """Remove a specific entry (or all entries for this function if no args given)."""
            with _lock:
                prefix = (func.__module__, func.__qualname__)
                if args or kwargs:
                    key = (func.__module__, func.__qualname__, args, tuple(sorted(kwargs.items())))
                    _STORE.pop(key, None)
                else:
                    to_delete = [k for k in _STORE if k[:2] == prefix]
                    for k in to_delete:
                        del _STORE[k]

        wrapper.invalidate = invalidate  # type: ignore[attr-defined]
        return wrapper

    return decorator


def cache_stats() -> Dict[str, int]:
    """Return current cache occupancy stats."""
    now = time.monotonic()
    with _lock:
        total = len(_STORE)
        alive = sum(1 for e in _STORE.values() if e.expires_at > now)
    return {"total_entries": total, "alive_entries": alive, "stale_entries": total - alive}
