(function () {
  "use strict";

  // ==========================================
  // 1. TIMEZONE INJECTION
  // ==========================================
  try {
    const tz = Intl.DateTimeFormat().resolvedOptions().timeZone;

    if (tz) {
      const tzInterval = setInterval(() => {
        if (window.sendChainlitMessage) {
          // Explicitly stringify the object so json.loads() on the backend is guaranteed to catch it
          window.sendChainlitMessage(
            JSON.stringify({ type: "timezone", timezone: tz }),
          );
          clearInterval(tzInterval);
        }
      }, 500);
    }
  } catch (e) {
    console.error("Failed to capture timezone:", e);
  }

  // ==========================================
  // 2. CUSTOM UI STYLES & BEHAVIOR (From test.js)
  // ==========================================
  function injectStyles() {
    if (!document.getElementById("custom-aida-styles")) {
      const style = document.createElement("style");
      style.id = "custom-aida-styles";
      style.innerHTML = `
                /* Hide the attach button completely */
                button[aria-label*="attach" i],
                button[title*="attach" i],
                button[id*="attach" i],
                button[aria-label*="file" i],
                button[title*="file" i],
                button[id*="file" i],
                input[type="file"],
                .attach-button-class-if-any {
                    display: none !important;
                }

                /* Limit the height of the select dropdown popups and add scrollbar */
                [role="listbox"],
                ul[role="listbox"],
                div[role="listbox"],
                [data-radix-select-viewport],
                .MuiMenu-paper,
                .MuiPopover-paper,
                [class*="select-content" i],
                [class*="SelectContent" i] {
                    max-height: 250px !important;
                    overflow-y: auto !important;
                }
            `;
      document.head.appendChild(style);
    }
  }

  function customizeUI() {
    // Inject styles if they aren't there yet[cite: 2]
    injectStyles();

    // 1. Hide attach icon and customize settings button attributes[cite: 2]
    const buttons = document.querySelectorAll("button");
    buttons.forEach((btn) => {
      const ariaLabel = (btn.getAttribute("aria-label") || "").toLowerCase();
      const id = (btn.getAttribute("id") || "").toLowerCase();

      if (
        ariaLabel.includes("attach") ||
        ariaLabel.includes("file") ||
        id.includes("attach")
      ) {
        btn.style.setProperty("display", "none", "important");
      }

      if (
        ariaLabel.includes("setting") ||
        ariaLabel.includes("config") ||
        id.includes("setting") ||
        id.includes("config")
      ) {
        btn.setAttribute("title", "Set OEM Config");
        btn.setAttribute("aria-label", "Set OEM Config");
      }
    });

    // 2. Change Custom Tooltip text[cite: 2]
    const tooltips = document.querySelectorAll('[role="tooltip"]');
    tooltips.forEach((t) => {
      const txt = t.textContent.trim().toLowerCase();
      if (
        txt === "chat settings" ||
        txt === "settings" ||
        txt === "chat settings panel"
      ) {
        t.textContent = "Set OEM Config";
      }
    });

    // 3. Change Dialog Header Title[cite: 2]
    const dialogTitle = document.querySelector(
      '[role="dialog"] h2, [role="dialog"] [id*="title"], [role="dialog"] h6',
    );
    if (
      dialogTitle &&
      (dialogTitle.textContent === "Settings" ||
        dialogTitle.textContent.includes("settings") ||
        dialogTitle.textContent.includes("Settings"))
    ) {
      dialogTitle.textContent = "Set OEM Config";
    }

    const headers = document.querySelectorAll('[role="dialog"] *');
    headers.forEach((h) => {
      if (
        h.childNodes.length === 1 &&
        h.childNodes[0].nodeType === Node.TEXT_NODE
      ) {
        const txt = h.textContent.trim();
        if (
          txt === "Settings" ||
          txt === "Settings panel" ||
          txt === "Chat settings"
        ) {
          h.textContent = "Set OEM Config";
        }
      }
    });
  }

  // Run regularly to handle dynamic React rendering updates[cite: 2]
  setInterval(customizeUI, 200);

  // ==========================================
  // 3. MESSAGE TIMESTAMPS (From timestamps.js)
  // ==========================================
  const TIMESTAMP_CLASS = "msg-timestamp";

  function formatTime(date) {
    return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  }

  function addTimestamp(msgEl) {
    if (msgEl.querySelector("." + TIMESTAMP_CLASS)) return;

    const ts = document.createElement("span");
    ts.className = TIMESTAMP_CLASS;
    ts.textContent = formatTime(new Date());
    ts.style.cssText =
      "display:block;font-size:0.65rem;opacity:0.45;margin-top:2px;" +
      "font-family:var(--font-sans, inherit);user-select:none;";

    msgEl.appendChild(ts); // Append timestamp at the bottom of the message container[cite: 3]
  }

  function processMessages() {
    const messages = document.querySelectorAll(
      '.step:not([data-ts-processed]), [class*="message"]:not([data-ts-processed])',
    );

    messages.forEach((msg) => {
      const isUserMsg =
        msg.closest('[class*="user"]') ||
        msg.getAttribute("data-testid")?.includes("user");
      const isAssistantMsg =
        msg.closest('[class*="assistant"]') ||
        msg.getAttribute("data-testid")?.includes("assistant") ||
        msg.closest(".step") !== null;

      if (isUserMsg || isAssistantMsg) {
        const targetEl = msg.querySelector(".message-content") || msg;
        addTimestamp(targetEl);
        msg.setAttribute("data-ts-processed", "true");
      }
    });
  }

  // Observe DOM changes for dynamically added messages[cite: 3]
  const observer = new MutationObserver(function (mutations) {
    let shouldProcess = false;
    for (const m of mutations) {
      if (m.addedNodes.length > 0) {
        for (const node of m.addedNodes) {
          if (
            node.nodeType === 1 &&
            (node.className?.includes?.("message") ||
              node.className?.includes?.("step"))
          ) {
            shouldProcess = true;
            break;
          } else if (
            node.nodeType === 1 &&
            node.querySelector &&
            (node.querySelector(".step") ||
              node.querySelector('[class*="message"]'))
          ) {
            shouldProcess = true;
            break;
          }
        }
      }
    }
    if (shouldProcess) {
      requestAnimationFrame(processMessages);
    }
  });

  // Start observing once the DOM is ready[cite: 3]
  function init() {
    const target = document.getElementById("root") || document.body;
    observer.observe(target, { childList: true, subtree: true });
    setTimeout(processMessages, 500);
    setInterval(processMessages, 3000);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
