(function () {
  // Get the user's local IANA timezone name
  const tz = Intl.DateTimeFormat().resolvedOptions().timeZone;

  // Send timezone to the Chainlit frontend
  setTimeout(() => {
    window.postMessage({ type: "timezone", timezone: tz }, "*");
  }, 1500);

  // Inject Custom CSS styles
  function injectStyles() {
    if (!document.getElementById("custom-aida-styles")) {
      const style = document.createElement("style");
      style.id = "custom-aida-styles";
      style.innerHTML = `
                /* Hide the attach button completely */
                button[aria-label*="attach" i],
                button[title*="attach" i],
                button[id*="attach" i],
                button[aria-label*="file" i],
                button[title*="file" i],
                button[id*="file" i],
                input[type="file"],
                .attach-button-class-if-any {
                    display: none !important;
                }

                /* Limit the height of the select dropdown popups and add scrollbar */
                [role="listbox"],
                ul[role="listbox"],
                div[role="listbox"],
                [data-radix-select-viewport],
                .MuiMenu-paper,
                .MuiPopover-paper,
                [class*="select-content" i],
                [class*="SelectContent" i] {
                    max-height: 250px !important;
                    overflow-y: auto !important;
                }
            `;
      document.head.appendChild(style);
    }
  }

  // Dynamic UI customization loop
  function customizeUI() {
    // Inject styles if they aren't there yet
    injectStyles();

    // 1. Hide attach icon and customize settings button attributes
    const buttons = document.querySelectorAll("button");
    buttons.forEach((btn) => {
      const ariaLabel = (btn.getAttribute("aria-label") || "").toLowerCase();
      const id = (btn.getAttribute("id") || "").toLowerCase();

      // Remove Attach button
      if (
        ariaLabel.includes("attach") ||
        ariaLabel.includes("file") ||
        id.includes("attach")
      ) {
        btn.style.setProperty("display", "none", "important");
      }

      // Customize Settings button
      if (
        ariaLabel.includes("setting") ||
        ariaLabel.includes("config") ||
        id.includes("setting") ||
        id.includes("config") ||
        btn.getAttribute("aria-haspopup") === "dialog"
      ) {
        // Set the tooltip text for browser-native hover tooltips
        btn.setAttribute("title", "Set OEM Config");

        // Set aria-label to improve accessibility and tooltip fallback behavior
        btn.setAttribute("aria-label", "Set OEM Config");

        const rect = btn.getBoundingClientRect();
      }
    });

    // 2. Change Custom Tooltip text (e.g. Radix/Shadcn Tooltip)
    const tooltips = document.querySelectorAll('[role="tooltip"]');
    tooltips.forEach((t) => {
      const txt = t.textContent.trim().toLowerCase();
      if (
        txt === "chat settings" ||
        txt === "settings" ||
        txt === "chat settings panel"
      ) {
        t.textContent = "Set OEM Config";
      }
    });

    // 3. Change Dialog Header Title ("Settings" or "Settings panel") to "Set OEM Config"
    const dialogTitle = document.querySelector(
      '[role="dialog"] h2, [role="dialog"] [id*="title"], [role="dialog"] h6',
    );
    if (
      dialogTitle &&
      (dialogTitle.textContent === "Settings" ||
        dialogTitle.textContent.includes("settings") ||
        dialogTitle.textContent.includes("Settings"))
    ) {
      dialogTitle.textContent = "Set OEM Config";
    }

    // Also look for dialog header text nodes
    const headers = document.querySelectorAll('[role="dialog"] *');
    headers.forEach((h) => {
      if (
        h.childNodes.length === 1 &&
        h.childNodes[0].nodeType === Node.TEXT_NODE
      ) {
        const txt = h.textContent.trim();
        if (
          txt === "Settings" ||
          txt === "Settings panel" ||
          txt === "Chat settings"
        ) {
          h.textContent = "Set OEM Config";
        }
      }
    });
  }

  // Run regularly to handle dynamic React rendering updates
  setInterval(customizeUI, 200);
})();
