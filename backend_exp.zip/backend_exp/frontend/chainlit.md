# 🤖 Welcome to AIDA (Automotive Intelligent Defect Assistant)

**AIDA** is your conversational operations copilot designed to help you monitor, inspect, and troubleshoot your automotive data exchange pipelines (ALM, Jira, and Agosense integrations) in real-time.

---

## ⚙️ How to Set Your Context (OEM, Project, Process)

To help AIDA retrieve the correct information, you must select your context. Follow these steps:

> [!IMPORTANT]
>
> 1. Look at the bottom of the screen inside the **Chat Input Composer** (next to where you type your questions).
> 2. Click the **Settings (Sliders) Button** (🔧/⚙️ icon).
> 3. A popover settings panel will expand. Select your:
>    - 🏢 **OEM** (e.g., `AUDI`, `FORD`, `MAHINDRA`)
>    - 📁 **Project Key** (e.g., `PAG24147`, `MS22029826`)
>    - 🔄 **Process Name** (e.g., `AudiEtrigtoVisteonJira`)
> 4. Once selected, AIDA stores this context in your active session. You can now ask questions directly, and AIDA will automatically query that specific pipeline!

---

## 💡 What Can AIDA Do?

AIDA is pre-configured to handle key data integration tasks. Ask AIDA questions regarding:

- 📅 **Execution Schedules**: Check when integration processes run, cron parameters, and next scheduled sync times.
- 🗺️ **Field & Value Mappings**: Retrieve field mappings or value lookup tables (e.g., how severity and priorities map between Jira and ALM).
- 🚨 **Sync Failures & Health Logs**: Trace recent pipeline failures and get a ranked list of top root-cause error reasons.
- ⚙️ **Configurations**: Inspect specific exchange flags (e.g., check if attachment sync is enabled or comment transfer is active).
- 🔍 **Filter Queries (JQL)**: Retrieve search filters and queries configured for data retrieval.
- 🧾 **Defect Auditing**: Trace the complete synchronization timeline and history logs for specific ticket or defect IDs.

---

## 💬 Sample Queries to Try

#### 📅 Schedules & Health

- _“When does the process run next?”_
- _“What is the schedule for this process?”_
- _“Show me recent sync failures”_
- _“What are the top failure reasons?”_

#### 🗺️ Mappings & Configurations

- _“Can you please provide the mapping schema?”_
- _“Provide the value mapping for priority and severity”_
- _“Is attachment sync enabled?”_
- _“Show the JQL filter query used in this process”_

#### 🔍 Defect History

- _“Check sync history for defect W502CDC-47269”_
- _“Trace sync status for ticket W502CDC-47269 and W502CDC-47595”_

---

> **Domain-Specific System**: AIDA is optimized exclusively for automotive data integration processes. It will politely decline general knowledge queries or off-topic conversation to prioritize system tokens.

---

## 📞 Contact Information

For any Agosense or AIDA related queries and concerns, please reach out to:

- **Agosense Support**: [EIT-Agosense@visteon.com](mailto:EIT-Agosense@visteon.com)
- **Alfred Miranda**: [amiran11@visteon.com](mailto:amiran11@visteon.com)
