import re
import sys

try:
    with open('/Users/harnish/Documents/AIDA/frontend/chainlit_app.py', 'r') as f:
        content = f.read()

    # 1. Eager session creation and No Default Context
    new_start_func = """@cl.on_chat_start
async def start():
    cl.user_session.set("session_id", None)
    
    # Eager session creation
    try:
        import httpx
        async with httpx.AsyncClient(timeout=_HTTP_TIMEOUT) as client:
            res = await client.get(f"{BACKEND_URL}/create-session")
            session_data = res.json()
            session_id = session_data["session_id"]
            cl.user_session.set("session_id", session_id)
    except Exception as e:
        logger.error("Failed to initialize backend session: %s", e)

    options = {"oems": [], "projects": [], "processes": []}
    try:
        import httpx
        async with httpx.AsyncClient(timeout=_HTTP_TIMEOUT) as client:
            opt_response = await client.get(f"{BACKEND_URL}/trigger-options")
            opt_response.raise_for_status()
            options = opt_response.json()
            cl.user_session.set("trigger_options", options)
    except Exception as e:
        logger.error("Failed to load context switch options: %s", e)
        cl.user_session.set("trigger_options", options)

    # Build initial options with NO DEFAULT ("— Select ... —")
    oems_list = options.get("oems", [])
    oem_items = {"— Select OEM —": ""}
    for oem in oems_list:
        oem_items[oem["name"]] = oem["name"]

    project_items = {"— Select Project —": ""}
    process_items = {"— Select Process —": ""}

    # Save initial selections in session as None
    cl.user_session.set("selected_oem", None)
    cl.user_session.set("selected_project", None)
    cl.user_session.set("selected_process", None)

    # Send ChatSettings
    from chainlit.input_widget import Select
    await cl.ChatSettings([
        Select(
            id="oem_select",
            label="Select OEM",
            items=oem_items,
            initial_value=""
        ),
        Select(
            id="project_select",
            label="Select Project",
            items=project_items,
            initial_value=""
        ),
        Select(
            id="process_select",
            label="Select Process",
            items=process_items,
            initial_value=""
        )
    ]).send()"""

    content = re.sub(r'@cl.on_chat_start\nasync def start\(\):.*?(?=@cl.on_window_message)', new_start_func + "\n\n", content, flags=re.DOTALL)


    # 2. Clarification buttons rewrite
    new_render_clarification = """async def render_clarification_buttons(response):
    missing = response.get("missing", "context")
    options = response.get("clarification_options", [])
    session_id = cl.user_session.get("session_id")
    
    actions = []
    
    for option in options:
        label = option.get("label")
        val = option.get("value")
        opt_type = option.get("type")
        
        actions.append(
            cl.Action(
                name="clarification_select",
                payload={
                    "type": opt_type,
                    "value": val,
                    "session_id": session_id
                },
                label=label
            )
        )
        
    if actions:
        await cl.Message(
            content=f"Which {missing} would you like to select?",
            actions=actions
        ).send()
    else:
        await cl.Message(content=f"💬 {response.get('message', 'I need more context.')}").send()"""

    content = re.sub(r'async def render_clarification_buttons\(response\):.*?(?=@cl\.action_callback|"feedback"|async def send_with_feedback)', new_render_clarification + "\n\n", content, flags=re.DOTALL)


    # 3. Add context_update to render_backend_response
    context_update_code = """
    # --------------------------------------------------
    # CONTEXT UPDATE
    # --------------------------------------------------
    if intent == "context_update":
        await cl.Message(content=f"⚙️ {data}").send()
        return
"""

    content = content.replace('    if status == "success":', '    if status == "success":\n' + context_update_code)


    # 4. Replace @cl.on_settings_edit and @cl.on_settings_update with just @cl.on_settings_update
    new_settings_update = """@cl.on_settings_update
async def on_settings_update(settings: dict):
    options = cl.user_session.get("trigger_options") or {"oems": [], "projects": [], "processes": []}
    
    selected_oem = settings.get("oem_select")
    selected_project = settings.get("project_select")
    selected_process = settings.get("process_select")
    
    prev_oem = cl.user_session.get("selected_oem")
    prev_project = cl.user_session.get("selected_project")
    
    oems_list = options.get("oems", [])
    projects_list = options.get("projects", [])
    processes_list = options.get("processes", [])
    
    oem_items = {"— Select OEM —": ""}
    for o in oems_list:
        oem_items[o["name"]] = o["name"]

    oem_changed = (selected_oem != prev_oem)
    project_changed = (selected_project != prev_project)
    
    if oem_changed:
        selected_project = ""
        selected_process = ""
        
    if project_changed:
        selected_process = ""
        
    # Rebuild project items based on selected OEM
    project_items = {"— Select Project —": ""}
    if selected_oem:
        oem_id = next((o["id"] for o in oems_list if o["name"] == selected_oem), None)
        for p in projects_list:
            if p["oem_id"] == oem_id:
                project_items[p["project_name"]] = p["project_key"]
                
    # Rebuild process items based on selected project
    process_items = {"— Select Process —": ""}
    if selected_project:
        project_id = next((p["id"] for p in projects_list if p["project_key"] == selected_project), None)
        for pr in processes_list:
            if pr["project_id"] == project_id:
                process_items[pr["process_name"]] = pr["process_name"]
                
    # Save current selections
    cl.user_session.set("selected_oem", selected_oem)
    cl.user_session.set("selected_project", selected_project)
    cl.user_session.set("selected_process", selected_process)
    
    # Sync context to backend if session exists
    session_id = cl.user_session.get("session_id")
    if session_id:
        if oem_changed and selected_oem:
            await send_to_backend(session_id, f"__select_oem__={selected_oem}")
        if project_changed and selected_project:
            await send_to_backend(session_id, f"__select_project__={selected_project}")
        if (selected_process != cl.user_session.get("selected_process")) and selected_process:
            await send_to_backend(session_id, f"__select_process__={selected_process}")
            
    # Send updated settings panel
    from chainlit.input_widget import Select
    try:
        settings_msg = cl.ChatSettings([
            Select(id="oem_select", label="Select OEM", items=oem_items, initial_value=selected_oem or ""),
            Select(id="project_select", label="Select Project", items=project_items, initial_value=selected_project or ""),
            Select(id="process_select", label="Select Process", items=process_items, initial_value=selected_process or "")
        ])
        if hasattr(settings_msg, 'send'):
            await settings_msg.send()
        else:
            await settings_msg.update()
    except Exception as e:
        logger.error("Failed to update settings panel: %s", e)"""

    content = re.sub(r'@cl\.on_settings_edit\nasync def on_settings_edit\(settings: dict\):.*?(?=@cl\.on_settings_update)', '', content, flags=re.DOTALL)
    content = re.sub(r'@cl\.on_settings_update\nasync def on_settings_update\(settings: dict\):.*?(?=$)', new_settings_update + "\n\n", content, flags=re.DOTALL)


    with open('/Users/harnish/Documents/AIDA/frontend/chainlit_app.py', 'w') as f:
        f.write(content)
        
    print("Success")
except Exception as e:
    print(f"Error: {e}")
    sys.exit(1)
