import os
import chainlit as cl
import httpx
import websockets
import asyncio
import json
import logging
import pprint

# ui_renderer.py is kept as an archived reference template but is not used
# at runtime — all rendering is handled inline in this file.

logger = logging.getLogger("exchange_engine")
logger.setLevel(logging.INFO)
if not logger.handlers:
    _handler = logging.StreamHandler()
    _handler.setLevel(logging.INFO)
    _handler.setFormatter(logging.Formatter(
        "%(asctime)s | %(levelname)s | [%(name)s] | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S"
    ))
    logger.addHandler(_handler)

BACKEND_URL = os.getenv("AIDA_BACKEND_URL", "http://localhost:8080")
WS_URL = os.getenv("AIDA_WS_URL", "ws://localhost:8080")

_HTTP_TIMEOUT = httpx.Timeout(120.0, connect=10.0)


from chainlit.data import BaseDataLayer
from typing import Optional, List, Dict
import uuid

from utils.backend_client import backend_client
from http.cookies import SimpleCookie

# from app.userSession.service import UserSessionService

# user_session_service = UserSessionService()

class CustomDataLayer(BaseDataLayer):
    async def get_user(self, identifier: str):
        return None

    async def create_user(self, user):
        return None

    async def delete_feedback(self, feedback_id: str) -> bool:
        return True

    async def upsert_feedback(self, feedback) -> str:
        session_id = feedback.threadId
        feedback_type = "like" if feedback.value == 1 else "dislike"
        comment = feedback.comment or ""
        
        try:
            async with backend_client() as client:
                await client.post(
                    f"{BACKEND_URL}/feedback",
                    json={
                        "session_id": session_id,
                        "feedback": feedback_type,
                        "comment": comment
                    }
                )
        except Exception as exc:
            logger.warning("Feedback submission failed: %s", exc)
            
        return getattr(feedback, "id", None) or str(uuid.uuid4())

    async def create_element(self, element):
        pass

    async def get_element(self, thread_id: str, element_id: str):
        return None

    async def delete_element(self, element_id: str, thread_id: Optional[str] = None):
        pass

    async def create_step(self, step_dict):
        pass

    async def update_step(self, step_dict):
        pass

    async def delete_step(self, step_id: str):
        pass

    async def get_thread_author(self, thread_id: str) -> str:
        return ""

    async def delete_thread(self, thread_id: str):
        pass

    async def list_threads(self, pagination, filters):
        return {"data": [], "pageInfo": {"hasNextPage": False, "endCursor": ""}}

    async def get_thread(self, thread_id: str):
        return None

    async def update_thread(self, thread_id: str, name: Optional[str] = None, user_id: Optional[str] = None, metadata: Optional[Dict] = None, tags: Optional[List[str]] = None):
        pass

    async def build_debug_url(self) -> str:
        return ""

    async def close(self) -> None:
        pass

    async def get_favorite_steps(self, user_id: str):
        return []

# Register custom data layer
import chainlit.data as cl_data
cl_data._data_layer = CustomDataLayer()


async def send_to_backend(session_id: str, query: str):
    oem = cl.user_session.get("selected_oem")
    project = cl.user_session.get("selected_project")
    process = cl.user_session.get("selected_process")
    # Use the browser-reported IANA timezone (set via JS on_chat_start),
    # falling back to UTC if the browser hasn't reported yet.
    timezone = cl.user_session.get("timezone") or "UTC"
    history = cl.user_session.get("chat_history", [])
    
    payload = {
        "session_id": session_id,
        "query": query,
        "oem": oem,
        "project_key": project,
        "process_name": process,
        "timezone": timezone,
        "history": history[-20:] # Keep last 20 messages to avoid massive payloads
    }
    
    async with backend_client() as client:
        response = await client.post(
            f"{BACKEND_URL}/agent/chat",
            json=payload
        )
        data = response.json()
        
        # Append to session history (in-memory per session)
        if query.strip() and not query.startswith("__select"):
            history.append({"role": "user", "content": query})
        if data.get("status") == "success" and data.get("data"):
            history.append({"role": "ai", "content": str(data.get("data"))})
            
        cl.user_session.set("chat_history", history)
        
        return data



async def load_user_profile():

    profile = None
    try:
        async with backend_client() as client:

            response = await client.get(
                f"{BACKEND_URL}/user/profile"
            )
            response.raise_for_status()

            profile = response.json()

            cl.user_session.set(
                "profile",
                profile,
            )

            logger.info(
                "Loaded user profile for %s",
                profile["email"],
            )

    except Exception as e:

        logger.warning(
            "Failed to load user profile: %s",
            e,
        )

    return profile



@cl.set_starters
async def set_starters():
    return [
        cl.Starter(
            label="Check Exchange Schedule",
            message="Can you provide me the schedule timings",
            icon="https://img.icons8.com/color/96/clock.png",
        ),
        cl.Starter(
            label="Recent Failures",
            message="What are the latest failed items for the last 24 hours?",
            icon="https://img.icons8.com/color/96/high-importance.png",
        ),
        cl.Starter(
            label="Query Check",
            message="Check the current Filter query used in the process",
            icon="https://img.icons8.com/color/96/help.png",
        ),
        cl.Starter(
            label="Trigger Sync",
            message="Trigger Sync",
            icon="https://img.icons8.com/color/96/rocket.png",
        ),
        cl.Starter(
            label="Check Mappings",
            message="Can you please provide the mapping schema?",
            icon="https://img.icons8.com/color/96/mind-map.png",
        ),
        cl.Starter(
            label="Check Configurations",
            message="Is attachment sync enabled?",
            icon="https://img.icons8.com/fluency/96/settings.png",
        ),
        cl.Starter(
            label="Defect History",
            message="Check sync history for defect ID",
            icon="https://img.icons8.com/color/96/time-span.png",
        )
    ]


@cl.on_chat_start
async def start():
    cl.user_session.set("session_id", None)
    cl.user_session.set("chat_history", [])

    raw_cookie = cl.context.session.environ.get("HTTP_COOKIE")

    if raw_cookie:
        cookie = SimpleCookie()
        cookie.load(raw_cookie)

        if "AIDA_SESSION" in cookie:
            session_cookie = cookie["AIDA_SESSION"].value
            cl.user_session.set("aida_session_cookie", session_cookie)

            logger.info(
                "Authenticated AIDA session detected: %s",
                session_cookie
            )
    
    # Client-side timezone detection is handled automatically by public/test.js postMessage on page mount
    
    # Eager session creation
    try:
        import httpx
        async with httpx.AsyncClient(timeout=_HTTP_TIMEOUT) as client:
            thread_id = cl.context.session.thread_id
            res = await client.get(f"{BACKEND_URL}/create-session?session_id={thread_id}")
            session_data = res.json()
            session_id = session_data["session_id"]
            cl.user_session.set("session_id", session_id)
    except Exception as e:
        logger.error("Failed to initialize backend session: %s", e)

    options = {"oems": [], "projects": [], "processes": []}
    try:
        # async with httpx.AsyncClient(timeout=_HTTP_TIMEOUT) as client:
        async with backend_client() as client:
            trigger_task = client.get(f"{BACKEND_URL}/trigger-options")
            profile_task = client.get(f"{BACKEND_URL}/user/profile")
            logger.info(
                "AIDA Cookie in Chainlit: %s",
                cl.user_session.get("aida_session_cookie")
            )
            opt_response, profile_response = await asyncio.gather(trigger_task, profile_task)
            opt_response.raise_for_status()
            options = opt_response.json()
            cl.user_session.set("trigger_options", options)

            profile_response.raise_for_status()
            profile = profile_response.json()
            cl.user_session.set("profile", profile)
            logger.info("Loaded user profile for %s", profile["email"])
    except Exception as e:
        logger.error("Failed to load context switch options: %s", e)
        cl.user_session.set("trigger_options", options)

    # Build initial options with NO DEFAULT ("Select ...")
    oems_list = options.get("oems", [])
    oem_items = {"Select OEM": "Select OEM"}
    for oem in oems_list:
        oem_items[oem["name"]] = oem["name"]

    project_items = {"Select Project": "Select Project"}
    process_items = {"Select Process": "Select Process"}

    # Save initial selections in session as None
    cl.user_session.set("selected_oem", None)
    cl.user_session.set("selected_project", None)
    cl.user_session.set("selected_process", None)

    # Send ChatSettings
    from chainlit.input_widget import Select
    try:
        await cl.ChatSettings([
            Select(
                id="oem_select",
                label="Select OEM",
                items=oem_items,
                initial_value="Select OEM"
            ),
            Select(
                id="project_select",
                label="Select Project",
                items=project_items,
                initial_value="Select Project"
            ),
            Select(
                id="process_select",
                label="Select Process",
                items=process_items,
                initial_value="Select Process"
            )
        ]).send()

        
    except Exception as e:
        logger.error(f"Failed to send ChatSettings: {e}")



@cl.on_window_message
async def handle_window_message(payload):
    if isinstance(payload, str):
        try:
            payload = json.loads(payload)
        except Exception:
            pass
    if isinstance(payload, dict):
        if payload.get("type") == "timezone":
            tz = payload.get("timezone")
            cl.user_session.set("timezone", tz)
            logger.info("Received client timezone: %s", tz)

@cl.on_message
async def handle_message(message: cl.Message):

    # Check if user explicitly wants the console panel options back
    if message.content.strip().lower() in ["/menu", "menu", "help"]:
        await cl.Message(
            content="Here are your quick-access console actions:",
            actions=[
                cl.Action(name="menu_schedule", payload={}, label="⏱️ Check Schedule"),
                cl.Action(name="menu_failures", payload={}, label="❌ Recent Failures"),
                cl.Action(name="menu_query", payload={}, label="⚙️ Query Check"),
                cl.Action(name="menu_trigger_sync", payload={}, label="🚀 Trigger Sync"),
                cl.Action(name="menu_mappings", payload={}, label="🗺️ Check Mappings"),
                cl.Action(name="menu_configs", payload={}, label="🛠️ Check Configs"),
                cl.Action(name="menu_history", payload={}, label="📜 Defect History")
            ]
        ).send()
        return

    session_id = cl.user_session.get("session_id")
    if not session_id:
        try:
            async with httpx.AsyncClient(timeout=_HTTP_TIMEOUT) as client:
                res = await client.get(f"{BACKEND_URL}/create-session")
                session_data = res.json()
                session_id = session_data["session_id"]
                cl.user_session.set("session_id", session_id)
            
            # Sync initial settings to backend
            oem = cl.user_session.get("selected_oem")
            project = cl.user_session.get("selected_project")
            process = cl.user_session.get("selected_process")
            
            if oem and oem != "N/A":
                await send_to_backend(session_id, f"__select_oem__={oem}")
            if project and project != "N/A":
                await send_to_backend(session_id, f"__select_project__={project}")
            if process and process != "N/A":
                await send_to_backend(session_id, f"__select_process__={process}")
        except Exception as e:
            logger.error("Failed to initialize backend session and sync settings: %s", e)

    # Save the user's query so clarification handlers can re-send it
    cl.user_session.set("last_user_query", message.content.strip())
    
    response = await send_to_backend(session_id, message.content)

    if response.get("session_id"):
        cl.user_session.set("session_id", response["session_id"])

    # Handle clarification separately
    if response.get("status") == "clarification_required":
        await render_clarification_buttons(response)
        return

    await render_backend_response(response)


async def render_clarification_buttons(response):
    missing = response.get("missing", "context")
    options = response.get("clarification_options", [])
    session_id = cl.user_session.get("session_id")
    
    actions = []
    
    for option in options:
        label = option.get("label")
        val = option.get("value")
        opt_type = option.get("type")
        
        actions.append(
            cl.Action(
                name="clarification_select",
                payload={
                    "type": opt_type,
                    "value": val,
                    "session_id": session_id
                },
                label=label
            )
        )
        
    if actions:
        await cl.Message(
            content=f"Which {missing} would you like to select?",
            actions=actions
        ).send()
    else:
        await cl.Message(content=f"💬 {response.get('message', 'I need more context.')}").send()

async def send_with_feedback(content: str):
    await cl.Message(
        content=content,
    ).send()


async def render_backend_response(response: dict):

    status = response.get("status")
    intent = response.get("intent")
    data = response.get("data", {})


    # --------------------------------------------------
    # CLARIFICATION
    # --------------------------------------------------
    if status == "clarification_required":
        await render_clarification_buttons(response)
        return

    # --------------------------------------------------
    # SUCCESS
    # --------------------------------------------------
    if status == "success":

        # --------------------------------------------------
        # CONTEXT UPDATE
        # --------------------------------------------------
        if intent == "context_update":
            await cl.Message(content=f"⚙️ {data}").send()
            return

        # ==========================
        # AI / LLM SYNTHESIZED RESPONSES
        # ==========================
        # In the new architecture, the LLM beautifully formats all tool responses directly.
        if intent in [
            "schedule_query",
            "failure_summary_query",
            "top_failures_query",
            "config_query",
            "filter_query",
            "mapping_query",
            "mapping_value_query",
            "mapping_list_query",
            "defect_history_query",
            "trigger_sync",
            "transform_previous",
            "ai",
        ]:
            content = data if isinstance(data, str) else str(data)
            await send_with_feedback(content)
            
            # For trigger_sync, the backend passes the job_id as a
            # dedicated field extracted from the raw tool result so we
            # don't have to regex-parse the LLM's reformatted prose.
            if intent == "trigger_sync":
                job_id = response.get("job_id")
                if job_id:
                    logger.info("Trigger Sync detected Job ID: %s. Awaiting WS listener.", job_id)
                    await listen(job_id)
            return

        # ==========================
        # FALLBACK SUCCESS (unknown intent with data)
        # ==========================
        await send_with_feedback(
            "Here is what I found, though I'm not sure how to format it nicely yet:\n\n"
            + _friendly_data_summary(data)
        )
        return

    # --------------------------------------------------
    # NOT FOUND
    # --------------------------------------------------
    if status == "not_found":
        # message lives at the top-level response, not inside data
        msg = response.get("message", data.get("message", "No data found."))
        await send_with_feedback(f"⚠️ {msg}")
        return

    # --------------------------------------------------
    # UNKNOWN INTENT — surface the backend's follow-up suggestion
    # --------------------------------------------------
    if status == "unknown_intent":
        follow_up = response.get("message") or "Could you rephrase your request?"
        await send_with_feedback(
            f"🤔 I'm not sure I understood that.\n\n💡 *{follow_up}*"
        )
        return

    # --------------------------------------------------
    # ERROR
    # --------------------------------------------------
    if status == "error":
        # message lives at the top-level response, not inside data
        msg = response.get("message", data.get("message", "An unexpected error occurred."))
        await send_with_feedback(f"❌ {msg}")
        return

    # --------------------------------------------------
    # FINAL FALLBACK
    # --------------------------------------------------
    await send_with_feedback(
        "⚠️ Something unexpected happened on my end. Please try rephrasing your question."
    )


def _friendly_data_summary(data) -> str:
    """Convert arbitrary data into a readable text block for the fallback case."""
    if isinstance(data, str):
        return data
    if isinstance(data, dict):
        lines = []
        for key, value in data.items():
            if key in ("status", "session_id"):
                continue
            lines.append(f"**{key.replace('_', ' ').title()}:** {value}")
        return "\n".join(lines) if lines else "No details available."
    return str(data)


@cl.action_callback("clarification_select")
async def handle_clarification_selection(action: cl.Action):

    selection_type = action.payload["type"]
    value = action.payload["value"]
    session_id = action.payload["session_id"]

    if selection_type == "oem":
        cl.user_session.set("selected_oem", value)
        query = f"__select_oem__={value}"
    elif selection_type == "project":
        cl.user_session.set("selected_project", value)
        query = f"__select_project__={value}"
    elif selection_type == "process":
        cl.user_session.set("selected_process", value)
        query = f"__select_process__={value}"
    else:
        return

    # 1. Send the context update
    response = await send_to_backend(session_id, query)
    if response.get("session_id"):
        cl.user_session.set("session_id", response["session_id"])
    await render_backend_response(response)

    # 2. Automatically re-send the original user query so the agent
    #    continues the flow (asks for project after OEM, etc.)
    last_user_query = cl.user_session.get("last_user_query")
    if last_user_query:
        logger.info(f"🔁 [CLARIFICATION] Re-sending original query: '{last_user_query}'")
        follow_up = await send_to_backend(session_id, last_user_query)
        if follow_up.get("session_id"):
            cl.user_session.set("session_id", follow_up["session_id"])
        
        # Handle the follow-up (might be another clarification or the final answer)
        if follow_up.get("status") == "clarification_required":
            await render_clarification_buttons(follow_up)
        else:
            await render_backend_response(follow_up)


@cl.action_callback("menu_trigger_sync")
async def handle_menu_trigger_sync(action: cl.Action):
    msg = cl.Message(content="I want to trigger sync")
    await handle_message(msg)


async def listen(job_id):
    message = cl.Message(content="📡 Connecting to live sync updates...")
    await message.send()

    try:
        async with websockets.connect(f"{WS_URL}/ws/{job_id}") as ws:
            async for payload in ws:
                data = json.loads(payload)

                try:
                    progress_val = float(data.get("progress", 0))
                except (ValueError, TypeError):
                    progress_val = 0.0

                status = data.get("status", "RUNNING")
                
                # Fetch process details safely (can be dict or string)
                process_data = data.get("process")
                process_name_display = "N/A"
                if isinstance(process_data, dict):
                    process_name_display = process_data.get("process_name") or process_data.get("name") or "N/A"
                elif isinstance(process_data, str):
                    process_name_display = process_data

                # Build a markdown progress bar
                bars_filled = int(progress_val // 2.5)
                bars_empty = 40 - bars_filled
                progress_bar = "█" * bars_filled + "░" * bars_empty

                message.content = f"""
**🚀 Sync Job:** `{job_id}`
**Process:** {process_name_display} | **Config Set:** {data.get('configset', 'N/A')}

**Status:** `{status}` ({progress_val}%)
`{progress_bar}`

📊 **Tasks:** **{data.get('total', 0)}** Total | ✅ **{data.get('succeeded', 0)}** Succeeded | ❌ **{data.get('failed', 0)}** Failed
"""
                await message.update()

                if status == "COMPLETED":
                    await cl.Message(content="🎉 Exchange process finished successfully!").send()
                    break
                elif status == "FAILED":
                    await cl.Message(content="❌ Exchange process failed. Please check the logs for details.").send()
                    break

    except Exception as e:
        logger.error("websocket listen error job_id=%s: %s", job_id, e)
        message.content = f"❌ **WebSocket Connection Error:** {str(e)}"
        await message.update()


# Attach this button to your chat start or starters as needed
# async def prompt_trigger_action():
#     await cl.Message(
#         content="Ready to trigger a new process?",
#         actions=[
#             cl.Action(
#                 name="trigger_process_form",
#                 payload={"action": "start"},
#                 label="🚀 Open Trigger Form"
#             )
#         ]
#     ).send()


@cl.action_callback("menu_schedule")
async def handle_menu_schedule(action: cl.Action):
    msg = cl.Message(content="Can you provide me the schedule timings")
    await handle_message(msg)


@cl.action_callback("menu_failures")
async def handle_menu_failures(action: cl.Action):
    msg = cl.Message(content="What are the recent failures for the last 24 hours?")
    await handle_message(msg)


@cl.action_callback("menu_query")
async def handle_menu_query(action: cl.Action):
    msg = cl.Message(content="Check the current Filter query used in the process")
    await handle_message(msg)


@cl.action_callback("menu_mappings")
async def handle_menu_mappings(action: cl.Action):
    msg = cl.Message(content="Can you please provide the mapping schema?")
    await handle_message(msg)


@cl.action_callback("menu_configs")
async def handle_menu_configs(action: cl.Action):
    msg = cl.Message(content="Is attachment sync enabled?")
    await handle_message(msg)


@cl.action_callback("menu_history")
async def handle_menu_history(action: cl.Action):
    msg = cl.Message(content="Check sync history for defect ID")
    await handle_message(msg)


@cl.on_settings_edit
async def on_settings_edit(settings: dict):
    """Fires dynamically in real-time as the user toggles drop-downs."""
    options = cl.user_session.get("trigger_options") or {"oems": [], "projects": [], "processes": []}
    
    selected_oem = settings.get("oem_select") or "Select OEM"
    selected_project = settings.get("project_select") or "Select Project"
    selected_process = settings.get("process_select") or "Select Process"
    
    prev_oem = cl.user_session.get("selected_oem")
    prev_project = cl.user_session.get("selected_project")
    
    oems_list = options.get("oems", [])
    projects_list = options.get("projects", [])
    processes_list = options.get("processes", [])
    
    # 1. Standardize OEM generation map
    oem_items = {"Select OEM": "Select OEM"}
    for o in oems_list:
        name = o.get("name")
        if name:
            oem_items[name] = name

    # 2. Reset cascade states instantly when a parent tier alters
    if selected_oem != prev_oem:
        selected_project = "Select Project"
        selected_process = "Select Process"
    elif selected_project != prev_project:
        selected_process = "Select Process"
        
    # 3. Filter and build Project Items strictly tracking integer IDs
    project_items = {"Select Project": "Select Project"}
    oem_id = None
    if selected_oem and selected_oem != "Select OEM":
        oem_id = next((o["id"] for o in oems_list if o.get("name") == selected_oem), None)
        if oem_id is not None:
            for p in projects_list:
                if p.get("oem_id") == oem_id:
                    label = p.get("project_name") or p.get("project_key") or "Unknown"
                    project_items[label] = p.get("project_key")

    # 4. Filter and build Process Items
    process_items = {"Select Process": "Select Process"}
    project_id = None
    if selected_project and selected_project != "Select Project":
        project_id = next((p["id"] for p in projects_list if p.get("project_key") == selected_project), None)
        if project_id is not None:
            for pr in processes_list:
                if pr.get("project_id") == project_id:
                    label = pr.get("process_name") or "Unknown"
                    process_items[label] = pr.get("process_name")
                
    # Save selection state cache to the active runtime memory session
    cl.user_session.set("selected_oem", selected_oem)
    cl.user_session.set("selected_project", selected_project)
    cl.user_session.set("selected_process", selected_process)
    
    # Re-render UI inputs instantly via refresh()
    from chainlit.input_widget import Select
    await cl.ChatSettings([
        Select(id="oem_select", label="Select OEM", items=oem_items, initial_value=selected_oem),
        Select(id="project_select", label="Select Project", items=project_items, initial_value=selected_project),
        Select(id="process_select", label="Select Process", items=process_items, initial_value=selected_process)
    ]).refresh()

@cl.on_settings_update
async def on_settings_update(settings: dict):
    """Fires ONLY when the settings panel modal is closed/submitted."""
    session_id = cl.user_session.get("session_id")
    if not session_id:
        return
        
    oem = cl.user_session.get("selected_oem")
    project = cl.user_session.get("selected_project")
    process = cl.user_session.get("selected_process")
    
    # Clear stale chat history when context changes to prevent
    # the LLM from hallucinating with old project/process names
    cl.user_session.set("chat_history", [])
    logger.info("🧹 [CONTEXT SWITCH] Cleared chat history to prevent stale context leakage")
    
    # Sync contexts over network to core LangGraph architecture agent endpoints
    if oem and oem != "Select OEM":
        await send_to_backend(session_id, f"__select_oem__={oem}")
    if project and project != "Select Project":
        await send_to_backend(session_id, f"__select_project__={project}")
    if process and process != "Select Process":
        await send_to_backend(session_id, f"__select_process__={process}")
        
    await cl.Message(content=f"🔄 **Context Contextualized:** `{oem}` ➔ `{project}` ➔ `{process}`").send()

