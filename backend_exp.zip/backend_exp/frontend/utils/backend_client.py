import httpx
import chainlit as cl
from contextlib import asynccontextmanager
import os

BACKEND_URL = os.getenv("AIDA_BACKEND_URL", "http://localhost:8080")

HTTP_TIMEOUT = httpx.Timeout(
    timeout=120.0,
    connect=10.0
)


@asynccontextmanager
async def backend_client():
    """
    Returns an AsyncClient that automatically forwards
    the authenticated AIDA_SESSION cookie.
    """

    session_cookie = cl.user_session.get("aida_session_cookie")

    cookies = {}

    if session_cookie:
        cookies["AIDA_SESSION"] = session_cookie

    async with httpx.AsyncClient(
        timeout=HTTP_TIMEOUT,
        cookies=cookies
    ) as client:

        yield client