CREATE TABLE exchange_history (
    id BIGSERIAL PRIMARY KEY,

    process_id INT NOT NULL
    REFERENCES processes(id),

    execution_time TIMESTAMP,

    status VARCHAR(50),

    total_items INT,

    success_items INT,

    failed_items INT,

    failure_reason TEXT
);


CREATE INDEX idx_history_process
ON exchange_history(process_id);

CREATE INDEX idx_history_execution
ON exchange_history(execution_time DESC);


ALTER TABLE sessions
ADD COLUMN selected_oem VARCHAR(100);

ALTER TABLE sessions
ADD COLUMN selected_project VARCHAR(100);

ALTER TABLE sessions
ADD COLUMN selected_process VARCHAR(255);

ALTER TABLE sessions
ADD COLUMN conversation_state VARCHAR(100);



CREATE TABLE intent_examples (

    id SERIAL PRIMARY KEY,

    intent VARCHAR(100),

    example_query TEXT
);





-- ################
--------------------


select * from processes;


CREATE TABLE IF NOT EXISTS exchange_history (

    id BIGSERIAL PRIMARY KEY,

    process_id INT NOT NULL
    REFERENCES processes(id)
    ON DELETE CASCADE,

    execution_time TIMESTAMP,

    status VARCHAR(50),

    total_items INT DEFAULT 0,

    success_items INT DEFAULT 0,

    failed_items INT DEFAULT 0,

    failure_reason TEXT,

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


CREATE INDEX IF NOT EXISTS idx_history_process
ON exchange_history(process_id);

CREATE INDEX IF NOT EXISTS idx_history_execution
ON exchange_history(execution_time DESC);


ALTER TABLE sessions
ADD COLUMN pending_intent TEXT;

ALTER TABLE sessions
ADD COLUMN last_query TEXT;

ALTER TABLE sessions
ADD COLUMN IF NOT EXISTS conversation_state VARCHAR(100);

ALTER TABLE sessions
ADD COLUMN IF NOT EXISTS selected_oem VARCHAR(100);

ALTER TABLE sessions
ADD COLUMN IF NOT EXISTS selected_project VARCHAR(100);

ALTER TABLE sessions
ADD COLUMN IF NOT EXISTS selected_process VARCHAR(255);


CREATE TABLE IF NOT EXISTS intent_examples (

    id SERIAL PRIMARY KEY,

    intent VARCHAR(100) NOT NULL,

    example_query TEXT NOT NULL,

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_attr_source_destination
ON attribute_mappings(source_field, destination_field);

CREATE INDEX IF NOT EXISTS idx_config_process_key
ON config_entries(process_id, config_key);