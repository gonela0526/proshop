from dataclasses import dataclass


@dataclass
class ToolContext:

    project_key: str

    process_name: str

    session_id: str = None