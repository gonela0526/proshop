from pydantic import BaseModel

class ToolResponse(BaseModel):
    module: str
    success: bool
    message: str
    data: dict
    suggestions: list[str]