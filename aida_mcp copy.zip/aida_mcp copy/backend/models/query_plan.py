from pydantic import BaseModel
from typing import Dict


class QueryPlan(BaseModel):

    intent: str

    field_name: str | None = None
    tool_name: str | None = None
    config_key: str | None = None