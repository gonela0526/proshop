from pydantic import BaseModel

class ExchangeContext(BaseModel):
    oem: str
    project_key: str
    process_name: str