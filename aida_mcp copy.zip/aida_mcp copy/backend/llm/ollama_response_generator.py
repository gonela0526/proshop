from llm.ollama_client import OllamaClient
from llm.response_prompt import RESPONSE_PROMPT


class OllamaResponseGenerator:

    @staticmethod
    def generate(
            query,
            tool_response):

        prompt = RESPONSE_PROMPT

        prompt = prompt.replace(
            "{query}",
            query
        )

        prompt = prompt.replace(
            "{tool_response}",
            str(tool_response)
        )

        return OllamaClient.generate(
            prompt
        )