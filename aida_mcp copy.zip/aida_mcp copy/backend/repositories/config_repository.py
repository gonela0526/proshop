# repositories/config_repository.py

from database.postgres import db


class ConfigRepository:

    def get_config_value(
            self,
            project_key: str,
            process_name: str
        ):

        print(f"Fetching config for project: {project_key}, process: {process_name}")

        sql = """
        SELECT
            ce.config_key,
            ce.config_value

        FROM config_entries ce

        JOIN processes p
            ON p.id = ce.process_id

        JOIN projects pr
            ON pr.id = p.project_id

        WHERE pr.project_key = %s
        AND p.process_name = %s
        """

        result = db.execute_query(
            sql,
            (
                project_key,
                process_name
            )
        )

        return result