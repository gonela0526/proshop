from database.postgres import db

class MappingRepository:

    def get_attribute_mapping(
            self,
            project_key: str,
            process_name: str,
            source_field: str):

        sql = """
        SELECT
            am.source_field,
            am.destination_field
        FROM attribute_mappings am
        JOIN mapping_scenarios ms
            ON ms.id = am.scenario_id

        JOIN processes p
            ON p.id = ms.process_id

        JOIN projects pr
            ON pr.id = p.project_id

        WHERE pr.project_key = %s
        AND p.process_name = %s
        AND LOWER(am.source_field)=LOWER(%s)
        """

        result = db.execute_query(
            sql,
            (
                project_key,
                process_name,
                source_field
            )
        )

        return result