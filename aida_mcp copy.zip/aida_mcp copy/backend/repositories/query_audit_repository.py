from database.postgres import db


class QueryAuditRepository:

    def save_audit(
            self,
            session_id,
            query,
            detected_intent,
            execution_path,
            status,
            processing_time):

        sql = """
        INSERT INTO query_audit
        (
            session_id,
            query,
            detected_intent,
            execution_path,
            status,
            processing_time
        )
        VALUES
        (
            %s,%s,%s,%s,%s,%s
        )
        """

        db.execute_update(
            sql,
            (
                session_id,
                query,
                detected_intent,
                execution_path,
                status,
                processing_time
            )
        )