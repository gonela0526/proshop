from database.postgres import db

class ScheduleRepository:

    def get_schedule(
            self,
            project_key,
            process_name):

        sql = """
        SELECT
            p.process_name,
            p.schedule,
            p.instance,
            p.java_process_name,
            p.configset_name

        FROM processes p

        JOIN projects pr
            ON pr.id = p.project_id

        WHERE pr.project_key = %s
        AND p.process_name = %s
        """

        return db.execute_query(
            sql,
            (
                project_key,
                process_name
            )
        )