from database.postgres import db


class SessionRepository:

    def get_session(
            self,
            session_id):

        sql = """
        SELECT
            id,
            project_key,
            process_name
        FROM sessions
        WHERE id = %s
        """

        result = db.execute_query(
            sql,
            (session_id,)
        )

        return result

    def save_session(
            self,
            session_id,
            project_key,
            process_name):

        sql = """
        INSERT INTO sessions
        (
            id,
            project_key,
            process_name
        )
        VALUES
        (
            %s,%s,%s
        )
        ON CONFLICT (id)
        DO UPDATE SET

        project_key = EXCLUDED.project_key,
        process_name = EXCLUDED.process_name,
        updated_at = CURRENT_TIMESTAMP
        """

        db.execute_update(
            sql,
            (
                session_id,
                project_key,
                process_name
            )
        )