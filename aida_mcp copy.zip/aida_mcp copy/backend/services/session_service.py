from repositories.session_repository import (
    SessionRepository
)


class SessionService:

    def __init__(self):

        self.repo = SessionRepository()

    def get_context(
            self,
            session_id):

        result = self.repo.get_session(
            session_id
        )

        if not result:
            return None

        return result[0]

    def save_context(
            self,
            session_id,
            project_key,
            process_name):

        self.repo.save_session(
            session_id,
            project_key,
            process_name
        )