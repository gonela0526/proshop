from repositories.mapping_repository import MappingRepository
from models.tool_response import ToolResponse

class MappingService:

    def __init__(self):
        self.repo = MappingRepository()

    def get_field_mapping(
            self,
            project_key,
            process_name,
            field_name):

        result = self.repo.get_attribute_mapping(
            project_key,
            process_name,
            field_name
        )

        if not result:
            return ToolResponse(
                module="mapping",
                success=False,
                message=f"No mapping found for {field_name}",
                data={},
                suggestions=[
                    "Show all mappings",
                    "Check another field"
                ]
            )

        mapping = result[0]

        return ToolResponse(
            module="mapping",
            success=True,
            message="Mapping found",
            data={
                "source_field":
                    mapping["source_field"],
                "destination_field":
                    mapping["destination_field"]
            },
            suggestions=[
                "Show value mappings",
                "Show all mappings"
            ]
        )