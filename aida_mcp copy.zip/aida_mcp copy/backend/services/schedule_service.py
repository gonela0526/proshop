from repositories.schedule_repository import (
    ScheduleRepository
)

from models.tool_response import (
    ToolResponse
)


class ScheduleService:

    def __init__(self):

        self.repo = ScheduleRepository()

    def get_schedule(
            self,
            project_key,
            process_name):

        result = self.repo.get_schedule(
            project_key,
            process_name
        )

        if not result:

            return ToolResponse(
                module="schedule",
                success=False,
                message="Schedule not found",
                data={},
                suggestions=[]
            )

        schedule = result[0]

        return ToolResponse(
            module="schedule",
            success=True,
            message="Schedule found",
            data={
                "process_name":
                    schedule["process_name"],

                "schedule":
                    schedule["schedule"],

                "instance":
                    schedule["instance"],

                "java_process_name":
                    schedule["java_process_name"],

                "configset_name":
                    schedule["configset_name"]
            },
            suggestions=[
                 "Show last run",
                "Show sync status"
            ]
        )