from repositories.query_audit_repository import (
    QueryAuditRepository
)


class QueryAuditService:

    def __init__(self):
        self.repo = QueryAuditRepository()

    def audit(
            self,
            session_id,
            query,
            intent,
            tool_name,
            status,
            processing_time):

        self.repo.save_audit(
            session_id=session_id,
            query=query,
            detected_intent=intent,
            execution_path=tool_name,
            status=status,
            processing_time=processing_time
        )