# services/config_service.py

from unittest import result

from repositories.config_repository import ConfigRepository
from models.tool_response import ToolResponse


class ConfigService:

    def __init__(self):
        self.repo = ConfigRepository()

    def get_config(
            self,
            project_key: str,
            process_name: str,
            config_key: str):

        result = self.repo.get_config_value(
            project_key,
            process_name
        )

        matched_config = None

        for config in result:

            config_name = config["config_key"].lower()

            if config_key == "creation" and "creation" in config_name:
                matched_config = config
                break

            elif config_key == "attachment" and "attachment" in config_name:
                matched_config = config
                break

            elif config_key == "comment" and "comment" in config_name:
                matched_config = config
                break

        print(f"Retrieved config: {result}")

        if not matched_config:

            return ToolResponse(
                module="config",
                success=False,
                message=f"Configuration '{config_key}' not found",
                data={},
                suggestions=[
                    "Show all configurations",
                    "Check another config key"
                ]
            )
        


        config = matched_config

        return ToolResponse(
            module="config",
            success=True,
            message="Configuration found",
            data={
                "config_key": config["config_key"],
                "config_value": config["config_value"]
            },
            suggestions=[
                "Check another configuration",
                "Show process details"
            ]
        )
    
    # services/config_service.py

    def is_creation_enabled(
            self,
            project_key,
            process_name):

        return self.get_config(
            project_key,
            process_name,
            "creation_enabled"
        )

    def is_attachment_enabled(
            self,
            project_key,
            process_name):

        return self.get_config(
            project_key,
            process_name,
            "attachment_enabled"
        )

    def is_comment_enabled(
            self,
            project_key,
            process_name):

        return self.get_config(
            project_key,
            process_name,
            "comment_sync_enabled"
        )