import json

from mcp import ClientSession
from mcp import StdioServerParameters
from mcp.client.stdio import stdio_client


class ExchangeMCPClient:

    async def execute(
            self,
            plan,
            context):

        server_params = StdioServerParameters(
            command="python",
            args=[
                "-m",
                "exchange_mcp.server"
            ]
        )

        async with stdio_client(server_params) as (
            read_stream,
            write_stream
        ):

            async with ClientSession(
                read_stream,
                write_stream
            ) as session:

                await session.initialize()

                arguments = self._build_arguments(
                    plan,
                    context
                )

                result = await session.call_tool(
                    plan.tool_name,
                    arguments=arguments
                )

                if not result.content:
                    return {}

                tool_response = result.content[0].text

                return json.loads(tool_response)
            
    def _build_arguments(
            self,
            plan,
            context):

        arguments = {
            "project_key": context.project_key,
            "process_name": context.process_name
        }

        if plan.field_name:
            arguments["field_name"] = plan.field_name

        if plan.config_key:
            arguments["config_key"] = plan.config_key

        return arguments