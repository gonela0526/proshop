from mcp.server import MCPServer


class MCPClient:

    def __init__(self):

        self.server = MCPServer()

    def execute(
            self,
            plan,
            context):

        return self.server.execute_tool(
            plan,
            context
        )