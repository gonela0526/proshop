from mcp.registry import MCPRegistry


class MCPServer:

    def __init__(self):

        self.registry = MCPRegistry()

    def execute_tool(
            self,
            plan,
            context):

        tool = self.registry.get_tool(
            plan.tool_name
        )

        if tool is None:

            raise Exception(
                f"Tool not found: {plan.tool_name}"
            )

        return tool.execute(
            plan,
            context
        )