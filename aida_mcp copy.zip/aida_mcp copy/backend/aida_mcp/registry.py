# mcp/registry.py

from tools.mapping_tool import MappingTool
from tools.config_tool import ConfigTool
from tools.schedule_tool import ScheduleTool


class MCPRegistry:

    def __init__(self):

        self.tools = {
            "mapping_tool": MappingTool,
            "config_tool": ConfigTool,
            "schedule_tool": ScheduleTool
        }

    def get_tool(self, tool_name):

        return self.tools.get(tool_name)