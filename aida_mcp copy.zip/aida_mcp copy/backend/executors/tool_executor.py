from tools.mapping_tool import MappingTool
from tools.config_tool import ConfigTool
from tools.schedule_tool import ScheduleTool


TOOL_REGISTRY = {
    "mapping_tool": MappingTool,
    "config_tool": ConfigTool,
    "schedule_tool": ScheduleTool
}


class ToolExecutor:

    def execute(self, plan, project_key, process_name):
        tool = TOOL_REGISTRY.get(plan.tool_name)

        if not tool:
            raise Exception(
                f"Unknown tool : {plan.tool_name}"
            )

        if plan.tool_name == "mapping_tool":

            return tool.execute(
                project_key=project_key,
                process_name=process_name,
                field_name=plan.field_name
            )

        elif plan.tool_name == "config_tool":

            return tool.execute(
                project_key=project_key,
                process_name=process_name,
                config_key=plan.config_key
            )

        elif plan.tool_name == "schedule_tool":

            return tool.execute(
                project_key=project_key,
                process_name=process_name
            )