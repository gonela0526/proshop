# planner/entity_extractor.py

import re


class EntityExtractor:

    @staticmethod
    def extract_field_name(query: str):

        patterns = [
            r"mapped to (.+)",
            r"mapping for (.+)",
            r"field mapping for (.+)"
        ]

        for pattern in patterns:

            match = re.search(
                pattern,
                query.lower()
            )

            if match:
                field_name = (
                    match.group(1)
                    .replace("?", "")
                    .strip()
                )

                return field_name

        return None
    

    @staticmethod
    def extract_config_type(query: str):

        query = query.lower()

        if "creation" in query:
            return "creation"

        if "attachment" in query:
            return "attachment"

        if "comment" in query:
            return "comment"

        return None