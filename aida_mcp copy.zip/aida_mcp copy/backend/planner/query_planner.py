# planner/query_planner.py

from models.query_plan import QueryPlan
from planner.intent_classifier import IntentClassifier
from planner.entity_extractor import EntityExtractor


class QueryPlanner:

    def build_plan(self, query: str) -> QueryPlan:

        intent = IntentClassifier.detect(query)

        print(f"Detected intent: {intent}")

        if intent == "MAPPING":

            field_name = EntityExtractor.extract_field_name(
                query
            )

            print(f"Extracted field name: {field_name}")

            return QueryPlan(
                intent="MAPPING",
                field_name=field_name,
                tool_name="mapping_tool"
            )
        
        if intent == "CONFIG":

            config_type = EntityExtractor.extract_config_type(
                query
            )

            print(f"Extracted config type: {config_type}")

            return QueryPlan(
                intent="CONFIG",
                tool_name="config_tool",
                config_key=config_type
            )
        
        if intent == "SCHEDULE":

            return QueryPlan(
                intent="SCHEDULE",
                tool_name="schedule_tool"
            )

        return QueryPlan(
            intent="UNKNOWN"
        )