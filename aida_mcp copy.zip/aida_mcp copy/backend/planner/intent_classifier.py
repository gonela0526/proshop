class IntentClassifier:

    @staticmethod
    def detect(query):

        query = query.lower()

        mapping_keywords = [
            "mapped",
            "mapping",
            "field mapping",
            "field mapped",
            "severity",
            "priority"
        ]

        config_keywords = [
            "creation",
            "attachment",
            "attachments",
            "comment",
            "comments",
            "enabled",
            "allowed",
            "transfer",
            "transferred",
            "synchronized",
            "sync"
        ]

        schedule_keywords = [
            "schedule",
            "next schedule",
            "next run",
            "sync run",
            "when will sync run",
            "cron"
        ]

        if any(
            word in query
            for word in mapping_keywords
        ):
            return "MAPPING"

        if any(
            word in query
            for word in config_keywords
        ):
            return "CONFIG"
        
        if any(
            word in query
            for word in schedule_keywords
        ):
            return "SCHEDULE"

        return "UNKNOWN"