import psycopg2
from psycopg2.extras import RealDictCursor

class PostgresDB:

    def __init__(self):
        self.conn = psycopg2.connect(
            host="localhost",
            port=5432,
            database="aida",
            user="sumanth",
            password=""
        )

    def execute_query(self, query, params=None):
        with self.conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute(query, params)
            return cur.fetchall()

    
    def execute_update(self, query, params=None):
        try:
            with self.conn.cursor() as cur:
                cur.execute(query, params)
                self.conn.commit()

        except Exception:
            self.conn.rollback()
            raise


db = PostgresDB()