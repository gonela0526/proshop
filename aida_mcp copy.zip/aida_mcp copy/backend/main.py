from llm.ollama_response_generator import OllamaResponseGenerator
from fastapi import FastAPI
# from planner.query_planner import QueryPlanner
# from executors.tool_executor import ToolExecutor
# from mcp.client import MCPClient
from services.query_audit_service import QueryAuditService
from models.tool_context import ToolContext

from llm.ollama_planner import (
    OllamaPlanner
)

from services.session_service import (
    SessionService
)

from exchange_mcp.client import ExchangeMCPClient

exchange_client = ExchangeMCPClient()



import time

# planner = QueryPlanner()
planner = OllamaPlanner()

audit_service = QueryAuditService()

session_service = SessionService()

# tool_executor = ToolExecutor()
# mcp_client = MCPClient()

app = FastAPI()





@app.post("/chat")
async def chat(request: dict):

    start_time = time.time()

    query = request["query"]

    session_id = request.get(
        "session_id",
        "default"
    )


    project_key = request.get("project")
    process_name = request.get("process")

    if not project_key or not process_name:
        session_context = (
            session_service.get_context(
                session_id
            )
        )

        if session_context:

            if not project_key:

                project_key = (
                    session_context[
                        "project_key"
                    ]
                )

            if not process_name:

                process_name = (
                    session_context[
                        "process_name"
                    ]
                )

    if project_key and process_name:

        session_service.save_context(
            session_id,
            project_key,
            process_name
        )

    context = ToolContext(
        project_key=project_key,
        process_name=process_name,
        session_id=session_id
    )

    plan = planner.build_plan(query)

    print(f"Generated plan: {plan}")

    if plan.intent == "UNKNOWN":
        return {
            "message":"I can currently help with Mapping, Config and Schedule related questions."
        }

    tool_response = None
    
    tool_response = await exchange_client.execute(
        plan=plan,
        context=context
    )

    ai_response = (
        OllamaResponseGenerator.generate(
            query=query,
            tool_response=tool_response
        )
    )
    


    processing_time = time.time() - start_time

    try:

        audit_service.audit(
            session_id=request.get(
                "session_id",
                "unknown"
            ),
            query=query,
            intent=plan.intent,
            tool_name=plan.tool_name,
            status="success",
            processing_time=processing_time
        )

    except Exception as ex:

        print(
            f"Audit failed: {ex}"
        )

    if tool_response and ai_response:
        return {
            "answer": ai_response,
            "data": tool_response
        }

    return {
        "message":
        "Unable to identify intent"
    }

