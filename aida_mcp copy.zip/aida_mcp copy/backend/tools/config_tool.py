from services.config_service import ConfigService

service = ConfigService()

class ConfigTool:

    @staticmethod
    def execute(
            plan,
            context):

        return service.get_config(
            project_key = context.project_key,
            process_name = context.process_name,
            config_key = plan.config_key
        )