from services.mapping_service import MappingService

service = MappingService()

class MappingTool:

    @staticmethod
    def execute(
            plan,
            context):

        return service.get_field_mapping(
            project_key = context.project_key,
            process_name=context.process_name,
            field_name=plan.field_name
        )