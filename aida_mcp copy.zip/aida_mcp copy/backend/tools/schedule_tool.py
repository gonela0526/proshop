from services.schedule_service import (
    ScheduleService
)

service = ScheduleService()


class ScheduleTool:

    @staticmethod
    def execute(
            plan,
            context):

        return service.get_schedule(
            project_key = context.project_key,
            process_name = context.process_name
        )