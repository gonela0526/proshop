import psycopg2


def get_db_connection():
    conn = psycopg2.connect(
        host="localhost",
        port=5432,
        database="aida",
        user="sumanth",
        password=""
    )
    return conn


# Example usage
if __name__ == "__main__":
    conn = get_db_connection()
    print("Connected successfully!")

    conn.close()