
print("hello world")
