import psycopg2
import json
import csv
from pathlib import Path

output_dir = Path("JSON")
output_dir.mkdir(parents=True, exist_ok=True)

def get_connection_prod1():
    return psycopg2.connect(
        host="136.16.200.68",
        database="app",
        user="app",
        password="agosense"
    )

def get_connection_prod2():
    return psycopg2.connect(
        host="136.16.200.28",
        database="app",
        user="app",
        password="agosense"
    )



def fetchall_dict(cursor, query, params=None):
    cursor.execute(query, params or ())
    cols = [desc[0] for desc in cursor.description]
    return [dict(zip(cols, row)) for row in cursor.fetchall()]



def build_structured_output(project_key,oem,project_name,instance,conn):
    cur = conn.cursor()

    output = {
        "oem":oem,
        "project key": project_key,
        "project name": project_name,
        "process": []
    }

    # 1️⃣ Fetch schedules
    q_schedules = """
        SELECT * FROM schedulecronbean WHERE schedulegroup_id IN (
            SELECT schedulegroup_id FROM schedulecronbean WHERE configsetid IN (
                SELECT configset_id FROM configvaluebean WHERE paramvalue LIKE %s
            )
        ) AND isactive=true;
    """

    schedules = fetchall_dict(cur, q_schedules, (f"%{project_key}%",))
    
    for schedule in schedules:
        process_name = schedule["name"]
        configset_id = schedule["configsetid"]


        # 2️⃣ Fetch configset values
        q_cfg = "SELECT * FROM configvaluebean WHERE configset_id=%s"
        cfg_values = fetchall_dict(cur, q_cfg, (configset_id,))

        # Convert config key-values into a dict
        config_dict = {
            row["paramname"]: (
                True if str(row["paramvalue"]).lower() == "true"
                else False if str(row["paramvalue"]).lower() == "false"
                else row["paramvalue"]
            )
            for row in cfg_values
        }


        #this is to get the mapping ids
        mapping_ids = [
            int(row["paramvalue"])
            for row in cfg_values
            if "mapping" in row["paramname"].lower()
            and row["paramvalue"] is not None and row["paramvalue"].isdigit()
        ]

        # mapping_dict = {
        #     "update mapping":attributeMapping_dict,
        #     "create mapping":124
        # }

        mapping_dict = {}

        for mid in mapping_ids:
            q_type = "SELECT * FROM mappingscenariobean WHERE id=%s"
            res = fetchall_dict(cur, q_type, (mid,))
            if not res:
                continue

            m_name = res[0]["name"]
            m_id = res[0]["id"]

            q_attr = "SELECT * FROM attributemappingbean WHERE scenario_id=%s"
            attributes = fetchall_dict(cur, q_attr, (mid,))

            attribute_list = []

            for attr in attributes:
                    atr_dict = {}
                    attr_id = attr["id"]
                    from_field = attr["srcname"]
                    to_field = attr["dstname"]
                    atr_dict["source"] = from_field
                    atr_dict["destination"]=to_field

                    # Fetch value mapping rules
                    q_val = "SELECT * FROM valuemappingbean WHERE attribute_id=%s"
                    values = fetchall_dict(cur, q_val, (attr_id,))
                    if values:
                        value_dict = {}
                        for row in values:
                            value_dict[row["matches"]] = row["replaces"]
                        atr_dict["Value Mapping"] = value_dict

                    attribute_list.append(atr_dict)


            attribute_dict = {}
            attribute_dict["Attribute Mapping"] = attribute_list
            mapping_dict[m_name] = attribute_dict
        
        config_dict["mappings"] = mapping_dict

        
        

       
        output["process"].append({
            "process name": process_name,
            "schedules": schedule["cronstring"],
            "lastrun": str(schedule["lastrun"]),
            "lastsuccessrun": str(schedule["lastsuccessrun"]),
            "instance":instance,
            "java_process_name":schedule["processname"],
            "configset_name":schedule["configsetname"],
            "config": config_dict
        })

    cur.close()
    return output


def read_csv_and_process(file_path):
    data_list = []
    with open(file_path, mode='r') as csvfile:
        reader = csv.DictReader(csvfile, delimiter=';')
        for row in reader:
            data_list.append(row)
    return data_list

if __name__ == "__main__":
    # Multiple sets of inputs
    projects = read_csv_and_process("project_keys_info.csv")
    conn_prod1 = get_connection_prod1()
    conn_prod2 = get_connection_prod2()


    for project in projects:
        project_key = project["Visteon Project Key"]
        oem = project["OEM Name"]
        project_name = project["Visteon Project Name"]
        instance = project["Instance"]

        if instance == "PROD1":
            conn =conn_prod1
        elif instance == "PROD2":
            conn = conn_prod2

        result = build_structured_output(project_key, oem, project_name,instance,conn)
        
        filename = output_dir / f"{project_key}_{instance}.json"
        with open(filename, "w") as f:
            json.dump(result, f, indent=4)

        print(f"JSON successfully written to: {filename}")
    
    conn_prod1.close()
    conn_prod2.close()
    
