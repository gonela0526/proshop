import './App.css'

function App() {
  return (
    <div className="flex h-screen items-center justify-center bg-slate-100">
      <h1 className="text-4xl font-bold text-blue-600">
        Welcome to AIDA
      </h1>
    </div>
  );
}

export default App;
