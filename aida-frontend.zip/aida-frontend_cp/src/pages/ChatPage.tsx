import ChatWindow from "@/components/chat";
import { ContextBar } from "@/components/context";

export default function ChatPage() {
  return (
    <div className="flex h-full flex-col">
      <ContextBar />

      <div className="flex-1 overflow-hidden">
        <ChatWindow />
      </div>
      
    </div>
  );
}