import {
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
} from "@/components/ui/sidebar";

import { chatHistory } from "@/mocks/chatHistory";

import HistoryItem from "./HistoryItem";

export default function SidebarHistory() {
  return (
    <>
      {chatHistory.map((group) => (
        <SidebarGroup key={group.label}>

          <SidebarGroupLabel>
            {group.label}
          </SidebarGroupLabel>

          <SidebarGroupContent>

            <SidebarMenu>

              {group.items.map((chat) => (
                <HistoryItem
                  key={chat.id}
                  title={chat.title}
                />
              ))}

            </SidebarMenu>

          </SidebarGroupContent>

        </SidebarGroup>
      ))}
    </>
  );
}