import { MessageSquare } from "lucide-react";

import {
  SidebarMenuButton,
  SidebarMenuItem,
} from "@/components/ui/sidebar";

interface HistoryItemProps {
  title: string;
}

export default function HistoryItem({
  title,
}: HistoryItemProps) {
  return (
    <SidebarMenuItem>
      <SidebarMenuButton>

        <MessageSquare className="h-4 w-4" />

        <span>{title}</span>

      </SidebarMenuButton>
    </SidebarMenuItem>
  );
}