import {
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
} from "@/components/ui/sidebar";

import ContextSelector from "./ContextSelector";

export default function SidebarContext() {
  return (
    <SidebarGroup>

      <SidebarGroupLabel>
        Context
      </SidebarGroupLabel>

      <SidebarGroupContent>

        <div className="space-y-4">

          <ContextSelector
            label="OEM"
            placeholder="Select OEM"
          />

          <ContextSelector
            label="Project"
            placeholder="Select Project"
          />

          <ContextSelector
            label="Process"
            placeholder="Select Process"
          />

        </div>

      </SidebarGroupContent>

    </SidebarGroup>
  );
}