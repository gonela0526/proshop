interface ContextSelectorProps {
  label: string;
  placeholder: string;
}

export default function ContextSelector({
  label,
  placeholder,
}: ContextSelectorProps) {
  return (
    <div className="space-y-2">

      <p className="text-xs font-medium text-muted-foreground">
        {label}
      </p>

      <button
        className="w-full rounded-md border bg-background px-3 py-2 text-left text-sm text-muted-foreground hover:bg-accent transition-colors"
      >
        {placeholder}
      </button>

    </div>
  );
}