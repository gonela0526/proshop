import {
  Sidebar as SidebarContainer,
  SidebarContent,
} from "@/components/ui/sidebar";

import SidebarHeader from "./header";
import SidebarHistory from "./history";
import SidebarQuickActions from "./actions";
import SidebarContext from "./context";
import SidebarFooter from "./footer";

export default function Sidebar() {
  return (
    <SidebarContainer>

      <SidebarHeader />

      <SidebarContent>

        {/* History */}
        <SidebarHistory />

        {/* Quick Actions */}
        <SidebarQuickActions />

        {/* Context */}
        <SidebarContext />

        <SidebarFooter />

      </SidebarContent>

    </SidebarContainer>
  );
}