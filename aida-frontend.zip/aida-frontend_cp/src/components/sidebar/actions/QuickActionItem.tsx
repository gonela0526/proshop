import {
  Calendar,
  GitBranch,
  History,
  Play,
} from "lucide-react";

import {
  SidebarMenuButton,
  SidebarMenuItem,
} from "@/components/ui/sidebar";

interface QuickActionItemProps {
  label: string;
  icon: "schedule" | "mapping" | "history" | "trigger";
}

function ActionIcon({
  icon,
}: {
  icon: QuickActionItemProps["icon"];
}) {
  switch (icon) {
    case "schedule":
      return <Calendar className="h-4 w-4" />;

    case "mapping":
      return <GitBranch className="h-4 w-4" />;

    case "history":
      return <History className="h-4 w-4" />;

    case "trigger":
      return <Play className="h-4 w-4" />;
  }
}

export default function QuickActionItem({
  label,
  icon,
}: QuickActionItemProps) {
  return (
    <SidebarMenuItem>
      <SidebarMenuButton>

        <ActionIcon icon={icon} />

        <span>{label}</span>

      </SidebarMenuButton>
    </SidebarMenuItem>
  );
}