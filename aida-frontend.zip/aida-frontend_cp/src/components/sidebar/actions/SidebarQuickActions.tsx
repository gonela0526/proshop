import {
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
} from "@/components/ui/sidebar";

import { quickActions } from "@/mocks/quickActions";

import QuickActionItem from "./QuickActionItem";

export default function SidebarQuickActions() {
  return (
    <SidebarGroup>

      <SidebarGroupLabel>
        Quick Actions
      </SidebarGroupLabel>

      <SidebarGroupContent>

        <SidebarMenu>

          {quickActions.map((action) => (
            <QuickActionItem
              key={action.id}
              label={action.label}
              icon={action.icon}
            />
          ))}

        </SidebarMenu>

      </SidebarGroupContent>

    </SidebarGroup>
  );
}