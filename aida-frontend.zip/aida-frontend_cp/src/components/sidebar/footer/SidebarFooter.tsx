import { LogOut } from "lucide-react";

import {
  SidebarFooter as SidebarFooterContainer,
} from "@/components/ui/sidebar";

import { profile } from "@/mocks/profile";

function getInitials(name: string) {
  return name
    .split(" ")
    .map((part) => part[0])
    .join("")
    .slice(0, 2)
    .toUpperCase();
}

export default function SidebarFooter() {
  return (
    <SidebarFooterContainer className="border-t pt-4">

      <div className="flex items-center gap-3 rounded-lg px-2 py-2">

        <div className="flex h-9 w-9 items-center justify-center rounded-full bg-muted text-sm font-semibold">
          {getInitials(profile.displayName)}
        </div>

        <div className="min-w-0">

          <p className="text-sm font-medium truncate">
            {profile.displayName}
          </p>

          <p className="text-xs text-muted-foreground truncate">
            {profile.email}
          </p>

        </div>

      </div>

      <button
        className="mt-2 flex w-full items-center gap-2 rounded-md px-2 py-2 text-sm text-muted-foreground hover:bg-accent hover:text-accent-foreground transition-colors"
      >

        <LogOut className="h-4 w-4" />

        Logout

      </button>

    </SidebarFooterContainer>
  );
}