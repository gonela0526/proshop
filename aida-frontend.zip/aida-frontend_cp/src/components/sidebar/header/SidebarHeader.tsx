import  VisteonLogo  from "@/assets/Visteon_wordmark_white.png";

import { SidebarHeader as SidebarHeaderContainer } from "@/components/ui/sidebar";

import NewChatButton from "./NewChatButton";

export default function SidebarHeader() {
  return (
    <SidebarHeaderContainer className="border-b pb-2 pt-2">

      <div className="flex justify-center items-center py-2">

          <img
            src={VisteonLogo}
            alt="Visteon Logo"
            className="h-12 w-auto object-contain" />

        {/* <span className="text-sm font-semibold tracking-tight">
          AIDA
        </span> */}

      </div>

      <NewChatButton />

    </SidebarHeaderContainer>
  );
}