interface ContextChipProps {
    label: string;
    value: string;
}

export default function ContextChip({
    label,
    value,
}: ContextChipProps) {
    return (
    <div className="flex items-center gap-1 rounded-full border border-slate-200 bg-white px-3 py-1.5 text-xs">
        <span className="font-semibold text-slate-600">{label}:</span>
        <span className="text-slate-900">{value}</span>
    </div>
    );
}