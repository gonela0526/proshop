import ContextChip from "./ContextChip";

export default function ContextBar() {
    return (
    <div className="sticky top-0 z-10 border-b border-slate-200 bg-background/95 backdrop-blur supports-\[backdrop-filter\]:bg-background/80">
        <div className="mx-auto flex w-full max-w-4xl flex-wrap items-center gap-2 px-6 py-3">
            <ContextChip label="OEM" value="FORD" />
            <ContextChip label="Project" value="FORD30806" />
            <ContextChip label="Process" value="Process1" />
        </div>
    </div>
    );
}