import {type Message } from "@/types/message";

import MessageBubble from "./MessageBubble";

interface MessageListProps {
  messages: Message[];
}

export default function MessageList({
  messages,
}: MessageListProps) {
  return (
    <div className="mx-auto flex w-full max-w-4xl flex-col gap-6 p-6">

      {messages.map((message) => (
        <MessageBubble
          key={message.id}
          message={message}
        />
      ))}

    </div>
  );
}