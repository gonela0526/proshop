import { type Message } from "@/types/message";
import MessageAvatar from "./MessageAvatar";

interface MessageBubbleProps {
  message: Message;
}

export default function MessageBubble({
  message,
}: MessageBubbleProps) {
  const isUser = message.role === "user";

  return (
    <div
      className={`flex w-full ${
        isUser ? "justify-end" : "justify-start"
      }`}
    >
      <div
        className={`flex w-full max-w-[85%] gap-3 ${
          isUser ? "flex-row-reverse ml-auto" : "flex-row"
        }`}
      >
        <MessageAvatar role={message.role} />

        <div
          className={`rounded-3xl px-4 py-2.5 shadow-sm transition-colors ${
            isUser
              ? "bg-slate-900 text-white"
              : "border border-slate-200 bg-white text-slate-900"
          }`}
        >
          <p className="whitespace-pre-wrap text-sm leading-6">
            {message.content}
          </p>

          <p
            className={`mt-1.5 text-[10px] ${
              isUser
                ? "text-white/60 text-right"
                : "text-slate-500"
            }`}
          >
            {message.timestamp.toLocaleTimeString([], {
              hour: "2-digit",
              minute: "2-digit",
            })}
          </p>
        </div>
      </div>
    </div>
  );
}