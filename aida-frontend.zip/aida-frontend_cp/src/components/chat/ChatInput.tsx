import { Paperclip, Mic, Send } from "lucide-react";

interface ChatInputProps {
  value: string;
  onChange: (value: string) => void;
  onSend: () => void;
}

export default function ChatInput({
  value,
  onChange,
  onSend,
}: ChatInputProps) {
  const handleKeyDown = (
    event: React.KeyboardEvent<HTMLTextAreaElement>
  ) => {
    if (event.key === "Enter" && !event.shiftKey) {
      event.preventDefault();
      onSend();
    }
  };

  return (
    <div className="border-t bg-background p-4">

      <div className="mx-auto max-w-3xl rounded-2xl border bg-background p-3 shadow-sm">

        <textarea
          value={value}
          onChange={(event) => onChange(event.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="Ask AIDA about mappings, schedules, exchanges, or trigger operations..."
          rows={1}
          className="max-h-40 min-h-[28px] w-full resize-none bg-transparent text-sm outline-none placeholder:text-muted-foreground"
        />

        <div className="mt-3 flex items-center justify-between">

          <button
            disabled
            className="rounded-md p-2 text-muted-foreground opacity-50"
          >
            <Paperclip className="h-4 w-4" />
          </button>

          <div className="flex items-center gap-2">

            <button
              disabled
              className="rounded-md p-2 text-muted-foreground opacity-50"
            >
              <Mic className="h-4 w-4" />
            </button>

            <button
              onClick={onSend}
              disabled={!value.trim()}
              className="rounded-md bg-primary p-2 text-primary-foreground transition-colors hover:bg-primary/90 disabled:cursor-not-allowed disabled:opacity-50"
            >
              <Send className="h-4 w-4" />
            </button>

          </div>

        </div>

      </div>

      <p className="mt-2 text-center text-xs text-muted-foreground">
        Press Enter to send • Shift+Enter for a new line
      </p>

    </div>
  );
}