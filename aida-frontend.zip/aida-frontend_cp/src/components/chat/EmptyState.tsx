import  AidaLogo  from "@/assets/aida_icon_bw.png";
import { Sparkles } from "lucide-react";

import { promptSuggestions } from "@/mocks/messages";

import SuggestionCard from "./SuggestionCard";

interface EmptyStateProps {
  onSuggestionClick: (prompt: string) => void;
}

export default function EmptyState({
  onSuggestionClick,
}: EmptyStateProps) {
  return (
    <div className="flex h-full flex-col items-center justify-center px-6">

      <div className="w-full max-w-2xl space-y-8 text-center">

        <div className="space-y-4">

          <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-background text-primary-foreground">
            <img
              src={AidaLogo}
              alt="AIDA Logo"
              className="h-12 w-auto object-contain" />
          </div>

          <div>

            <h1 className="text-3xl font-bold tracking-tight">
              Welcome to AIDA
            </h1>

            <p className="mt-2 text-muted-foreground">
              Your AI assistant for Agosense exchange management, mappings,
              schedules, and trigger operations.
            </p>

          </div>

        </div>

        <div className="rounded-2xl border bg-muted/30 p-6 text-left">

          <div className="mb-4 flex items-center gap-2 text-sm font-medium text-muted-foreground">
            <Sparkles className="h-4 w-4" />
            Try asking
          </div>

          <div className="grid gap-3">

            {promptSuggestions.map((suggestion) => (
              <SuggestionCard
                key={suggestion.id}
                title={suggestion.title}
                onClick={() => onSuggestionClick(suggestion.prompt)}
              />
            ))}

          </div>

        </div>

      </div>

    </div>
  );
}