import { useState } from "react";

import {type Message } from "@/types/message";
import { generateId } from "@/lib/id";


import ChatInput from "./ChatInput";
import EmptyState from "./EmptyState";
import MessageList from "./MessageList";

export default function ChatWindow() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");

  const sendMessage = (message: string) => {
    const text = message.trim();

    if (!text) return;

    const userMessage: Message = {
      id: generateId(),
      role: "user",
      content: text,
      timestamp: new Date(),
    };

    const assistantMessage: Message = {
      id: generateId(),
      role: "assistant",
      content:
        "This is a placeholder response from AIDA. In the next chapter we will replace this with your FastAPI backend and streaming responses.",
      timestamp: new Date(),
    };

    setMessages((previous) => [
      ...previous,
      userMessage,
      assistantMessage,
    ]);

    setInput("");
  };

  const handleSend = () => {
    sendMessage(input);
  };

  const handleSuggestionClick = (prompt: string) => {
    sendMessage(prompt);
  };

  return (
    <div className="flex h-full flex-col">

      <div className="flex-1 overflow-auto">

        {messages.length === 0 ? (
          <EmptyState onSuggestionClick={handleSuggestionClick} />
        ) : (
          <MessageList messages={messages} />
        )}

      </div>

      <ChatInput
        value={input}
        onChange={setInput}
        onSend={handleSend}
      />

    </div>
  );
}