import AidaLogo from "@/assets/aida_icon_bw.png";

interface MessageAvatarProps {
  role: "user" | "assistant";
}

export default function MessageAvatar({
  role,
}: MessageAvatarProps) {
  if (role === "assistant") {
    return (
      <div className="flex h-8 w-8 items-center justify-center rounded-full bg-background text-primary-foreground">
        <img src={AidaLogo} alt="AIDA Logo" className="h-6 w-6" />
      </div>
    );
  }

  return (
    <div className="flex h-8 w-8 items-center justify-center rounded-full bg-muted text-xs font-semibold">
      SG
    </div>
  );
}