interface SuggestionCardProps {
  title: string;
  onClick?: () => void;
}

export default function SuggestionCard({
  title,
  onClick,
}: SuggestionCardProps) {
  return (
    <button
      onClick={onClick}
      className="w-full rounded-xl border bg-background px-4 py-3 text-left text-sm transition-colors hover:bg-accent hover:text-accent-foreground"
    >
      {title}
    </button>
  );
}