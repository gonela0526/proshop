import VisteonLogo from "@/assets/v_logo.png"
import AidaLogo from "@/assets/aida_icon_bw.png"

export default function HeaderBrand() {
  return (
    <div className="flex items-center gap-3">

      {/* Organization Logo Placeholder */}
      <div className="h-9 w-9 flex items-center justify-center rounded-lg border bg-black text-primary-foreground">
        <img
          src={VisteonLogo}
          alt="Organization Logo"
          className= "h-9 w-9 object-contain" />
      </div>

      {/* Divider */}
      <div className="h-6 w-px bg-border" />

      {/* AIDA Logo */}
      <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-background text-primary-foreground">
        <img
          src={AidaLogo}
          alt="AIDA Logo"
          className= "h-9 w-9 object-contain" />
      </div>

      {/* Product Name */}
      <div className="leading-tight">

        <h1 className="text-base font-semibold tracking-tight">
          AIDA
        </h1>

        <p className="text-xs text-muted-foreground">
          Agosense Intelligent Defect Assistant
        </p>

      </div>

    </div>
  );
}