import { SidebarTrigger } from "@/components/ui/sidebar";

import HeaderActions from "./HeaderActions";
import HeaderBrand from "./HeaderBrand";

export default function Header() {
  return (
    <header className="flex h-16 items-center justify-between border-b bg-background px-4">

      <div className="flex items-center gap-4">

        <SidebarTrigger />

        <HeaderBrand />

      </div>

      <HeaderActions />

    </header>
  );
}