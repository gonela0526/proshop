import { Bell, Moon } from "lucide-react";

export default function HeaderActions() {
  return (
    <div className="flex items-center gap-2">

      {/* Notifications */}
      <button
        className="rounded-md p-2 text-muted-foreground transition-colors hover:bg-accent hover:text-accent-foreground"
      >
        <Bell className="h-5 w-5" />
      </button>

      {/* Theme Toggle Placeholder */}
      <button
        className="rounded-md p-2 text-muted-foreground transition-colors hover:bg-accent hover:text-accent-foreground"
      >
        <Moon className="h-5 w-5" />
      </button>

      {/* User Avatar */}
      <button
        className="flex h-9 w-9 items-center justify-center rounded-full bg-muted text-sm font-semibold transition-colors hover:bg-accent"
      >
        SG
      </button>

    </div>
  );
}