import {type QuickAction } from "@/types/actions";

export const quickActions: QuickAction[] = [
  {
    id: "schedule",
    label: "Schedule",
    icon: "schedule",
  },
  {
    id: "mapping",
    label: "Mapping",
    icon: "mapping",
  },
  {
    id: "exchange-history",
    label: "Exchange History",
    icon: "history",
  },
  {
    id: "trigger-sync",
    label: "Trigger Sync",
    icon: "trigger",
  },
];