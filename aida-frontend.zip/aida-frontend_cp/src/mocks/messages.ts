import {type PromptSuggestion } from "@/types/message";

export const promptSuggestions: PromptSuggestion[] = [
  {
    id: "schedule",
    title: "Show me the schedules",
    prompt: "Can you provide me the schedules",
  },
  {
    id: "mapping",
    title: "Check mapping configuration",
    prompt: "Provide me the mapping details",
  },
  {
    id: "history",
    title: "Show recent exchange failures",
    prompt: "Show recent exchange failures",
  },
  {
    id: "trigger",
    title: "Trigger a sync",
    prompt: "Trigger a sync",
  },
];