import {type  UserProfile } from "@/types/profile";

export const profile: UserProfile = {
  displayName: "Sumanth Gonela",
  email: "sumanth.gonela@example.com",
};