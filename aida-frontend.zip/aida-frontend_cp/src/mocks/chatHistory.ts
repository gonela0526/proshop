// import { ChatHistoryGroup } from "@/types/chat";

import {type  ChatHistoryGroup } from "@/types/chat";

export const chatHistory: ChatHistoryGroup[] = [
  {
    label: "Today",
    items: [
      {
        id: "1",
        title: "Exchange Monitoring",
      },
      {
        id: "2",
        title: "Ford Mapping",
      },
    ],
  },
  {
    label: "Yesterday",
    items: [
      {
        id: "3",
        title: "Schedule Query",
      },
    ],
  },
];