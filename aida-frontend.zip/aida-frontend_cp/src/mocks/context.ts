import {type ContextData } from "@/types/context";

export const contextData: ContextData = {
  oems: [
    { id: "ford", name: "Ford" },
    { id: "gm", name: "General Motors" },
    { id: "vw", name: "Volkswagen" },
  ],
  projects: [
    { id: "skylark", name: "Skylark" },
    { id: "apollo", name: "Apollo" },
    { id: "falcon", name: "Falcon" },
  ],
  processes: [
    { id: "defect-sync", name: "Defect Sync" },
    { id: "attachment-sync", name: "Attachment Sync" },
    { id: "comment-sync", name: "Comment Sync" },
  ],
};