import axios from "axios";
import { API } from "@/constants/api";

export const apiClient = axios.create({
  baseURL: API.BASE_URL,
  timeout: 30000,
  withCredentials: true,
});

apiClient.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      console.error("Authentication required");
    }

    return Promise.reject(error);
  }
);