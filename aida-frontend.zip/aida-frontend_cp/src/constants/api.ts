export const API = {
  BASE_URL: import.meta.env.VITE_API_BASE_URL || "http://localhost:8080",

  CHAT: "/agent/chat",
  CREATE_SESSION: "/create-session",
  TRIGGER_OPTIONS: "/trigger-options",
  USER_PROFILE: "/user/profile",
  LOGOUT: "/logout",
};