export interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: Date;
}

export interface PromptSuggestion {
  id: string;
  title: string;
  prompt: string;
}