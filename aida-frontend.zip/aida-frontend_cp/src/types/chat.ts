export interface ChatHistoryItem {
  id: string;
  title: string;
}

export interface ChatHistoryGroup {
  label: string;
  items: ChatHistoryItem[];
}