export interface ContextOption {
  id: string;
  name: string;
}

export interface ContextData {
  oems: ContextOption[];
  projects: ContextOption[];
  processes: ContextOption[];
}