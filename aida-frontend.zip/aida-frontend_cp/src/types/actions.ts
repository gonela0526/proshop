export interface QuickAction {
  id: string;
  label: string;
  icon: "schedule" | "mapping" | "history" | "trigger";
}