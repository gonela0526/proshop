import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'

import { QueryClientProvider } from "@tanstack/react-query";
import { RouterProvider } from "react-router-dom";


import './index.css'
import router from "@/router";
import { queryClient } from "@/lib/queryClient";

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <QueryClientProvider client={queryClient}>
      <RouterProvider router={router} />
    </QueryClientProvider>
  </StrictMode>,
)