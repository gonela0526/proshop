import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from "@tailwindcss/vite"
import tsconfigPaths from 'vite-tsconfig-paths'

// https://vite.dev/config/
export default defineConfig({
  plugins: [
    react(),
    tsconfigPaths(),
    tailwindcss(),
  ],
  server: {
    port: 5173,
    host: '0.0.0.0',
    allowedHosts: ['localhost', 'reaenv0006.ctsread.visteon.com', 'reaenv0006.ctsread.visteon.com:5173'],
  },
});
